# Lesson 11.8 Deploy Bundle

## Files
- app/academy/lesson/cipher-signal-philosophy/page.tsx — NEW (2672 lines, SWC verified)

## Manual patches required (2 files)

### 1. app/lib/academy-data.ts
Add entry AFTER 'cipher-regime-sizing' entry (see PATCH-academy-data.txt)

### 2. app/academy/page.tsx
Add 'cipher-signal-philosophy' to liveLessons Set AFTER 'cipher-regime-sizing' (see PATCH-page-allowlist.txt)

## Git commit message
Academy: ship Lesson 11.8 — The Signal Philosophy
