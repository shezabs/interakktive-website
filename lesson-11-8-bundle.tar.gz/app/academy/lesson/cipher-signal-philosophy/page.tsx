'use client'

import { useEffect, useRef, useState } from 'react'
import { motion } from 'framer-motion'

// ─── BRAND CONSTANTS ───────────────────────────────────────────────────────────
const TEAL    = '#26A69A'
const MAGENTA = '#EF5350'
const AMBER   = '#FFB300'

// ─── ANIMSCENE ─────────────────────────────────────────────────────────────────
function AnimScene({
  draw,
  deps = [],
  height = 220,
  className = '',
}: {
  draw: (ctx: CanvasRenderingContext2D, w: number, h: number, frame: number) => void
  deps?: unknown[]
  height?: number
  className?: string
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const frameRef  = useRef(0)
  const rafRef    = useRef<number>(0)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    const resize = () => {
      const dpr  = window.devicePixelRatio || 1
      const rect = canvas.getBoundingClientRect()
      canvas.width  = rect.width  * dpr
      canvas.height = rect.height * dpr
      ctx.scale(dpr, dpr)
    }
    resize()
    window.addEventListener('resize', resize)

    const tick = () => {
      const w = canvas.getBoundingClientRect().width
      const h = canvas.getBoundingClientRect().height
      ctx.clearRect(0, 0, w, h)
      draw(ctx, w, h, frameRef.current)
      frameRef.current++
      rafRef.current = requestAnimationFrame(tick)
    }
    rafRef.current = requestAnimationFrame(tick)

    return () => {
      window.removeEventListener('resize', resize)
      cancelAnimationFrame(rafRef.current)
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps)

  return (
    <canvas
      ref={canvasRef}
      style={{ width: '100%', height }}
      className={`rounded-lg ${className}`}
    />
  )
}

// ─── CONFETTI ──────────────────────────────────────────────────────────────────
function Confetti({ active }: { active: boolean }) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const rafRef    = useRef<number>(0)

  useEffect(() => {
    if (!active) return
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return
    canvas.width  = window.innerWidth
    canvas.height = window.innerHeight
    const colors = [TEAL, MAGENTA, AMBER, '#ffffff']
    const pieces = Array.from({ length: 120 }, () => ({
      x: Math.random() * canvas.width,
      y: -10,
      vx: (Math.random() - 0.5) * 4,
      vy: Math.random() * 3 + 2,
      color: colors[Math.floor(Math.random() * colors.length)],
      size: Math.random() * 8 + 4,
      spin: 0,
      spinV: (Math.random() - 0.5) * 0.2,
    }))
    const tick = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height)
      pieces.forEach(p => {
        p.x += p.vx; p.y += p.vy; p.spin += p.spinV
        ctx.save()
        ctx.translate(p.x, p.y)
        ctx.rotate(p.spin)
        ctx.fillStyle = p.color
        ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size * 0.5)
        ctx.restore()
      })
      pieces.splice(0, pieces.length, ...pieces.filter(p => p.y < canvas.height + 20))
      if (pieces.length > 0) rafRef.current = requestAnimationFrame(tick)
    }
    rafRef.current = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(rafRef.current)
  }, [active])

  if (!active) return null
  return <canvas ref={canvasRef} className="fixed inset-0 pointer-events-none z-50" />
}

// ─── HELPERS ───────────────────────────────────────────────────────────────────
function lerp(a: number, b: number, t: number) { return a + (b - a) * t }
function easeOut(t: number) { return 1 - Math.pow(1 - t, 3) }
function easeInOut(t: number) { return t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t }

function drawGrid(ctx: CanvasRenderingContext2D, w: number, h: number) {
  ctx.strokeStyle = 'rgba(255,255,255,0.04)'
  ctx.lineWidth = 1
  for (let i = 1; i < 5; i++) {
    ctx.beginPath(); ctx.moveTo(0, h * i / 5); ctx.lineTo(w, h * i / 5); ctx.stroke()
  }
}

function roundRect(
  ctx: CanvasRenderingContext2D,
  x: number, y: number, w: number, h: number, r: number
) {
  ctx.beginPath()
  ctx.moveTo(x + r, y)
  ctx.lineTo(x + w - r, y); ctx.quadraticCurveTo(x + w, y, x + w, y + r)
  ctx.lineTo(x + w, y + h - r); ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h)
  ctx.lineTo(x + r, y + h); ctx.quadraticCurveTo(x, y + h, x, y + h - r)
  ctx.lineTo(x, y + r); ctx.quadraticCurveTo(x, y, x + r, y)
  ctx.closePath()
}

// ─── SECTION WRAPPER ───────────────────────────────────────────────────────────
function Section({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <motion.section
      initial={{ opacity: 0, y: 32 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-60px' }}
      transition={{ duration: 0.55, ease: 'easeOut' }}
      className="mb-16"
    >
      <p className="text-xs font-bold tracking-widest uppercase text-amber-400/60 mb-3 font-mono">
        {label}
      </p>
      {children}
    </motion.section>
  )
}

// ─── ANIM 1: SIGNAL QUALIFICATION PIPELINE (GC) ───────────────────────────────
function Anim1Pipeline() {
  const [engine,     setEngine]     = useState<'all'|'trend'|'reversal'|'visuals'>('all')
  const [dir,        setDir]        = useState<'both'|'long'|'short'>('both')
  const [strongOnly, setStrongOnly] = useState(false)
  const [animProg,   setAnimProg]   = useState(1)
  const rafRef   = useRef<number>(0)
  const startRef = useRef<number>(0)
  const ANIM_DUR = 2400

  // Fixed candidate: Long PX, conviction 3/4 (ribbon✓ adx✓ vol✓ health✗)
  const CONV = { ribbon: true, adx: true, vol: true, health: false }
  const convScore = Object.values(CONV).filter(Boolean).length

  function getGates(eng: string, d: string, str: boolean) {
    const g0pass = eng !== 'visuals'
    const g1pass = g0pass && (d === 'both' || d === 'long')
    const g2pass = g1pass // conviction gate never blocks
    const g3pass = g2pass && (!str || convScore >= 3)
    const g4pass = g3pass
    return [
      { label: eng === 'visuals' ? 'VISUALS\nONLY' : 'SIGNAL\nORIGIN',   sub: eng === 'visuals' ? 'No signals' : 'PX (Pulse Cross)', pass: g0pass, blockReason: eng === 'visuals' ? 'Signal Engine = VISUALS ONLY. Signals disabled.' : '' },
      { label: 'DIRECTION\nFILTER',   sub: d === 'both' ? 'Both dirs' : d === 'long' ? 'Long Only' : 'Short Only', pass: g1pass, blockReason: d === 'short' ? 'Direction = SHORT ONLY. Long candidate blocked.' : '' },
      { label: 'CONVICTION\nSCORE',   sub: `${convScore}/4 factors`, pass: g2pass, blockReason: '' },
      { label: str ? 'STRONG\nONLY ✓' : 'STRONG\nONLY (off)', sub: str ? `Need 3+, got ${convScore}` : 'Gate inactive', pass: g3pass, blockReason: str && convScore < 3 ? `Strong Only: needs 3+, got ${convScore}.` : '' },
      { label: 'FINAL\nGATE',         sub: g4pass ? 'buy_signal ✓' : 'buy_signal ✗', pass: g4pass, blockReason: '' },
    ]
  }

  function runAnim() {
    cancelAnimationFrame(rafRef.current)
    startRef.current = 0
    setAnimProg(0)
    const step = (ts: number) => {
      if (!startRef.current) startRef.current = ts
      const p = Math.min(1, (ts - startRef.current) / ANIM_DUR)
      setAnimProg(p)
      if (p < 1) rafRef.current = requestAnimationFrame(step)
    }
    rafRef.current = requestAnimationFrame(step)
  }

  useEffect(() => () => cancelAnimationFrame(rafRef.current), [])

  const gates   = getGates(engine, dir, strongOnly)
  const passed  = gates[4].pass
  const blockIdx = gates.findIndex(g => !g.pass)
  const blockGate = blockIdx !== -1 ? gates[blockIdx] : null

  const draw = (ctx: CanvasRenderingContext2D, w: number, h: number) => {
    ctx.clearRect(0, 0, w, h)
    const N     = 5
    const padX  = 20
    const gW    = Math.min(82, (w - padX * 2 - (N - 1) * 16) / N)
    const gH    = 60
    const gY    = h / 2 - gH / 2
    const usableW = w - padX * 2
    const step  = usableW / (N - 1)
    const midY  = h / 2

    // connectors
    for (let i = 0; i < N - 1; i++) {
      const x1 = padX + i * step + gW / 2
      const x2 = padX + (i + 1) * step - gW / 2
      const lp = easeOut(Math.min(1, Math.max(0, animProg * N - i)))
      const isBlock = blockIdx !== -1 && i >= blockIdx
      const lineEnd = x1 + (x2 - x1) * lp

      ctx.save()
      ctx.strokeStyle = isBlock ? 'rgba(239,83,80,0.18)' : 'rgba(38,166,154,0.30)'
      ctx.lineWidth   = 2
      if (isBlock) ctx.setLineDash([4, 4])
      ctx.beginPath(); ctx.moveTo(x1, midY); ctx.lineTo(lineEnd, midY); ctx.stroke()
      ctx.setLineDash([])
      ctx.restore()

      // travelling dot
      if (lp > 0 && lp < 1 && !isBlock) {
        const dx = x1 + (x2 - x1) * lp
        ctx.save()
        ctx.shadowColor = TEAL; ctx.shadowBlur = 12
        ctx.fillStyle   = TEAL
        ctx.beginPath(); ctx.arc(dx, midY, 5, 0, Math.PI * 2); ctx.fill()
        ctx.restore()
      }
    }

    // gate boxes
    gates.forEach((gate, i) => {
      const cx    = padX + i * step
      const boxX  = cx - gW / 2
      const gp    = easeOut(Math.min(1, Math.max(0, animProg * N - i + 0.6)))
      if (gp <= 0) return

      const dimmed  = blockIdx !== -1 && i > blockIdx
      const isFail  = !gate.pass && i === blockIdx
      const bdr     = gate.pass ? 'rgba(38,166,154,0.5)' : isFail ? 'rgba(239,83,80,0.6)' : 'rgba(255,255,255,0.06)'
      const bg      = gate.pass ? 'rgba(38,166,154,0.09)' : isFail ? 'rgba(239,83,80,0.12)' : 'rgba(255,255,255,0.02)'
      const txtClr  = gate.pass ? TEAL : isFail ? MAGENTA : 'rgba(255,255,255,0.18)'

      ctx.save()
      ctx.globalAlpha = gp
      ctx.fillStyle   = bg
      roundRect(ctx, boxX, gY, gW, gH, 7); ctx.fill()
      ctx.strokeStyle = bdr; ctx.lineWidth = isFail ? 1.5 : 1
      ctx.stroke()

      // label
      ctx.fillStyle  = dimmed ? 'rgba(255,255,255,0.18)' : txtClr
      ctx.font       = `bold 8px monospace`
      ctx.textAlign  = 'center'
      gate.label.split('\n').forEach((line, li) => ctx.fillText(line, cx, gY + 11 + li * 10))

      // icon
      ctx.font       = `bold 12px monospace`
      ctx.fillStyle  = gate.pass ? TEAL : isFail ? MAGENTA : 'rgba(255,255,255,0.12)'
      ctx.fillText(gate.pass ? '✓' : isFail ? '✗' : '—', cx, gY + gH / 2 + 5)

      // sub
      ctx.font       = `8px monospace`
      ctx.fillStyle  = dimmed ? 'rgba(255,255,255,0.15)' : 'rgba(255,255,255,0.45)'
      ctx.fillText(gate.sub, cx, gY + gH - 8)
      ctx.restore()
    })

    // output signal / blocked badge
    if (animProg > 0.88) {
      const finalCX = padX + 4 * step
      const outX    = finalCX + gW / 2 + 10
      const fade    = easeOut((animProg - 0.88) / 0.12)
      const badgeW  = 66
      if (outX + badgeW <= w - 4) {
        ctx.save(); ctx.globalAlpha = fade
        if (passed) {
          ctx.fillStyle   = 'rgba(38,166,154,0.88)'
          roundRect(ctx, outX, midY - 18, badgeW, 34, 6); ctx.fill()
          ctx.fillStyle   = '#fff'; ctx.font = 'bold 10px monospace'; ctx.textAlign = 'center'
          ctx.fillText('▲', outX + badgeW / 2, midY - 4)
          ctx.fillText('Long +', outX + badgeW / 2, midY + 9)
        } else {
          ctx.fillStyle   = 'rgba(239,83,80,0.07)'
          ctx.strokeStyle = 'rgba(239,83,80,0.3)'; ctx.lineWidth = 1
          roundRect(ctx, outX, midY - 13, badgeW, 26, 6); ctx.fill(); ctx.stroke()
          ctx.fillStyle   = 'rgba(239,83,80,0.65)'; ctx.font = 'bold 9px monospace'; ctx.textAlign = 'center'
          ctx.fillText('BLOCKED', outX + badgeW / 2, midY + 4)
        }
        ctx.restore()
      }
    }
  }

  const tabBase  = 'flex-1 py-1.5 rounded-lg text-[10px] font-bold font-mono tracking-wider border transition-all'
  const activeT  = `${tabBase} bg-teal-500/15 border-teal-500/50 text-teal-400`
  const activeA  = `${tabBase} bg-amber-400/15 border-amber-400/50 text-amber-400`
  const inactive = `${tabBase} bg-transparent border-white/8 text-white/30`

  return (
    <div className="rounded-xl border border-white/8 bg-white/2 overflow-hidden">
      {/* Filter controls */}
      <div className="grid grid-cols-3 gap-4 p-4 border-b border-white/6">
        <div>
          <p className="text-[10px] font-mono font-bold tracking-widest text-white/30 uppercase mb-2">Signal Engine</p>
          <div className="flex flex-col gap-1.5">
            {([['all','ALL'],['trend','TREND'],['reversal','REVERSAL'],['visuals','VISUALS ONLY']] as const).map(([v,l]) => (
              <button key={v} onClick={() => setEngine(v)} className={engine === v ? activeT : inactive}>{l}</button>
            ))}
          </div>
        </div>
        <div>
          <p className="text-[10px] font-mono font-bold tracking-widest text-white/30 uppercase mb-2">Direction</p>
          <div className="flex flex-col gap-1.5">
            {([['both','BOTH'],['long','LONG ONLY'],['short','SHORT ONLY']] as const).map(([v,l]) => (
              <button key={v} onClick={() => setDir(v)} className={dir === v ? activeT : inactive}>{l}</button>
            ))}
          </div>
        </div>
        <div>
          <p className="text-[10px] font-mono font-bold tracking-widest text-white/30 uppercase mb-2">Strong Only</p>
          <div className="flex flex-col gap-1.5">
            <button onClick={() => setStrongOnly(false)} className={!strongOnly ? activeT : inactive}>OFF</button>
            <button onClick={() => setStrongOnly(true)}  className={strongOnly  ? activeA : inactive}>ON (3+/4)</button>
          </div>
          <div className="mt-3 rounded-lg border border-white/6 bg-white/2 p-2 space-y-1">
            {[
              { k: 'ribbon', label: 'Ribbon', pass: CONV.ribbon, val: 'Stacked' },
              { k: 'adx',    label: 'ADX',    pass: CONV.adx,    val: 'ADX 34' },
              { k: 'vol',    label: 'Volume',  pass: CONV.vol,    val: '1.4×' },
              { k: 'health', label: 'Health',  pass: CONV.health, val: '42%' },
            ].map(f => (
              <div key={f.k} className="flex items-center justify-between text-[10px] font-mono">
                <span className="text-white/35">{f.label}</span>
                <span style={{ color: f.pass ? TEAL : 'rgba(255,255,255,0.2)' }}>{f.pass ? '✓' : '✗'} {f.val}</span>
              </div>
            ))}
            <div className="border-t border-white/6 pt-1 flex items-center justify-between text-[10px] font-mono">
              <span className="text-white/35">Score</span>
              <span className="font-bold" style={{ color: convScore >= 3 ? TEAL : AMBER }}>{convScore}/4</span>
            </div>
          </div>
        </div>
      </div>

      {/* Pipeline canvas */}
      <div className="bg-[#080d18] px-4 py-2">
        <AnimScene draw={draw} deps={[engine, dir, strongOnly, animProg]} height={160} />
      </div>

      {/* Verdict row */}
      <div className="flex items-center gap-3 px-4 py-3 border-t border-white/6 min-h-[52px]">
        <span className="text-[10px] font-mono text-white/25 w-14 shrink-0">RESULT</span>
        {passed ? (
          <>
            <span className="font-mono font-bold text-sm" style={{ color: TEAL }}>
              ▲ {convScore >= 3 ? 'Long +' : 'Long'}
            </span>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded-full font-bold"
              style={{ background: 'rgba(38,166,154,0.12)', color: TEAL }}>
              Trend (PX)
            </span>
            <span className="text-xs text-white/45 ml-1">
              {convScore >= 3
                ? `Passed all gates. Strong (${convScore}/4). Fires with + marker.`
                : `Passed all gates. Standard (${convScore}/4). Normal label.`}
            </span>
          </>
        ) : (
          <>
            <span className="font-mono font-bold text-sm text-red-400/60">&#8212; BLOCKED</span>
            <span className="text-xs text-white/45 ml-1">{blockGate?.blockReason}</span>
          </>
        )}
        <button
          onClick={runAnim}
          className="ml-auto shrink-0 px-4 py-1.5 rounded-lg text-[11px] font-bold font-mono tracking-widest hover:opacity-80 transition-opacity"
          style={{ background: AMBER, color: '#060a12' }}
        >
          &#9654; RUN
        </button>
      </div>
    </div>
  )
}

// ─── ANIM 2: PX VS TS ORIGINS ─────────────────────────────────────────────────
function Anim2Origins() {
  const [active, setActive] = useState<'px'|'ts'>('px')

  const draw = (ctx: CanvasRenderingContext2D, w: number, h: number, frame: number) => {
    drawGrid(ctx, w, h)
    const pulse = Math.sin(frame * 0.05) * 0.5 + 0.5

    // Shared price scaffold
    const midY = h * 0.50
    const atrPx = h * 0.09

    if (active === 'px') {
      // Pulse line
      const pulseY = midY + atrPx * 1.5
      ctx.save(); ctx.strokeStyle = TEAL; ctx.globalAlpha = 0.5 + pulse * 0.2; ctx.lineWidth = 1.5
      ctx.setLineDash([5, 3])
      ctx.beginPath(); ctx.moveTo(0, pulseY); ctx.lineTo(w, pulseY); ctx.stroke()
      ctx.setLineDash([]); ctx.restore()
      ctx.fillStyle = `rgba(38,166,154,0.6)`; ctx.font = '9px monospace'; ctx.textAlign = 'right'
      ctx.fillText('CIPHER PULSE', w - 8, pulseY - 5); ctx.textAlign = 'left'

      // Candles approaching and crossing pulse
      const candles = [
        { x: 0.20, o: 0.62, h: 0.66, l: 0.58, c: 0.60 },
        { x: 0.32, o: 0.60, h: 0.64, l: 0.56, c: 0.58 },
        { x: 0.44, o: 0.58, h: 0.62, l: 0.53, c: 0.55 }, // approaching pulse
        { x: 0.56, o: 0.55, h: 0.58, l: 0.49, c: 0.51 }, // at pulse
        { x: 0.68, o: 0.51, h: 0.53, l: 0.44, c: 0.46 }, // CROSS — PX fires
        { x: 0.80, o: 0.46, h: 0.50, l: 0.42, c: 0.48 },
      ]
      const py = (n: number) => h * (1 - n * 0.70 - 0.15)
      const bW = w * 0.06
      candles.forEach((c, i) => {
        const cx = w * c.x; const isCross = i === 4
        const bull = c.c >= c.o
        const col  = isCross ? TEAL : (bull ? 'rgba(38,166,154,0.55)' : 'rgba(239,83,80,0.55)')
        ctx.strokeStyle = col; ctx.lineWidth = isCross ? 1.5 : 1
        ctx.beginPath(); ctx.moveTo(cx, py(c.h)); ctx.lineTo(cx, py(c.l)); ctx.stroke()
        ctx.fillStyle = col
        const yT = py(Math.max(c.o, c.c)); const yB = py(Math.min(c.o, c.c))
        ctx.fillRect(cx - bW/2, yT, bW, Math.max(2, yB - yT))
        if (isCross) {
          ctx.save(); ctx.shadowColor = TEAL; ctx.shadowBlur = 14 + pulse * 8
          ctx.fillStyle = TEAL; ctx.strokeStyle = '#fff'; ctx.lineWidth = 1
          roundRect(ctx, cx - 22, py(c.l) + 12, 44, 24, 5); ctx.fill(); ctx.stroke()
          ctx.fillStyle = '#fff'; ctx.font = 'bold 9px monospace'; ctx.textAlign = 'center'
          ctx.fillText('▲', cx, py(c.l) + 24)
          ctx.fillText('Long', cx, py(c.l) + 35)
          ctx.restore()
          // Cross marker
          ctx.save(); ctx.strokeStyle = TEAL; ctx.globalAlpha = 0.5 + pulse * 0.3; ctx.lineWidth = 1
          ctx.setLineDash([2, 2])
          ctx.beginPath(); ctx.moveTo(cx, py(c.l)); ctx.lineTo(cx, pulseY); ctx.stroke()
          ctx.setLineDash([]); ctx.restore()
        }
      })

      // Label
      ctx.fillStyle = TEAL; ctx.font = 'bold 11px monospace'
      ctx.fillText('PULSE CROSS (PX)', 12, 20)
      ctx.fillStyle = 'rgba(255,255,255,0.4)'; ctx.font = '10px monospace'
      ctx.fillText('Price crosses the Cipher Pulse line', 12, 34)

    } else {
      // TS: tension stretch → snap
      const tensionY = midY - atrPx * 2.2
      // Tension fill
      ctx.fillStyle = `rgba(239,83,80,${0.10 + pulse * 0.07})`
      ctx.fillRect(0, tensionY, w, midY - tensionY)
      ctx.fillStyle = 'rgba(239,83,80,0.3)'; ctx.font = '9px monospace'; ctx.textAlign = 'right'
      ctx.fillText('TENSION STRETCHED', w - 8, tensionY + 14); ctx.textAlign = 'left'

      const candles = [
        { x: 0.15, o: 0.68, h: 0.74, l: 0.65, c: 0.72 }, // stretching up
        { x: 0.27, o: 0.72, h: 0.78, l: 0.69, c: 0.76 }, // more stretch
        { x: 0.39, o: 0.76, h: 0.80, l: 0.70, c: 0.71 }, // reversal candle
        { x: 0.51, o: 0.71, h: 0.73, l: 0.62, c: 0.63 }, // TS snap bar
        { x: 0.63, o: 0.63, h: 0.65, l: 0.55, c: 0.57 },
        { x: 0.75, o: 0.57, h: 0.59, l: 0.50, c: 0.52 },
      ]
      const py = (n: number) => h * (1 - n * 0.70 - 0.10)
      const bW = w * 0.06
      candles.forEach((c, i) => {
        const cx = w * c.x; const isSnap = i === 3
        const bull = c.c >= c.o
        const col  = bull ? 'rgba(38,166,154,0.55)' : (isSnap ? MAGENTA : 'rgba(239,83,80,0.55)')
        ctx.strokeStyle = col; ctx.lineWidth = isSnap ? 1.5 : 1
        ctx.beginPath(); ctx.moveTo(cx, py(c.h)); ctx.lineTo(cx, py(c.l)); ctx.stroke()
        ctx.fillStyle = col
        const yT = py(Math.max(c.o, c.c)); const yB = py(Math.min(c.o, c.c))
        ctx.fillRect(cx - bW/2, yT, bW, Math.max(2, yB - yT))
        if (isSnap) {
          ctx.save(); ctx.shadowColor = MAGENTA; ctx.shadowBlur = 14 + pulse * 8
          ctx.fillStyle = MAGENTA; ctx.strokeStyle = '#fff'; ctx.lineWidth = 1
          roundRect(ctx, cx - 24, py(c.h) - 34, 48, 24, 5); ctx.fill(); ctx.stroke()
          ctx.fillStyle = '#fff'; ctx.font = 'bold 9px monospace'; ctx.textAlign = 'center'
          ctx.fillText('▼', cx, py(c.h) - 22)
          ctx.fillText('Short', cx, py(c.h) - 11)
          ctx.restore()
        }
      })

      // 4 condition badges
      const badges = ['Stretch ✓', 'Snap ✓', 'Body ✓', 'Velocity ✓']
      badges.forEach((b, i) => {
        ctx.fillStyle = 'rgba(239,83,80,0.12)'
        ctx.strokeStyle = 'rgba(239,83,80,0.35)'; ctx.lineWidth = 1
        roundRect(ctx, 10 + i * 74, h - 34, 68, 22, 5); ctx.fill(); ctx.stroke()
        ctx.fillStyle = MAGENTA; ctx.font = 'bold 8px monospace'; ctx.textAlign = 'center'
        ctx.fillText(b, 10 + i * 74 + 34, h - 19)
      })
      ctx.textAlign = 'left'

      ctx.fillStyle = MAGENTA; ctx.font = 'bold 11px monospace'
      ctx.fillText('TENSION SNAP (TS)', 12, 20)
      ctx.fillStyle = 'rgba(255,255,255,0.4)'; ctx.font = '10px monospace'
      ctx.fillText('4 conditions: stretch + snap + body + velocity', 12, 34)
    }
  }

  return (
    <div className="space-y-3">
      <div className="flex gap-2">
        {([['px', 'PULSE CROSS (PX)', TEAL], ['ts', 'TENSION SNAP (TS)', MAGENTA]] as const).map(([v, l, c]) => (
          <button
            key={v}
            onClick={() => setActive(v)}
            className="flex-1 py-2 rounded-lg text-xs font-bold font-mono tracking-wider border transition-all"
            style={{
              background: active === v ? c + '18' : 'transparent',
              color: active === v ? c : 'rgba(255,255,255,0.3)',
              borderColor: active === v ? c + '55' : 'rgba(255,255,255,0.08)',
            }}
          >{l}</button>
        ))}
      </div>
      <AnimScene draw={draw} deps={[active]} height={220} />
      <div className="rounded-lg border border-white/8 bg-white/2 p-3 text-xs text-white/55 leading-relaxed">
        {active === 'px'
          ? <>PX fires when price crosses the Cipher Pulse — the adaptive ATR-based level below price in an uptrend, above in a downtrend. It is a <span className="text-white font-semibold">trend continuation</span> signal. Distance and rapid-flip filters prevent chop entries.</>
          : <>TS requires all four conditions simultaneously: prior tension <span className="text-white font-semibold">stretched</span> beyond threshold, a snap candle with directional body, velocity shift confirmation, and a cooldown bar since the last TS signal. It is a <span className="text-white font-semibold">mean-reversion</span> signal.</>
        }
      </div>
    </div>
  )
}

// ─── ANIM 3: PX MECHANICS ─────────────────────────────────────────────────────
function Anim3PX() {
  const draw = (ctx: CanvasRenderingContext2D, w: number, h: number, frame: number) => {
    drawGrid(ctx, w, h)
    const pulse = Math.sin(frame * 0.05) * 0.5 + 0.5

    const midY  = h * 0.52
    const atrPx = h * 0.09
    const pulseY = midY + atrPx * 1.6
    const py = (n: number) => h * (1 - n * 0.72 - 0.14)
    const bW = w * 0.055

    // Min distance zone
    ctx.fillStyle = 'rgba(255,179,0,0.05)'
    ctx.fillRect(0, pulseY - atrPx * 0.8, w, atrPx * 1.6)
    ctx.fillStyle = 'rgba(255,179,0,0.4)'; ctx.font = '9px monospace'; ctx.textAlign = 'right'
    ctx.fillText('MIN DIST ZONE', w - 8, pulseY - atrPx * 0.8 + 12); ctx.textAlign = 'left'

    // Pulse line
    ctx.save(); ctx.strokeStyle = TEAL; ctx.globalAlpha = 0.5 + pulse * 0.15; ctx.lineWidth = 1.5; ctx.setLineDash([5,3])
    ctx.beginPath(); ctx.moveTo(0, pulseY); ctx.lineTo(w, pulseY); ctx.stroke()
    ctx.setLineDash([]); ctx.restore()

    const candles = [
      { x: 0.12, o: 0.60, h: 0.65, l: 0.57, c: 0.62 },
      { x: 0.24, o: 0.62, h: 0.67, l: 0.58, c: 0.64 },
      { x: 0.36, o: 0.64, h: 0.69, l: 0.60, c: 0.62, blocked: true },   // rapid flip block example
      { x: 0.48, o: 0.62, h: 0.65, l: 0.56, c: 0.58 },
      { x: 0.60, o: 0.58, h: 0.61, l: 0.51, c: 0.53 },
      { x: 0.72, o: 0.53, h: 0.56, l: 0.46, c: 0.48, signal: true },    // valid PX
      { x: 0.84, o: 0.48, h: 0.52, l: 0.44, c: 0.50 },
    ]

    candles.forEach(c => {
      const cx = w * c.x
      const col = c.signal ? TEAL : c.blocked ? 'rgba(255,179,0,0.5)' : (c.c >= c.o ? 'rgba(38,166,154,0.5)' : 'rgba(239,83,80,0.5)')
      ctx.strokeStyle = col; ctx.lineWidth = c.signal ? 1.5 : 1
      ctx.beginPath(); ctx.moveTo(cx, py(c.h)); ctx.lineTo(cx, py(c.l)); ctx.stroke()
      ctx.fillStyle = col
      const yT = py(Math.max(c.o, c.c)); const yB = py(Math.min(c.o, c.c))
      ctx.fillRect(cx - bW/2, yT, bW, Math.max(2, yB - yT))

      if (c.blocked) {
        ctx.fillStyle = AMBER; ctx.font = 'bold 9px monospace'; ctx.textAlign = 'center'
        ctx.fillText('⚡ FLIP', cx, py(c.h) - 6)
        ctx.fillText('BLOCKED', cx, py(c.h) - 18)
      }
      if (c.signal) {
        ctx.save(); ctx.shadowColor = TEAL; ctx.shadowBlur = 12 + pulse * 6
        ctx.fillStyle = TEAL; ctx.strokeStyle = '#fff'; ctx.lineWidth = 1
        roundRect(ctx, cx - 22, py(c.l) + 10, 44, 26, 5); ctx.fill(); ctx.stroke()
        ctx.fillStyle = '#fff'; ctx.font = 'bold 10px monospace'; ctx.textAlign = 'center'
        ctx.fillText('▲ Long', cx, py(c.l) + 27)
        ctx.restore()
      }
    })

    ctx.fillStyle = 'rgba(255,255,255,0.25)'; ctx.font = '9px monospace'; ctx.textAlign = 'left'
    ctx.fillText('Pulse line (CIPHER FLOW - ATR × pulse_factor)', 10, pulseY + 12)
  }

  return (
    <div className="space-y-4">
      <AnimScene draw={draw} height={210} />
      <div className="grid grid-cols-3 gap-3 text-xs font-mono">
        {[
          { label: 'Body Check', color: TEAL,    desc: 'Candle body must be meaningful — no doji crosses.' },
          { label: 'Min Distance', color: AMBER, desc: 'Price must be far enough from pulse pre-cross to avoid noise.' },
          { label: 'Rapid Flip', color: MAGENTA, desc: 'If opposite PX fired recently, this direction is suppressed as chop.' },
        ].map(({ label, color, desc }) => (
          <div key={label} className="rounded-lg border border-white/8 bg-white/2 p-3">
            <p className="font-bold mb-1" style={{ color }}>{label}</p>
            <p className="text-white/45 text-[11px] leading-snug">{desc}</p>
          </div>
        ))}
      </div>
    </div>
  )
}

// ─── ANIM 4: TS 4 CONDITIONS ───────────────────────────────────────────────────
function Anim4TS() {
  const [step, setStep] = useState(0)
  const [playing, setPlaying] = useState(false)
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null)

  const CONDITIONS = [
    {
      label: '1 — Prior Stretch',
      color: MAGENTA,
      desc: 'Tension must have reached the stretch threshold in recent bars. No snap is valid without a prior extreme.',
      active: [true, false, false, false],
    },
    {
      label: '2 — Snap Candle',
      color: MAGENTA,
      desc: 'Price must reverse sharply from the extreme — a clear directional candle in the opposite direction to the stretch.',
      active: [true, true, false, false],
    },
    {
      label: '3 — Body Conviction',
      color: MAGENTA,
      desc: 'The snap candle needs a real body — not a wick reversal. Wicks can be noise. A body shows commitment.',
      active: [true, true, true, false],
    },
    {
      label: '4 — Velocity Shift + Cooldown',
      color: MAGENTA,
      desc: 'Momentum velocity must shift direction. A cooldown gate prevents TS signals firing back-to-back in the same direction.',
      active: [true, true, true, true],
    },
  ]

  useEffect(() => {
    if (!playing) return
    timerRef.current = setTimeout(() => setStep(s => (s + 1) % CONDITIONS.length), 1800)
    return () => { if (timerRef.current) clearTimeout(timerRef.current) }
  }, [step, playing])

  const cond = CONDITIONS[step]

  const draw = (ctx: CanvasRenderingContext2D, w: number, h: number, frame: number) => {
    drawGrid(ctx, w, h)
    const pulse = Math.sin(frame * 0.06) * 0.5 + 0.5

    const tensionThreshY = h * 0.25
    const midY           = h * 0.55

    // Tension fill
    ctx.fillStyle = `rgba(239,83,80,${0.07 + pulse * 0.05})`
    ctx.fillRect(0, tensionThreshY, w, midY - tensionThreshY)

    const candles = [
      { x: 0.12, o: 0.60, h: 0.65, l: 0.57, c: 0.63 },
      { x: 0.24, o: 0.63, h: 0.70, l: 0.60, c: 0.68 }, // stretch building
      { x: 0.36, o: 0.68, h: 0.76, l: 0.65, c: 0.73 }, // at tension extreme
      { x: 0.48, o: 0.73, h: 0.78, l: 0.64, c: 0.66 }, // snap candle (big bear body)
      { x: 0.60, o: 0.66, h: 0.68, l: 0.57, c: 0.59 }, // continuation
      { x: 0.72, o: 0.59, h: 0.61, l: 0.51, c: 0.53 },
    ]
    const py = (n: number) => h * (1 - n * 0.65 - 0.20)
    const bW = w * 0.055

    candles.forEach((c, i) => {
      const cx  = w * c.x
      const isSnap = i === 3
      const col = c.c >= c.o ? 'rgba(38,166,154,0.55)' : (isSnap ? MAGENTA : 'rgba(239,83,80,0.55)')
      ctx.strokeStyle = col; ctx.lineWidth = isSnap ? 1.5 : 1
      ctx.beginPath(); ctx.moveTo(cx, py(c.h)); ctx.lineTo(cx, py(c.l)); ctx.stroke()
      ctx.fillStyle = col
      const yT = py(Math.max(c.o, c.c)); const yB = py(Math.min(c.o, c.c))
      ctx.fillRect(cx - bW/2, yT, bW, Math.max(2, yB - yT))
    })

    // Condition highlights
    const snapCX = w * 0.48
    if (cond.active[0]) { // prior stretch bracket
      ctx.save(); ctx.strokeStyle = MAGENTA; ctx.globalAlpha = 0.5; ctx.lineWidth = 1.5; ctx.setLineDash([3,3])
      ctx.beginPath(); ctx.moveTo(w * 0.24, tensionThreshY + 4); ctx.lineTo(w * 0.36, tensionThreshY + 4); ctx.stroke()
      ctx.setLineDash([]); ctx.restore()
      ctx.fillStyle = MAGENTA; ctx.font = 'bold 8px monospace'; ctx.textAlign = 'center'
      ctx.fillText('STRETCHED', w * 0.30, tensionThreshY - 3)
    }
    if (cond.active[1]) { // snap highlight
      ctx.save(); ctx.shadowColor = MAGENTA; ctx.shadowBlur = 10 + pulse * 6
      ctx.strokeStyle = MAGENTA; ctx.lineWidth = 1.5
      ctx.strokeRect(snapCX - bW, py(0.78) - 2, bW * 2, py(0.64) - py(0.78) + 4)
      ctx.restore()
      ctx.fillStyle = MAGENTA; ctx.font = 'bold 8px monospace'; ctx.textAlign = 'center'
      ctx.fillText('SNAP', snapCX, py(0.78) - 8)
    }
    if (cond.active[2]) { // body arrow
      ctx.fillStyle = 'rgba(239,83,80,0.8)'; ctx.font = '8px monospace'; ctx.textAlign = 'left'
      ctx.fillText('BODY ✓', snapCX + bW + 6, py(0.70))
    }
    if (cond.active[3]) { // velocity label + signal
      ctx.save(); ctx.shadowColor = MAGENTA; ctx.shadowBlur = 12 + pulse * 8
      ctx.fillStyle = MAGENTA; ctx.strokeStyle = '#fff'; ctx.lineWidth = 1
      roundRect(ctx, snapCX - 24, py(0.64) + 10, 48, 26, 5); ctx.fill(); ctx.stroke()
      ctx.fillStyle = '#fff'; ctx.font = 'bold 10px monospace'; ctx.textAlign = 'center'
      ctx.fillText('▼ Short', snapCX, py(0.64) + 27); ctx.restore()
      ctx.fillStyle = 'rgba(239,83,80,0.7)'; ctx.font = '8px monospace'; ctx.textAlign = 'center'
      ctx.fillText('VEL SHIFT ✓', w * 0.60, h - 18)
    }
    ctx.textAlign = 'left'
  }

  return (
    <div className="space-y-3">
      <AnimScene draw={draw} deps={[step]} height={210} />
      <div className="flex gap-2">
        {CONDITIONS.map((c, i) => (
          <button
            key={i}
            onClick={() => { setStep(i); setPlaying(false) }}
            className="flex-1 py-1.5 rounded-lg text-[10px] font-bold font-mono border transition-all"
            style={{
              background: step === i ? 'rgba(239,83,80,0.12)' : 'transparent',
              color: step === i ? MAGENTA : 'rgba(255,255,255,0.25)',
              borderColor: step === i ? 'rgba(239,83,80,0.4)' : 'rgba(255,255,255,0.06)',
            }}
          >{i + 1}</button>
        ))}
        <button
          onClick={() => setPlaying(p => !p)}
          className="px-3 py-1.5 rounded-lg text-[10px] font-mono border border-white/10 text-white/40"
        >{playing ? '⏸' : '▶'}</button>
      </div>
      <div className="rounded-lg border border-white/8 bg-white/2 p-3">
        <p className="text-xs font-bold font-mono mb-1" style={{ color: MAGENTA }}>{cond.label}</p>
        <p className="text-xs text-white/55 leading-relaxed">{cond.desc}</p>
      </div>
    </div>
  )
}

// ─── MAIN COMPONENT ────────────────────────────────────────────────────────────
export default function Lesson118() {
  // ── Game state ──
  const [gameStep,     setGameStep]     = useState(0)
  const [gameScore,    setGameScore]    = useState(0)
  const [gameSelected, setGameSelected] = useState<string | null>(null)
  const [gameRevealed, setGameRevealed] = useState(false)
  const [gameDone,     setGameDone]     = useState(false)

  // ── Quiz state ──
  const [quizStep,     setQuizStep]     = useState(0)
  const [quizScore,    setQuizScore]    = useState(0)
  const [quizSelected, setQuizSelected] = useState<string | null>(null)
  const [quizRevealed, setQuizRevealed] = useState(false)
  const [quizDone,     setQuizDone]     = useState(false)
  const [quizPassed,   setQuizPassed]   = useState(false)
  const [confettiActive, setConfettiActive] = useState(false)

  // ── Cert reveal ──
  useEffect(() => {
    if (quizDone && quizPassed) {
      const t = setTimeout(() => setConfettiActive(true), 400)
      return () => clearTimeout(t)
    }
  }, [quizDone, quizPassed])

  // ── Game handlers ──
  function handleGameSelect(optId: string) {
    if (gameRevealed) return
    setGameSelected(optId)
    setGameRevealed(true)
    const opt = gameRounds[gameStep].options.find(o => o.id === optId)
    if (opt?.correct) setGameScore(s => s + 1)
  }
  function handleGameNext() {
    if (gameStep < gameRounds.length - 1) {
      setGameStep(s => s + 1); setGameSelected(null); setGameRevealed(false)
    } else { setGameDone(true) }
  }

  // ── Quiz handlers ──
  function handleQuizSelect(optId: string) {
    if (quizRevealed) return
    setQuizSelected(optId)
    setQuizRevealed(true)
    if (optId === quizQuestions[quizStep].correct) setQuizScore(s => s + 1)
  }
  function handleQuizNext() {
    if (quizStep < quizQuestions.length - 1) {
      setQuizStep(s => s + 1); setQuizSelected(null); setQuizRevealed(false)
    } else {
      const lastCorrect = quizSelected === quizQuestions[quizStep].correct ? 1 : 0
      const finalScore  = quizScore + lastCorrect
      const pct = Math.round((finalScore / quizQuestions.length) * 100)
      setQuizDone(true); setQuizPassed(pct >= 66)
    }
  }

  const certCode = 'ATLAS-SGA-118-2026'

  return (
    <>
    <Confetti active={confettiActive} />
    <main
      className="min-h-screen text-white"
      style={{ background: 'linear-gradient(to bottom, #060a12, #0a0f1a)' }}
    >
      <div className="max-w-2xl mx-auto px-5 pb-24 pt-8">

        {/* ── HERO ── */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-14 text-center"
        >
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-amber-400/30 bg-amber-400/8 mb-5">
            <span className="text-amber-400 text-xs">&#9812;</span>
            <span className="text-amber-400 text-xs font-bold tracking-widest font-mono">CIPHER PRO MASTERY</span>
            <span className="text-amber-400 text-xs">&#9812;</span>
          </div>
          <p className="text-xs font-bold tracking-widest uppercase text-white/35 font-mono mb-3">
            Level 11 &middot; Lesson 8
          </p>
          <h1 className="text-3xl font-extrabold leading-tight mb-4">
            The Signal<br />
            <span style={{ color: AMBER }}>Philosophy</span>
          </h1>
          <p className="text-base text-gray-400 leading-relaxed max-w-lg mx-auto">
            Every signal on your CIPHER chart survived a multi-stage qualification pipeline.
            Most candidates never made it. Understanding why separates operators from observers.
          </p>
          <div className="flex items-center justify-center gap-6 mt-6 text-xs font-mono text-white/30">
            <span>17 SECTIONS</span>
            <span className="w-px h-3 bg-white/15" />
            <span>45 MIN</span>
            <span className="w-px h-3 bg-white/15" />
            <span>CERT: SIGNAL ARCHITECT</span>
          </div>
        </motion.div>

        {/* ── S00 ── */}
        <Section label="00 — Why Signal Quality Beats Signal Quantity">
          <h2 className="text-2xl font-extrabold mb-4">
            More Signals Is Not Better
          </h2>
          <div className="text-gray-400 space-y-4 leading-relaxed">
            <p>
              Most indicators fire signals freely. Price touches a level — signal fires.
              RSI crosses a threshold — signal fires. The result is a chart full of arrows
              and a trader who learns nothing about which signals actually matter.
            </p>
            <p>
              CIPHER was designed around the opposite philosophy. A signal that has not
              passed through origin validation, direction gating, conviction scoring,
              and a final qualification check does not appear on your chart at all.
              What you see is what survived.
            </p>
            <p>
              This lesson teaches you the architecture of that pipeline — so you understand
              not just what CIPHER signals look like, but why they fire when they do
              and why they stay silent when the conditions are not right.
            </p>
          </div>
          <div className="mt-6 rounded-lg border-l-4 border-amber-400 bg-amber-400/6 px-4 py-3">
            <p className="text-sm text-amber-300 font-semibold leading-relaxed">
              The absence of a signal is itself information. If CIPHER is quiet, it means
              the pipeline found something that disqualified the candidate. Silence is
              not a malfunction — it is the filter working.
            </p>
          </div>
        </Section>

        {/* ── S01 GC ── */}
        <Section label="01 ⭐ — CIPHER Doesn't Fire — It Qualifies">
          <h2 className="text-2xl font-extrabold mb-2">
            The Qualification Pipeline
          </h2>
          <p className="text-gray-400 mb-5 leading-relaxed">
            Configure the filters and press RUN to watch a Long candidate move through
            each gate. Change any filter to block it at a different stage.
          </p>
          <Anim1Pipeline />
          <div className="mt-4 rounded-lg border border-white/8 bg-white/2 px-4 py-3">
            <p className="text-sm text-white/60 leading-relaxed">
              Every time you see a signal on your chart, it cleared all five gates.
              Every time CIPHER is silent, at least one gate rejected the candidate.
              The filters are not limitations — they are what makes the signals trustworthy.
            </p>
          </div>
        </Section>

        {/* ── S02 ── */}
        <Section label="02 — The Two Signal Origins: PX vs TS">
          <h2 className="text-2xl font-extrabold mb-2">
            Two Engines. One Chart.
          </h2>
          <p className="text-gray-400 mb-5 leading-relaxed">
            CIPHER has two independent signal engines running simultaneously. Each has its
            own trigger logic, its own market condition, and its own entry philosophy.
            They are not the same signal with different names.
          </p>
          <Anim2Origins />
          <div className="mt-5 grid grid-cols-2 gap-3 text-xs font-mono">
            {[
              { label: 'PX — Trend', color: TEAL,    desc: 'Fires on pulse line cross. Best when ribbon is stacked and ADX shows trend strength. Continuation entries.' },
              { label: 'TS — Reversal', color: MAGENTA, desc: 'Fires on tension snap. Best when tension fill is bright and momentum is shifting. Mean-reversion entries.' },
            ].map(({ label, color, desc }) => (
              <div key={label} className="rounded-lg border border-white/8 bg-white/2 p-3">
                <p className="font-bold mb-1.5" style={{ color }}>{label}</p>
                <p className="text-white/50 text-[11px] leading-snug">{desc}</p>
              </div>
            ))}
          </div>
        </Section>

        {/* ── S03 ── */}
        <Section label="03 — Pulse Cross (PX): How It Fires">
          <h2 className="text-2xl font-extrabold mb-2">
            Three Gates Before the Cross Counts
          </h2>
          <p className="text-gray-400 mb-5 leading-relaxed">
            A Pulse Cross is not simply price touching the pulse line. Three validation
            checks run on every bar where a cross is detected. All three must pass.
          </p>
          <Anim3PX />
          <div className="mt-4 rounded-lg border border-white/8 bg-white/2 p-4 font-mono text-xs space-y-2">
            <div className="text-white/40 mb-1 text-[10px] tracking-widest uppercase">PX Conditions</div>
            <div className="text-white/70">1. Price crosses the Pulse line (flip detected)</div>
            <div className="text-white/70">2. Candle body meets minimum size threshold</div>
            <div className="text-white/70">3. Pre-cross distance clears minimum (or failed flip exempt)</div>
            <div className="text-white/70">4. No opposite-direction PX within rapid-flip window</div>
            <div className="border-t border-white/8 pt-2 text-white/35 text-[10px]">
              Rapid-flip window varies by asset class and timeframe. Index CFDs: 2 bars all TFs. Crypto: shorter windows.
            </div>
          </div>
        </Section>

        {/* ── S04 ── */}
        <Section label="04 — Tension Snap (TS): The 4 Conditions">
          <h2 className="text-2xl font-extrabold mb-2">
            All Four Must Fire Together
          </h2>
          <p className="text-gray-400 mb-5 leading-relaxed">
            TS is the more selective of the two engines. Each condition filters for
            a different aspect of a genuine mean-reversion setup. Step through them
            to see what each one adds to the qualification.
          </p>
          <Anim4TS />
        </Section>

        {/* ── S05: SIGNAL ENGINE INPUT — 4 MODES ── */}
        <Section label="05 — The Signal Engine Input: 4 Modes">
          <h2 className="text-2xl font-extrabold mb-2">
            What CIPHER Is Allowed to Show You
          </h2>
          <p className="text-gray-400 mb-5 leading-relaxed">
            Before any signal can fire, the Signal Engine input determines which origin
            types are permitted. This is the first gate in the pipeline. Get it wrong
            and CIPHER will either show you everything or nothing.
          </p>
          <Anim5SignalEngine />
          <div className="mt-5 rounded-lg border border-white/8 bg-white/2 p-4 font-mono text-xs space-y-3">
            <div className="text-white/40 text-[10px] tracking-widest uppercase mb-1">Mode Reference</div>
            {[
              { mode: 'All Signals',   color: TEAL,    desc: 'Both PX and TS active. Full coverage. Default for most operators.' },
              { mode: 'Trend',         color: TEAL,    desc: 'PX only. Use when HTF is clearly trending and you want continuation entries only.' },
              { mode: 'Reversal',      color: MAGENTA, desc: 'TS only. Use when tension is consistently elevated and you are fading extremes.' },
              { mode: 'Visuals Only',  color: AMBER,   desc: 'No signal labels. Chart tools still active. Use for manual reading practice.' },
            ].map(({ mode, color, desc }) => (
              <div key={mode} className="flex items-start gap-3">
                <span className="font-bold shrink-0 w-28" style={{ color }}>{mode}</span>
                <span className="text-white/50 text-[11px] leading-snug">{desc}</span>
              </div>
            ))}
          </div>
        </Section>

        {/* ── S06: DIRECTION FILTER ── */}
        <Section label="06 — Direction Filter: Long / Short / Both">
          <h2 className="text-2xl font-extrabold mb-2">
            Aligning Signals with HTF Bias
          </h2>
          <p className="text-gray-400 mb-5 leading-relaxed">
            The Direction filter gates signals by side. It is the fastest way to align
            CIPHER with your higher-timeframe bias — without changing your Signal Engine
            mode or touching any other setting.
          </p>
          <Anim6Direction />
          <div className="mt-4 rounded-lg border-l-4 border-amber-400 bg-amber-400/6 px-4 py-3">
            <p className="text-sm text-amber-300 leading-relaxed">
              If your HTF structure is bearish, setting Direction to Short Only means
              every long signal is blocked before it reaches the conviction check.
              You are not missing signals — you are removing the ones that contradict
              your bias by design.
            </p>
          </div>
        </Section>

        {/* ── S07: 4-FACTOR CONVICTION SCORE ── */}
        <Section label="07 — The 4-Factor Conviction Score">
          <h2 className="text-2xl font-extrabold mb-2">
            How Strong Is This Signal?
          </h2>
          <p className="text-gray-400 mb-5 leading-relaxed">
            Every signal that passes the origin and direction gates is scored against
            four market factors. The score (0&ndash;4) determines whether the signal
            is standard or strong, and whether it survives the Strong Only gate.
          </p>
          <Anim7Conviction />
          <div className="mt-5 rounded-lg border border-white/8 bg-white/2 p-4 font-mono text-xs space-y-2">
            <div className="text-white/40 text-[10px] tracking-widest uppercase mb-1">4 Conviction Factors</div>
            {[
              { factor: 'Ribbon Stacked', threshold: 'Bull stack for long / Bear for short', color: TEAL },
              { factor: 'ADX > 20',       threshold: 'Trend has minimum strength',           color: TEAL },
              { factor: 'Volume > 1.0×',  threshold: 'Volume above average at signal bar',   color: TEAL },
              { factor: 'Health > 50%',   threshold: 'Momentum health above midpoint',       color: TEAL },
            ].map(({ factor, threshold, color }) => (
              <div key={factor} className="flex items-center justify-between gap-2">
                <span className="font-bold" style={{ color }}>{factor}</span>
                <span className="text-white/35 text-[10px] text-right">{threshold}</span>
              </div>
            ))}
          </div>
        </Section>

        {/* ── S08: STRONG ONLY ── */}
        <Section label="08 — Strong Only: When 3+/4 Is Required">
          <h2 className="text-2xl font-extrabold mb-2">
            The Sniper Gate
          </h2>
          <p className="text-gray-400 mb-5 leading-relaxed">
            When Strong Only is enabled, signals with fewer than 3 conviction factors
            are blocked entirely. The visual marker changes too — strong signals get a
            larger label and a{' '}<span className="font-mono font-bold text-white">+</span>{' '}
            suffix. This is the setting you saw in the screenshots: <span className="font-mono text-white">Long +</span>{' '}
            and <span className="font-mono text-white">Short +</span>.
          </p>
          <Anim8StrongOnly />
          <div className="mt-4 rounded-lg border border-white/8 bg-white/2 p-4 text-sm text-white/60 leading-relaxed">
            Strong Only does not change what CIPHER sees. It changes what CIPHER shows you.
            The same conviction scoring runs on every bar. Strong Only just adds a final
            filter that says: if fewer than 3 factors aligned, do not display this.
          </div>
        </Section>

        {/* ── S09: THE FINAL GATE ── */}
        <Section label="09 — The Final Gate: How buy_signal Is Born">
          <h2 className="text-2xl font-extrabold mb-2">
            One Line. One Decision.
          </h2>
          <p className="text-gray-400 mb-5 leading-relaxed">
            After origin, direction, conviction scoring, and the strong gate, CIPHER
            evaluates a single boolean expression. If it resolves to true, the signal
            fires and a label appears on your chart. If false, nothing happens.
          </p>
          <Anim9FinalGate />
          <div className="mt-5 rounded-lg border border-white/8 bg-white/2 p-4 font-mono text-xs space-y-2">
            <div className="text-white/40 text-[10px] tracking-widest uppercase mb-2">Final Gate Logic</div>
            <div className="text-white/70">buy_signal &nbsp;= (buy_px <span className="text-white/35">OR</span> buy_ts) <span className="text-white/35">AND</span> bull_conviction &gt;= min_conviction</div>
            <div className="text-white/70">sell_signal = (sell_px <span className="text-white/35">OR</span> sell_ts) <span className="text-white/35">AND</span> bear_conviction &gt;= min_conviction</div>
            <div className="border-t border-white/8 pt-2 text-white/35 text-[10px]">
              min_conviction = 0 (Strong Only OFF) or 3 (Strong Only ON or Sniper preset)
            </div>
          </div>
        </Section>

        {/* ── S10: STANDARD VS STRONG ON CHART ── */}
        <Section label="10 — Standard vs Strong: What You See on the Chart">
          <h2 className="text-2xl font-extrabold mb-2">
            Two Visual Weights. One Decision.
          </h2>
          <p className="text-gray-400 mb-5 leading-relaxed">
            When a signal fires, the chart label carries information about conviction.
            A standard signal fires with a smaller label. A strong signal (3+/4 factors)
            fires with a larger label and a{' '}
            <span className="font-mono font-bold text-white">+</span> suffix.
            Both are valid — but they tell you different things about the market alignment
            behind the signal.
          </p>
          <Anim10StandardVsStrong />
          <div className="mt-4 grid grid-cols-2 gap-3 text-xs font-mono">
            {[
              { label: 'Long / Short',   color: TEAL,    desc: 'Standard conviction (0–2/4). Signal passed origin, direction, and final gate. Less market alignment behind it.' },
              { label: 'Long + / Short +', color: AMBER, desc: 'Strong conviction (3–4/4). Ribbon, ADX, volume, and/or health all aligned. Higher-quality setup.' },
            ].map(({ label, color, desc }) => (
              <div key={label} className="rounded-lg border border-white/8 bg-white/2 p-3">
                <p className="font-bold mb-1.5" style={{ color }}>{label}</p>
                <p className="text-white/45 text-[11px] leading-snug">{desc}</p>
              </div>
            ))}
          </div>
        </Section>

        {/* ── S11: 13 CONTEXT TAGS ── */}
        <Section label="11 — The 13 Context Tags">
          <h2 className="text-2xl font-extrabold mb-2">
            Why Did This Signal Fire Here?
          </h2>
          <p className="text-gray-400 mb-5 leading-relaxed">
            Every signal carries a context tag in its tooltip. The tag is determined by
            a priority waterfall — CIPHER evaluates 13 possible context states and
            selects the most specific one. The tag tells you the market condition
            that made this signal relevant.
          </p>
          <Anim11ContextTags />
          <div className="mt-4 rounded-lg border-l-4 border-amber-400 bg-amber-400/6 px-4 py-3">
            <p className="text-sm text-amber-300 leading-relaxed">
              The tag is not a separate signal. It is context layered on top of the
              signal that already passed the pipeline. A{' '}
              <span className="font-mono font-bold">Sweep + FVG</span> tag does not mean
              the signal is stronger than a{' '}
              <span className="font-mono font-bold">Trend</span> tag — it means the
              specific market condition at that bar was a sweep with FVG confluence.
            </p>
          </div>
        </Section>

        {/* ── S12: LAST SIGNAL ROW ── */}
        <Section label="12 — Last Signal Row: Freshness States">
          <h2 className="text-2xl font-extrabold mb-2">
            How Old Is the Most Recent Signal?
          </h2>
          <p className="text-gray-400 mb-5 leading-relaxed">
            The Last Signal row in your Command Center tracks the most recent signal
            that passed your active filters. It shows direction, bars elapsed, and a
            freshness label that tells you how relevant the signal still is.
          </p>
          <Anim12LastSignal />
          <div className="mt-5 grid grid-cols-2 gap-3 text-xs font-mono">
            {[
              { state: 'JUST FIRED', bars: '≤1–3b', color: TEAL,    desc: 'Signal fired this bar or within the last 3 bars. Maximum freshness — full weight.' },
              { state: 'FRESH',      bars: '4–10b',      color: TEAL,    desc: 'Signal fired within the last 10 bars. Still actionable in most conditions.' },
              { state: 'ACTIVE',     bars: '11–30b',     color: AMBER,   desc: 'Signal is aging but still within 30 bars. Context is weakening.' },
              { state: 'AGING',      bars: '30b+',            color: MAGENTA, desc: 'Signal is stale. A new setup should be forming before you act on this.' },
            ].map(({ state, bars, color, desc }) => (
              <div key={state} className="rounded-lg border border-white/8 bg-white/2 p-3">
                <div className="flex items-center justify-between mb-1">
                  <span className="font-bold" style={{ color }}>{state}</span>
                  <span className="text-white/30 text-[10px]">{bars}</span>
                </div>
                <p className="text-white/45 text-[11px] leading-snug">{desc}</p>
              </div>
            ))}
          </div>
        </Section>

        {/* ── S13: VISUALS ONLY MODE ── */}
        <Section label="13 — Visuals Only Mode: Reading Without Signals">
          <h2 className="text-2xl font-extrabold mb-2">
            When You Want to Read, Not React
          </h2>
          <p className="text-gray-400 mb-5 leading-relaxed">
            Visuals Only mode disables all signal labels while keeping every other
            CIPHER tool active — ribbon, pulse line, tension fill, risk envelope,
            Command Center. This mode is used for manual chart reading practice
            and for operators who prefer to trigger entries themselves.
          </p>
          <Anim13VisualsOnly />
          <div className="mt-4 rounded-lg border border-white/8 bg-white/2 p-4 text-sm text-white/60 leading-relaxed">
            Visuals Only is not a downgrade. It is a discipline mode. An operator who
            can read the ribbon, pulse, and tension correctly without signal labels
            is reading the same information CIPHER uses to generate those labels.
            The labels are a convenience — the chart tools are the intelligence.
          </div>
        </Section>

        {/* ── S14: SIX MISTAKES ── */}
        <Section label="14 — Six Common Signal Philosophy Mistakes">
          <h2 className="text-2xl font-extrabold mb-2">
            What Operators Get Wrong
          </h2>
          <p className="text-gray-400 mb-6 leading-relaxed">
            These are the six most common mistakes made by traders who have CIPHER
            but have not understood the signal philosophy behind it.
          </p>
          <div className="space-y-3">
            {[
              {
                n: '01',
                title: 'Treating silence as malfunction',
                body: 'When CIPHER shows no signal, many traders assume the indicator is broken or the settings are wrong. CIPHER is silent because the pipeline found a reason to block. Silence is the filter working correctly — not a bug.',
              },
              {
                n: '02',
                title: 'Using All Signals mode with no HTF context',
                body: 'All Signals mode enables both PX and TS simultaneously. Without a clear HTF bias to validate them against, you will take continuation signals in ranges and reversal signals in trends. The engine needs operator context to be useful.',
              },
              {
                n: '03',
                title: 'Ignoring the context tag',
                body: 'Two signals with the same direction and same conviction score can mean very different things. A "Sweep + FVG" tag and a "Momentum" tag are not equivalent. The tag tells you the specific structural condition. Read it.',
              },
              {
                n: '04',
                title: 'Chasing AGING signals',
                body: 'When the Last Signal row shows AGING, the setup that generated it is 30+ bars in the past. Taking action on an AGING signal without a new setup forming is not executing the CIPHER philosophy — it is trading on stale information.',
              },
              {
                n: '05',
                title: 'Enabling Strong Only to reduce losses, not to improve quality',
                body: 'Strong Only is a quality filter, not a loss prevention tool. Enabling it does not guarantee that the signals that remain will be profitable. It means those signals have 3+ factors aligned. You still need confluence, structure, and timing.',
              },
              {
                n: '06',
                title: 'Treating a 2/4 signal as equivalent to a 4/4 signal',
                body: 'Both signals passed the pipeline but they did not pass with equal evidence. A 4/4 signal has all four market dimensions aligned behind it. A 2/4 signal has two. That difference matters for position sizing, stop placement, and conviction management.',
              },
            ].map(({ n, title, body }) => (
              <div key={n} className="rounded-lg border border-red-500/25 bg-red-500/6 p-4">
                <div className="flex items-start gap-3">
                  <span className="font-mono text-xs font-bold text-red-400/60 mt-0.5 shrink-0">{n}</span>
                  <div>
                    <p className="text-sm font-bold text-red-400 mb-1">{title}</p>
                    <p className="text-xs text-white/55 leading-relaxed">{body}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </Section>

        {/* ── S15: CHEAT SHEET ── */}
        <Section label="15 — Cheat Sheet">
          <h2 className="text-2xl font-extrabold mb-5">
            Signal Philosophy at a Glance
          </h2>
          <div className="rounded-xl border border-white/10 bg-white/2 divide-y divide-white/6">

            {/* Signal Origins */}
            <div className="p-4 space-y-2">
              <p className="text-[10px] font-mono font-bold tracking-widest text-amber-400/60 uppercase mb-3">Signal Origins</p>
              {[
                { origin: 'PX (Pulse Cross)', color: TEAL,    when: 'Price crosses Cipher Pulse', type: 'Trend / Continuation' },
                { origin: 'TS (Tension Snap)', color: MAGENTA, when: '4 conditions: stretch+snap+body+velocity', type: 'Reversal / Mean-reversion' },
              ].map(({ origin, color, when, type }) => (
                <div key={origin} className="flex items-start gap-3 text-xs font-mono">
                  <span className="font-bold w-32 shrink-0" style={{ color }}>{origin}</span>
                  <span className="text-white/45 flex-1">{when}</span>
                  <span className="text-white/30 text-[10px] text-right">{type}</span>
                </div>
              ))}
            </div>

            {/* Pipeline Gates */}
            <div className="p-4 space-y-2">
              <p className="text-[10px] font-mono font-bold tracking-widest text-amber-400/60 uppercase mb-3">Pipeline Gates (in order)</p>
              {[
                { n:'1', gate: 'Signal Engine', rule: 'All / Trend / Reversal / Visuals Only' },
                { n:'2', gate: 'Direction',     rule: 'Both / Long Only / Short Only' },
                { n:'3', gate: 'Conviction',    rule: '0–4 factors scored (ribbon, ADX, vol, health)' },
                { n:'4', gate: 'Strong Only',   rule: 'Gate at 3+/4 when ON (min_conviction = 3)' },
                { n:'5', gate: 'Final Gate',    rule: '(buy_px OR buy_ts) AND conviction >= min' },
              ].map(({ n, gate, rule }) => (
                <div key={n} className="flex items-start gap-3 text-xs font-mono">
                  <span className="text-white/25 w-4 shrink-0">{n}</span>
                  <span className="font-bold text-white/70 w-28 shrink-0">{gate}</span>
                  <span className="text-white/40 text-[11px]">{rule}</span>
                </div>
              ))}
            </div>

            {/* Conviction Factors */}
            <div className="p-4 space-y-2">
              <p className="text-[10px] font-mono font-bold tracking-widest text-amber-400/60 uppercase mb-3">4 Conviction Factors</p>
              {[
                { f: 'Ribbon Stacked', t: 'Stack direction matches signal' },
                { f: 'ADX > 20',       t: 'Minimum trend strength present' },
                { f: 'Volume > 1.0×',  t: 'Above-average volume on signal bar' },
                { f: 'Health > 50%',   t: 'Momentum health above midpoint' },
              ].map(({ f, t }) => (
                <div key={f} className="flex items-center gap-3 text-xs font-mono">
                  <span className="font-bold text-white/70 w-32 shrink-0">{f}</span>
                  <span className="text-white/40 text-[11px]">{t}</span>
                </div>
              ))}
            </div>

            {/* Signal Labels */}
            <div className="p-4 space-y-2">
              <p className="text-[10px] font-mono font-bold tracking-widest text-amber-400/60 uppercase mb-3">Signal Labels on Chart</p>
              <div className="flex items-center gap-6 text-xs font-mono">
                <span><span className="font-bold" style={{color:TEAL}}>Long / Short</span><span className="text-white/35 ml-2">0–2/4 conv — standard size label</span></span>
              </div>
              <div className="flex items-center gap-6 text-xs font-mono">
                <span><span className="font-bold" style={{color:AMBER}}>Long + / Short +</span><span className="text-white/35 ml-2">3–4/4 conv — larger label with + marker</span></span>
              </div>
            </div>

            {/* Freshness */}
            <div className="p-4">
              <p className="text-[10px] font-mono font-bold tracking-widest text-amber-400/60 uppercase mb-3">Last Signal Freshness</p>
              <div className="flex items-center gap-2 text-[11px] font-mono text-white/40 flex-wrap">
                {[
                  { label: 'JUST FIRED', color: TEAL },
                  { label: 'FRESH', color: TEAL },
                  { label: 'ACTIVE', color: AMBER },
                  { label: 'AGING', color: MAGENTA },
                ].map(({ label, color }, i, arr) => (
                  <span key={label}>
                    <span style={{ color }} className="font-bold">{label}</span>
                    {i < arr.length - 1 && <span className="text-white/20 mx-1">&rarr;</span>}
                  </span>
                ))}
                <span className="text-white/25 ml-2">(&le;3b / &le;10b / &le;30b / 30b+)</span>
              </div>
            </div>

          </div>
        </Section>

        {/* ── S16: SCENARIO GAME ── */}
        <Section label="16 — Scenario Game">
          <h2 className="text-2xl font-extrabold mb-2">
            Signal Architect: <span style={{ color: AMBER }}>5 Live Scenarios</span>
          </h2>
          <p className="text-gray-400 mb-6 leading-relaxed">
            Apply the signal pipeline to real situations. One correct answer per round.
          </p>

          {!gameDone ? (
            <div className="space-y-5">
              <div className="flex items-center justify-between text-xs font-mono text-white/35">
                <span>Round {gameStep + 1} of {gameRounds.length}</span>
                <span style={{ color: AMBER }}>{gameScore} correct</span>
              </div>
              <div className="w-full h-1 bg-white/8 rounded-full overflow-hidden">
                <div className="h-full rounded-full transition-all duration-500"
                  style={{ width: `${(gameStep / gameRounds.length) * 100}%`, background: AMBER }} />
              </div>
              <div className="rounded-xl border border-white/10 bg-white/2 p-5">
                <p className="text-xs font-mono font-bold tracking-widest text-amber-400/60 uppercase mb-3">Scenario</p>
                <p className="text-sm text-white/85 leading-relaxed">{gameRounds[gameStep].scenario}</p>
              </div>
              <div className="space-y-3">
                {gameRounds[gameStep].options.map(opt => {
                  const isSel = gameSelected === opt.id
                  let border = 'rgba(255,255,255,0.08)', bg = 'transparent', color = 'rgba(255,255,255,0.75)'
                  if (gameRevealed) {
                    if (opt.correct)    { border = TEAL + '70';    bg = 'rgba(38,166,154,0.10)';  color = '#fff' }
                    else if (isSel)     { border = MAGENTA + '70'; bg = 'rgba(239,83,80,0.10)';   color = '#fff' }
                    else                { color = 'rgba(255,255,255,0.28)' }
                  } else if (isSel)     { border = AMBER + '70';   bg = 'rgba(255,179,0,0.08)' }
                  return (
                    <button key={opt.id} onClick={() => handleGameSelect(opt.id)} disabled={gameRevealed}
                      className="w-full text-left rounded-xl border p-4 text-sm leading-relaxed transition-all duration-200 disabled:cursor-default"
                      style={{ borderColor: border, background: bg, color }}>
                      <span className="font-mono font-bold text-xs mr-2 opacity-50">{opt.id.toUpperCase()}.</span>
                      {opt.text}
                    </button>
                  )
                })}
              </div>
              {gameRevealed && (
                <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
                  className="rounded-xl border border-white/10 bg-white/2 p-4">
                  <p className="text-xs font-mono font-bold tracking-widest mb-2"
                    style={{ color: gameRounds[gameStep].options.find(o => o.id === gameSelected)?.correct ? TEAL : MAGENTA }}>
                    {gameRounds[gameStep].options.find(o => o.id === gameSelected)?.correct ? 'CORRECT' : 'INCORRECT'}
                  </p>
                  <p className="text-sm text-white/65 leading-relaxed">
                    {gameRounds[gameStep].options.find(o => o.id === gameSelected)?.explanation}
                  </p>
                  <button onClick={handleGameNext}
                    className="mt-4 px-5 py-2 rounded-lg text-xs font-bold font-mono tracking-widest transition-opacity hover:opacity-80"
                    style={{ background: AMBER, color: '#060a12' }}>
                    {gameStep < gameRounds.length - 1 ? 'NEXT ROUND →' : 'SEE RESULTS'}
                  </button>
                </motion.div>
              )}
            </div>
          ) : (
            <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}
              className="rounded-xl border border-white/10 bg-white/2 p-6 text-center space-y-4">
              <p className="text-xs font-mono text-white/35 tracking-widest uppercase">Game Complete</p>
              <p className="text-4xl font-extrabold" style={{ color: AMBER }}>
                {gameScore}<span className="text-white/30 text-2xl"> / {gameRounds.length}</span>
              </p>
              <p className="text-sm text-white/55">
                {gameScore === 5 ? 'Perfect. You understand exactly how CIPHER qualifies signals.' :
                 gameScore >= 3 ? 'Solid. Review the scenarios you missed before the quiz.' :
                 'Review the pipeline sections above and try the quiz.'}
              </p>
            </motion.div>
          )}
        </Section>

        {/* ── S17: QUIZ + CERTIFICATE ── */}
        <Section label="17 — Knowledge Check">
          <h2 className="text-2xl font-extrabold mb-2">
            Signal Architect <span style={{ color: AMBER }}>Certification</span>
          </h2>
          <p className="text-gray-400 mb-6 leading-relaxed">
            8 questions. Score 66% or above to earn the Signal Architect certificate.
          </p>

          {!quizDone ? (
            <div className="space-y-5">
              <div className="flex items-center justify-between text-xs font-mono text-white/35">
                <span>Question {quizStep + 1} of {quizQuestions.length}</span>
                <span style={{ color: AMBER }}>{quizScore} correct</span>
              </div>
              <div className="w-full h-1 bg-white/8 rounded-full overflow-hidden">
                <div className="h-full rounded-full transition-all duration-500"
                  style={{ width: `${(quizStep / quizQuestions.length) * 100}%`, background: AMBER }} />
              </div>
              <div className="rounded-xl border border-white/10 bg-white/2 p-5">
                <p className="text-xs font-mono font-bold tracking-widest text-amber-400/60 uppercase mb-3">
                  Question {quizStep + 1}
                </p>
                <p className="text-sm text-white/85 leading-relaxed">{quizQuestions[quizStep].question}</p>
              </div>
              <div className="space-y-3">
                {quizQuestions[quizStep].options.map(opt => {
                  const isSel = quizSelected === opt.id
                  const isCorrect = opt.id === quizQuestions[quizStep].correct
                  let border = 'rgba(255,255,255,0.08)', bg = 'transparent', color = 'rgba(255,255,255,0.75)'
                  if (quizRevealed) {
                    if (isCorrect)  { border = TEAL + '70';    bg = 'rgba(38,166,154,0.10)';  color = '#fff' }
                    else if (isSel) { border = MAGENTA + '70'; bg = 'rgba(239,83,80,0.10)';   color = '#fff' }
                    else            { color = 'rgba(255,255,255,0.28)' }
                  } else if (isSel) { border = AMBER + '70';   bg = 'rgba(255,179,0,0.08)' }
                  return (
                    <button key={opt.id} onClick={() => handleQuizSelect(opt.id)} disabled={quizRevealed}
                      className="w-full text-left rounded-xl border p-4 text-sm leading-relaxed transition-all duration-200 disabled:cursor-default"
                      style={{ borderColor: border, background: bg, color }}>
                      <span className="font-mono font-bold text-xs mr-2 opacity-50">{opt.id.toUpperCase()}.</span>
                      {opt.text}
                    </button>
                  )
                })}
              </div>
              {quizRevealed && (
                <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
                  className="rounded-xl border border-white/10 bg-white/2 p-4">
                  <p className="text-xs font-mono font-bold tracking-widest mb-2"
                    style={{ color: quizSelected === quizQuestions[quizStep].correct ? TEAL : MAGENTA }}>
                    {quizSelected === quizQuestions[quizStep].correct ? 'CORRECT' : 'INCORRECT'}
                  </p>
                  <p className="text-sm text-white/65 leading-relaxed">{quizQuestions[quizStep].explanation}</p>
                  <button onClick={handleQuizNext}
                    className="mt-4 px-5 py-2 rounded-lg text-xs font-bold font-mono tracking-widest transition-opacity hover:opacity-80"
                    style={{ background: AMBER, color: '#060a12' }}>
                    {quizStep < quizQuestions.length - 1 ? 'NEXT QUESTION →' : 'SEE RESULTS'}
                  </button>
                </motion.div>
              )}
            </div>
          ) : (
            <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
              <div className="rounded-xl border border-white/10 bg-white/2 p-6 text-center space-y-3">
                <p className="text-xs font-mono text-white/35 tracking-widest uppercase">Quiz Complete</p>
                <p className="text-4xl font-extrabold" style={{ color: quizPassed ? TEAL : MAGENTA }}>
                  {Math.round((quizScore / quizQuestions.length) * 100)}%
                  <span className="text-white/30 text-xl ml-2">{quizScore}/{quizQuestions.length}</span>
                </p>
                <p className="text-sm" style={{ color: quizPassed ? TEAL : MAGENTA }}>
                  {quizPassed ? 'Passed — Signal Architect certification earned.' : 'Below 66% — review and retry when ready.'}
                </p>
              </div>

              {quizPassed && (
                <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.3, duration: 0.5 }}
                  className="rounded-2xl p-px"
                  style={{ background: 'conic-gradient(from 180deg, #26A69A, #FFB300, #EF5350, #FFB300, #26A69A)' }}>
                  <div className="rounded-2xl p-8 text-center space-y-4"
                    style={{ background: 'linear-gradient(135deg, #0a0f1a 0%, #060a12 100%)' }}>
                    <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-amber-400/30 bg-amber-400/8">
                      <span className="text-amber-400 text-sm">&#9812;</span>
                      <span className="text-amber-400 text-xs font-bold tracking-widest font-mono">ATLAS ACADEMY</span>
                      <span className="text-amber-400 text-sm">&#9812;</span>
                    </div>
                    <div>
                      <p className="text-xs font-mono text-white/30 tracking-widest uppercase mb-2">Certificate of Completion</p>
                      <h3 className="text-2xl font-extrabold" style={{ color: AMBER }}>Signal Architect</h3>
                      <p className="text-sm text-white/50 mt-1">Level 11 &middot; Lesson 8 &middot; The Signal Philosophy</p>
                    </div>
                    <div className="border-t border-b border-white/8 py-4 space-y-1">
                      <p className="text-xs text-white/35 font-mono">This certifies mastery of</p>
                      <p className="text-sm text-white/70 leading-relaxed">
                        CIPHER&apos;s signal qualification pipeline &mdash; dual signal origins, direction and engine filters,
                        4-factor conviction scoring, the Strong Only gate, context tag priority waterfall, and freshness states.
                      </p>
                    </div>
                    <div className="font-mono text-xs space-y-1">
                      <p className="text-white/25">Certificate Code</p>
                      <p className="font-bold tracking-widest" style={{ color: AMBER }}>{certCode}</p>
                    </div>
                  </div>
                </motion.div>
              )}
            </motion.div>
          )}
        </Section>

      </div>

      {/* ── GOLD FOOTER ── */}
      <div className="border-t border-white/6 mt-8 py-12 text-center"
        style={{ background: 'linear-gradient(to bottom, transparent, rgba(255,179,0,0.04))' }}>
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-amber-400/20 bg-amber-400/5 mb-4">
          <span className="text-amber-400 text-xs">&#9812;</span>
          <span className="text-amber-400 text-xs font-bold tracking-widest font-mono">CIPHER PRO MASTERY</span>
          <span className="text-amber-400 text-xs">&#9812;</span>
        </div>
        <p className="text-sm text-white/30 font-mono">Level 11 &middot; Lesson 8 of 20</p>
        <p className="text-xs text-white/20 mt-2 font-mono tracking-widest">
          &ldquo;We Show You WHY, Not Just What.&rdquo;
        </p>
      </div>

    </main>
    </>
  )
}

// ─── ANIM 5: SIGNAL ENGINE 4 MODES ────────────────────────────────────────────
function Anim5SignalEngine() {
  const [mode, setMode] = useState<'all'|'trend'|'reversal'|'visuals'>('all')

  const MODES = [
    { id: 'all',      label: 'ALL SIGNALS',  color: TEAL,    px: true,  ts: true  },
    { id: 'trend',    label: 'TREND',        color: TEAL,    px: true,  ts: false },
    { id: 'reversal', label: 'REVERSAL',     color: MAGENTA, px: false, ts: true  },
    { id: 'visuals',  label: 'VISUALS ONLY', color: AMBER,   px: false, ts: false },
  ] as const

  const cfg = MODES.find(m => m.id === mode)!

  const draw = (ctx: CanvasRenderingContext2D, w: number, h: number, frame: number) => {
    drawGrid(ctx, w, h)
    const pulse = Math.sin(frame * 0.05) * 0.5 + 0.5
    const py = (n: number) => h * (1 - n * 0.72 - 0.14)
    const bW = w * 0.048

    // Pulse line
    const pulseY = py(0.38)
    ctx.save(); ctx.strokeStyle = TEAL; ctx.globalAlpha = 0.4 + pulse * 0.15; ctx.lineWidth = 1.5; ctx.setLineDash([5, 3])
    ctx.beginPath(); ctx.moveTo(0, pulseY); ctx.lineTo(w, pulseY); ctx.stroke()
    ctx.setLineDash([]); ctx.restore()

    // Tension fill hint
    ctx.fillStyle = `rgba(239,83,80,${0.06 + pulse * 0.04})`
    ctx.fillRect(0, py(0.82), w, py(0.68) - py(0.82))

    // Candles with signals
    const CANDLES: { x: number; o: number; h: number; l: number; c: number; sigType?: 'px'|'ts' }[] = [
      { x: 0.08, o: 0.52, h: 0.57, l: 0.48, c: 0.55 },
      { x: 0.18, o: 0.55, h: 0.60, l: 0.51, c: 0.57 },
      { x: 0.28, o: 0.57, h: 0.62, l: 0.53, c: 0.60 },
      { x: 0.38, o: 0.60, h: 0.65, l: 0.56, c: 0.63, sigType: 'px' }, // PX fires
      { x: 0.48, o: 0.63, h: 0.68, l: 0.59, c: 0.66 },
      { x: 0.58, o: 0.66, h: 0.72, l: 0.62, c: 0.70 },
      { x: 0.68, o: 0.70, h: 0.76, l: 0.66, c: 0.72 },
      { x: 0.78, o: 0.72, h: 0.78, l: 0.64, c: 0.66, sigType: 'ts' }, // TS fires (snap)
      { x: 0.88, o: 0.66, h: 0.68, l: 0.59, c: 0.61 },
    ]

    CANDLES.forEach(c => {
      const cx  = w * c.x
      const showSig = c.sigType === 'px' ? cfg.px : c.sigType === 'ts' ? cfg.ts : false
      const sigColor = c.sigType === 'px' ? TEAL : MAGENTA
      const baseCol = c.c >= c.o ? 'rgba(38,166,154,0.5)' : 'rgba(239,83,80,0.5)'
      const dimmed = c.sigType && !showSig

      ctx.globalAlpha = dimmed ? 0.3 : 1.0
      ctx.strokeStyle = showSig ? sigColor : baseCol; ctx.lineWidth = showSig ? 1.5 : 1
      ctx.beginPath(); ctx.moveTo(cx, py(c.h)); ctx.lineTo(cx, py(c.l)); ctx.stroke()
      ctx.fillStyle = showSig ? sigColor : baseCol
      const yT = py(Math.max(c.o, c.c)); const yB = py(Math.min(c.o, c.c))
      ctx.fillRect(cx - bW / 2, yT, bW, Math.max(2, yB - yT))
      ctx.globalAlpha = 1

      if (c.sigType && showSig) {
        const isLong = c.sigType === 'px'
        ctx.save(); ctx.shadowColor = sigColor; ctx.shadowBlur = 10 + pulse * 6
        ctx.fillStyle = sigColor; ctx.strokeStyle = '#fff'; ctx.lineWidth = 1
        const lY = isLong ? py(c.l) + 8 : py(c.h) - 32
        roundRect(ctx, cx - 22, lY, 44, 24, 5); ctx.fill(); ctx.stroke()
        ctx.fillStyle = '#fff'; ctx.font = 'bold 9px monospace'; ctx.textAlign = 'center'
        ctx.fillText(isLong ? '▲ Long' : '▼ Short', cx, lY + 16)
        ctx.restore()
      }

      if (c.sigType && !showSig) {
        // Blocked — grey X
        ctx.fillStyle = 'rgba(255,255,255,0.15)'; ctx.font = 'bold 11px monospace'; ctx.textAlign = 'center'
        const xY = c.sigType === 'px' ? py(c.l) + 18 : py(c.h) - 20
        ctx.fillText('✕', cx, xY)
      }
    })
    ctx.textAlign = 'left'

    // Mode badge
    ctx.save()
    ctx.fillStyle = cfg.color + '20'; ctx.strokeStyle = cfg.color + '60'; ctx.lineWidth = 1
    roundRect(ctx, 10, 10, 110, 22, 5); ctx.fill(); ctx.stroke()
    ctx.fillStyle = cfg.color; ctx.font = 'bold 10px monospace'
    ctx.fillText(cfg.label, 18, 25)
    ctx.restore()

    // PX / TS status pills
    ;[{ label: 'PX', on: cfg.px }, { label: 'TS', on: cfg.ts }].forEach(({ label, on }, i) => {
      const px2 = 130 + i * 52
      ctx.fillStyle = on ? 'rgba(38,166,154,0.15)' : 'rgba(255,255,255,0.04)'
      ctx.strokeStyle = on ? 'rgba(38,166,154,0.5)' : 'rgba(255,255,255,0.1)'; ctx.lineWidth = 1
      roundRect(ctx, px2, 10, 44, 22, 5); ctx.fill(); ctx.stroke()
      ctx.fillStyle = on ? TEAL : 'rgba(255,255,255,0.2)'; ctx.font = 'bold 10px monospace'
      ctx.fillText(label + (on ? ' ✓' : ' ✕'), px2 + 8, 25)
    })
  }

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-4 gap-2">
        {MODES.map(m => (
          <button
            key={m.id}
            onClick={() => setMode(m.id)}
            className="py-2 rounded-lg text-[10px] font-bold font-mono tracking-wider border transition-all"
            style={{
              background: mode === m.id ? m.color + '18' : 'transparent',
              color: mode === m.id ? m.color : 'rgba(255,255,255,0.3)',
              borderColor: mode === m.id ? m.color + '55' : 'rgba(255,255,255,0.08)',
            }}
          >{m.label}</button>
        ))}
      </div>
      <AnimScene draw={draw} deps={[mode]} height={210} />
    </div>
  )
}

// ─── ANIM 6: DIRECTION FILTER ──────────────────────────────────────────────────
function Anim6Direction() {
  const [dir, setDir] = useState<'both'|'long'|'short'>('both')

  const draw = (ctx: CanvasRenderingContext2D, w: number, h: number, frame: number) => {
    drawGrid(ctx, w, h)
    const pulse = Math.sin(frame * 0.05) * 0.5 + 0.5
    const py = (n: number) => h * (1 - n * 0.72 - 0.14)
    const bW = w * 0.05
    const pulseY = py(0.42)

    ctx.save(); ctx.strokeStyle = TEAL; ctx.globalAlpha = 0.4; ctx.lineWidth = 1.5; ctx.setLineDash([5, 3])
    ctx.beginPath(); ctx.moveTo(0, pulseY); ctx.lineTo(w, pulseY); ctx.stroke()
    ctx.setLineDash([]); ctx.restore()

    const SIGS: { x: number; o: number; h: number; l: number; c: number; side: 'long'|'short' }[] = [
      { x: 0.15, o: 0.48, h: 0.54, l: 0.44, c: 0.52, side: 'long'  },
      { x: 0.35, o: 0.52, h: 0.58, l: 0.48, c: 0.50, side: 'long'  },
      { x: 0.55, o: 0.62, h: 0.67, l: 0.56, c: 0.59, side: 'short' },
      { x: 0.75, o: 0.56, h: 0.61, l: 0.51, c: 0.54, side: 'long'  },
    ]

    // Filler candles
    const FILLERS = [
      { x: 0.08, o: 0.45, h: 0.49, l: 0.42, c: 0.47 },
      { x: 0.25, o: 0.50, h: 0.55, l: 0.47, c: 0.53 },
      { x: 0.45, o: 0.55, h: 0.59, l: 0.51, c: 0.57 },
      { x: 0.65, o: 0.60, h: 0.64, l: 0.56, c: 0.58 },
      { x: 0.85, o: 0.55, h: 0.59, l: 0.51, c: 0.53 },
    ]
    FILLERS.forEach(c => {
      const cx = w * c.x; const bull = c.c >= c.o
      ctx.strokeStyle = bull ? 'rgba(38,166,154,0.35)' : 'rgba(239,83,80,0.35)'; ctx.lineWidth = 1
      ctx.beginPath(); ctx.moveTo(cx, py(c.h)); ctx.lineTo(cx, py(c.l)); ctx.stroke()
      ctx.fillStyle = bull ? 'rgba(38,166,154,0.35)' : 'rgba(239,83,80,0.35)'
      ctx.fillRect(cx - bW / 2, py(Math.max(c.o, c.c)), bW, Math.max(2, py(Math.min(c.o, c.c)) - py(Math.max(c.o, c.c))))
    })

    SIGS.forEach(c => {
      const cx = w * c.x
      const allowed = dir === 'both' || dir === c.side
      const sigColor = c.side === 'long' ? TEAL : MAGENTA
      ctx.globalAlpha = allowed ? 1 : 0.25
      ctx.strokeStyle = sigColor; ctx.lineWidth = 1.5
      ctx.beginPath(); ctx.moveTo(cx, py(c.h)); ctx.lineTo(cx, py(c.l)); ctx.stroke()
      ctx.fillStyle = sigColor
      ctx.fillRect(cx - bW / 2, py(Math.max(c.o, c.c)), bW, Math.max(2, py(Math.min(c.o, c.c)) - py(Math.max(c.o, c.c))))
      ctx.globalAlpha = 1

      if (allowed) {
        ctx.save(); ctx.shadowColor = sigColor; ctx.shadowBlur = 10 + pulse * 6
        ctx.fillStyle = sigColor; ctx.strokeStyle = '#fff'; ctx.lineWidth = 1
        const lY = c.side === 'long' ? py(c.l) + 8 : py(c.h) - 32
        roundRect(ctx, cx - 22, lY, 44, 24, 5); ctx.fill(); ctx.stroke()
        ctx.fillStyle = '#fff'; ctx.font = 'bold 9px monospace'; ctx.textAlign = 'center'
        ctx.fillText(c.side === 'long' ? '▲ Long' : '▼ Short', cx, lY + 16)
        ctx.restore()
      } else {
        ctx.fillStyle = 'rgba(255,255,255,0.15)'; ctx.font = 'bold 13px monospace'; ctx.textAlign = 'center'
        const xY = c.side === 'long' ? py(c.l) + 20 : py(c.h) - 14
        ctx.fillText('✕', cx, xY)
      }
    })
    ctx.textAlign = 'left'

    // Direction badge
    const dColor = dir === 'both' ? TEAL : dir === 'long' ? TEAL : MAGENTA
    const dLabel = dir === 'both' ? 'BOTH' : dir === 'long' ? 'LONG ONLY' : 'SHORT ONLY'
    ctx.fillStyle = dColor + '20'; ctx.strokeStyle = dColor + '60'; ctx.lineWidth = 1
    roundRect(ctx, 10, 10, 100, 22, 5); ctx.fill(); ctx.stroke()
    ctx.fillStyle = dColor; ctx.font = 'bold 10px monospace'
    ctx.fillText(dLabel, 18, 25)
  }

  return (
    <div className="space-y-3">
      <div className="flex gap-2">
        {([['both','BOTH',TEAL],['long','LONG ONLY',TEAL],['short','SHORT ONLY',MAGENTA]] as const).map(([v,l,c]) => (
          <button
            key={v}
            onClick={() => setDir(v)}
            className="flex-1 py-2 rounded-lg text-xs font-bold font-mono tracking-wider border transition-all"
            style={{
              background: dir === v ? c + '18' : 'transparent',
              color: dir === v ? c : 'rgba(255,255,255,0.3)',
              borderColor: dir === v ? c + '55' : 'rgba(255,255,255,0.08)',
            }}
          >{l}</button>
        ))}
      </div>
      <AnimScene draw={draw} deps={[dir]} height={210} />
      <div className="rounded-lg border border-white/8 bg-white/2 p-3 text-xs text-white/55 leading-relaxed">
        {dir === 'both' && 'Both long and short candidates pass the direction gate. All signals that clear origin and conviction will appear.'}
        {dir === 'long' && <>Short candidates are blocked at the direction gate. Only <span className="text-white font-semibold">long</span> signals that clear origin and conviction appear. Use when HTF bias is bullish.</>}
        {dir === 'short' && <>Long candidates are blocked at the direction gate. Only <span className="text-white font-semibold">short</span> signals that clear origin and conviction appear. Use when HTF bias is bearish.</>}
      </div>
    </div>
  )
}

// ─── ANIM 7: 4-FACTOR CONVICTION ──────────────────────────────────────────────
function Anim7Conviction() {
  const [scenario, setScenario] = useState(0)

  const SCENARIOS = [
    {
      label: '4/4 — Maximum',
      ribbon: true,  adx: true,  vol: true,  health: true,
      score: 4, color: TEAL,
      note: 'All four factors aligned. CIPHER has maximum confidence. Strong signal fires regardless of Strong Only setting.',
    },
    {
      label: '3/4 — Strong',
      ribbon: true,  adx: true,  vol: true,  health: false,
      score: 3, color: TEAL,
      note: 'Three factors aligned — ribbon, ADX, and volume confirm. Health below 50%. Passes Strong Only gate. Fires as Long +.',
    },
    {
      label: '2/4 — Standard',
      ribbon: true,  adx: false, vol: true,  health: false,
      score: 2, color: AMBER,
      note: 'Two factors: ribbon stacked and volume above average. ADX below 20 (weak trend), health below 50%. Blocked by Strong Only — fires only when Strong Only is OFF.',
    },
    {
      label: '1/4 — Weak',
      ribbon: false, adx: false, vol: false, health: true,
      score: 1, color: MAGENTA,
      note: 'Only momentum health passes. Ribbon not stacked, ADX weak, volume thin. Fires only when Strong Only is OFF — and should be treated as low confidence.',
    },
  ]

  const sc = SCENARIOS[scenario]
  const factors = [
    { key: 'ribbon', label: 'Ribbon Stacked', pass: sc.ribbon, val: sc.ribbon ? 'BULL stack ✓' : 'Not stacked ✗', threshold: 'Ribbon stacked with signal direction' },
    { key: 'adx',    label: 'ADX > 20',       pass: sc.adx,    val: sc.adx    ? 'ADX 32 ✓'    : 'ADX 14 ✗',      threshold: 'Minimum trend strength' },
    { key: 'vol',    label: 'Volume > 1.0×',  pass: sc.vol,    val: sc.vol    ? '1.6× avg ✓'  : '0.5× avg ✗',    threshold: 'Above-average volume' },
    { key: 'health', label: 'Health > 50%',   pass: sc.health, val: sc.health ? '67% ✓'       : '38% ✗',         threshold: 'Momentum health above midpoint' },
  ]

  const draw = (ctx: CanvasRenderingContext2D, w: number, h: number, frame: number) => {
    drawGrid(ctx, w, h)
    const pulse = Math.sin(frame * 0.06) * 0.5 + 0.5
    const N = 4
    const padX = 20
    const fW = (w - padX * 2) / N
    const fH = h * 0.55
    const fY = (h - fH) / 2

    factors.forEach((f, i) => {
      const cx = padX + i * fW + fW / 2
      const bX = padX + i * fW + 8
      const bW2 = fW - 16
      const bColor = f.pass ? TEAL : 'rgba(255,255,255,0.06)'
      const bgColor = f.pass ? 'rgba(38,166,154,0.09)' : 'rgba(255,255,255,0.02)'

      ctx.fillStyle = bgColor; ctx.strokeStyle = bColor; ctx.lineWidth = f.pass ? 1.5 : 1
      roundRect(ctx, bX, fY, bW2, fH, 8); ctx.fill(); ctx.stroke()

      // Icon
      ctx.save()
      if (f.pass) { ctx.shadowColor = TEAL; ctx.shadowBlur = 8 + pulse * 6 }
      ctx.fillStyle = f.pass ? TEAL : 'rgba(255,255,255,0.2)'
      ctx.font = `bold 18px monospace`; ctx.textAlign = 'center'
      ctx.fillText(f.pass ? '✓' : '✗', cx, fY + fH * 0.42)
      ctx.restore()

      // Label
      ctx.fillStyle = f.pass ? 'rgba(38,166,154,0.8)' : 'rgba(255,255,255,0.25)'
      ctx.font = 'bold 8px monospace'; ctx.textAlign = 'center'
      const words = f.label.split(' ')
      words.forEach((word, wi) => ctx.fillText(word, cx, fY + 14 + wi * 10))

      // Value
      ctx.fillStyle = f.pass ? 'rgba(38,166,154,0.6)' : 'rgba(255,255,255,0.2)'
      ctx.font = '8px monospace'
      ctx.fillText(f.val, cx, fY + fH - 10)
    })

    // Score display
    ctx.font = `bold 28px monospace`; ctx.textAlign = 'center'
    ctx.fillStyle = sc.color
    ctx.fillText(`${sc.score}/4`, w / 2, h - 18)
    ctx.textAlign = 'left'
  }

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
        {SCENARIOS.map((s, i) => (
          <button
            key={i}
            onClick={() => setScenario(i)}
            className="py-2 rounded-lg text-[10px] font-bold font-mono tracking-wider border transition-all"
            style={{
              background: scenario === i ? s.color + '18' : 'transparent',
              color: scenario === i ? s.color : 'rgba(255,255,255,0.3)',
              borderColor: scenario === i ? s.color + '55' : 'rgba(255,255,255,0.08)',
            }}
          >{s.label}</button>
        ))}
      </div>
      <AnimScene draw={draw} deps={[scenario]} height={200} />
      <div className="rounded-lg border border-white/8 bg-white/2 p-3 text-xs text-white/55 leading-relaxed">
        {sc.note}
      </div>
    </div>
  )
}

// ─── ANIM 8: STRONG ONLY GATE ──────────────────────────────────────────────────
function Anim8StrongOnly() {
  const [strongOn, setStrongOn] = useState(false)

  // Three signals: 4/4, 3/4, 2/4
  const SIGS = [
    { x: 0.20, conv: 4, label: 'Long +', color: TEAL,  size: 'large' },
    { x: 0.50, conv: 3, label: 'Long +', color: TEAL,  size: 'large' },
    { x: 0.80, conv: 2, label: 'Long',   color: TEAL,  size: 'small' },
  ]

  const draw = (ctx: CanvasRenderingContext2D, w: number, h: number, frame: number) => {
    drawGrid(ctx, w, h)
    const pulse = Math.sin(frame * 0.05) * 0.5 + 0.5
    const py = (n: number) => h * (1 - n * 0.68 - 0.16)
    const bW = w * 0.05
    const pulseY = py(0.40)

    ctx.save(); ctx.strokeStyle = TEAL; ctx.globalAlpha = 0.35; ctx.lineWidth = 1.5; ctx.setLineDash([5, 3])
    ctx.beginPath(); ctx.moveTo(0, pulseY); ctx.lineTo(w, pulseY); ctx.stroke()
    ctx.setLineDash([]); ctx.restore()

    // Filler candles
    const fillers = [
      {x:0.08,o:0.44,h:0.48,l:0.41,c:0.46},{x:0.35,o:0.50,h:0.55,l:0.47,c:0.53},
      {x:0.65,o:0.56,h:0.60,l:0.52,c:0.58},{x:0.92,o:0.52,h:0.56,l:0.49,c:0.54},
    ]
    fillers.forEach(c => {
      const cx = w * c.x; const bull = c.c >= c.o
      ctx.strokeStyle = bull ? 'rgba(38,166,154,0.3)' : 'rgba(239,83,80,0.3)'; ctx.lineWidth = 1
      ctx.beginPath(); ctx.moveTo(cx, py(c.h)); ctx.lineTo(cx, py(c.l)); ctx.stroke()
      ctx.fillStyle = bull ? 'rgba(38,166,154,0.3)' : 'rgba(239,83,80,0.3)'
      ctx.fillRect(cx - bW/2, py(Math.max(c.o,c.c)), bW, Math.max(2, py(Math.min(c.o,c.c))-py(Math.max(c.o,c.c))))
    })

    const candleBase = [
      {x:0.20,o:0.42,h:0.47,l:0.38,c:0.45},
      {x:0.50,o:0.48,h:0.53,l:0.44,c:0.51},
      {x:0.80,o:0.54,h:0.59,l:0.50,c:0.57},
    ]
    candleBase.forEach((c, i) => {
      const sig = SIGS[i]
      const blocked = strongOn && sig.conv < 3
      ctx.globalAlpha = blocked ? 0.25 : 1
      ctx.strokeStyle = TEAL; ctx.lineWidth = blocked ? 1 : 1.5
      const cx = w * c.x
      ctx.beginPath(); ctx.moveTo(cx, py(c.h)); ctx.lineTo(cx, py(c.l)); ctx.stroke()
      ctx.fillStyle = TEAL
      ctx.fillRect(cx - bW/2, py(Math.max(c.o,c.c)), bW, Math.max(2, py(Math.min(c.o,c.c))-py(Math.max(c.o,c.c))))
      ctx.globalAlpha = 1

      if (!blocked) {
        const isLarge = sig.size === 'large'
        const lW = isLarge ? 52 : 44; const lH = isLarge ? 28 : 22
        ctx.save()
        ctx.shadowColor = TEAL; ctx.shadowBlur = (10 + pulse * 6) * (isLarge ? 1.4 : 1)
        ctx.fillStyle = TEAL; ctx.strokeStyle = '#fff'; ctx.lineWidth = isLarge ? 1.5 : 1
        roundRect(ctx, cx - lW/2, py(c.l) + 8, lW, lH, 5); ctx.fill(); ctx.stroke()
        ctx.fillStyle = '#fff'
        ctx.font = `bold ${isLarge ? 10 : 9}px monospace`; ctx.textAlign = 'center'
        ctx.fillText('▲', cx, py(c.l) + 8 + lH * 0.45)
        ctx.fillText(sig.label, cx, py(c.l) + 8 + lH * 0.82)
        ctx.restore()

        // Conviction badge
        ctx.fillStyle = sig.conv === 4 ? 'rgba(38,166,154,0.6)' : sig.conv === 3 ? 'rgba(38,166,154,0.45)' : 'rgba(255,179,0,0.5)'
        ctx.font = 'bold 8px monospace'; ctx.textAlign = 'center'
        ctx.fillText(`${sig.conv}/4`, cx, py(c.l) + 8 + lH + 12)
      } else {
        ctx.fillStyle = 'rgba(255,255,255,0.2)'; ctx.font = 'bold 12px monospace'; ctx.textAlign = 'center'
        ctx.fillText('✕', w * c.x, py(c.l) + 22)
        ctx.font = '8px monospace'; ctx.fillStyle = 'rgba(255,179,0,0.5)'
        ctx.fillText(`${sig.conv}/4`, w * c.x, py(c.l) + 34)
      }
    })
    ctx.textAlign = 'left'

    // Gate label
    const gColor = strongOn ? AMBER : 'rgba(255,255,255,0.3)'
    ctx.fillStyle = gColor + '22'; ctx.strokeStyle = gColor + '60'; ctx.lineWidth = 1
    roundRect(ctx, 10, 10, strongOn ? 108 : 90, 22, 5); ctx.fill(); ctx.stroke()
    ctx.fillStyle = gColor; ctx.font = 'bold 10px monospace'
    ctx.fillText(strongOn ? 'STRONG ONLY: ON' : 'STRONG ONLY: OFF', 18, 25)
  }

  return (
    <div className="space-y-3">
      <div className="flex gap-2">
        {([false, true] as const).map(v => (
          <button
            key={String(v)}
            onClick={() => setStrongOn(v)}
            className="flex-1 py-2 rounded-lg text-xs font-bold font-mono tracking-wider border transition-all"
            style={{
              background: strongOn === v ? (v ? 'rgba(255,179,0,0.15)' : 'rgba(38,166,154,0.12)') : 'transparent',
              color: strongOn === v ? (v ? AMBER : TEAL) : 'rgba(255,255,255,0.3)',
              borderColor: strongOn === v ? (v ? AMBER + '55' : TEAL + '55') : 'rgba(255,255,255,0.08)',
            }}
          >{v ? 'STRONG ONLY: ON' : 'STRONG ONLY: OFF'}</button>
        ))}
      </div>
      <AnimScene draw={draw} deps={[strongOn]} height={210} />
      <div className="grid grid-cols-3 gap-2 text-[10px] font-mono">
        {[
          { conv: '4/4', label: 'Long +', size: 'Large + marker', blocked: false, color: TEAL },
          { conv: '3/4', label: 'Long +', size: 'Large + marker', blocked: false, color: TEAL },
          { conv: '2/4', label: strongOn ? 'BLOCKED' : 'Long', size: strongOn ? 'Does not fire' : 'Smaller label', blocked: strongOn, color: strongOn ? MAGENTA : AMBER },
        ].map(({ conv, label, size, blocked, color }) => (
          <div key={conv} className="rounded-lg border border-white/8 bg-white/2 p-2 text-center">
            <p className="font-bold" style={{ color }}>{conv}</p>
            <p className="text-white/60 mt-0.5">{label}</p>
            <p className="text-white/30 text-[10px] mt-0.5">{size}</p>
          </div>
        ))}
      </div>
    </div>
  )
}

// ─── ANIM 9: FINAL GATE ────────────────────────────────────────────────────────
function Anim9FinalGate() {
  const [scenario, setScenario] = useState<'pass-px'|'pass-ts'|'block-conv'|'block-dir'>('pass-px')

  const SCENARIOS = {
    'pass-px':    { label: 'PX passes',      buy_px: true,  buy_ts: false, conv: 3, minConv: 0, result: true,  origin: 'PX',  color: TEAL    },
    'pass-ts':    { label: 'TS passes',      buy_px: false, buy_ts: true,  conv: 4, minConv: 0, result: true,  origin: 'TS',  color: TEAL    },
    'block-conv': { label: 'Blocked: conv',  buy_px: true,  buy_ts: false, conv: 1, minConv: 3, result: false, origin: 'PX',  color: MAGENTA },
    'block-dir':  { label: 'Blocked: dir',   buy_px: false, buy_ts: false, conv: 3, minConv: 0, result: false, origin: '—',   color: MAGENTA },
  } as const

  const sc = SCENARIOS[scenario]

  const draw = (ctx: CanvasRenderingContext2D, w: number, h: number, frame: number) => {
    drawGrid(ctx, w, h)
    const pulse = Math.sin(frame * 0.06) * 0.5 + 0.5
    const midY = h / 2
    const padX = 24
    const boxW = (w - padX * 2 - 32) / 3
    const boxH = 56
    const boxY = midY - boxH / 2

    // Three input boxes
    const boxes = [
      { label: 'buy_px', val: sc.buy_px ? 'TRUE' : 'FALSE', pass: sc.buy_px, x: padX },
      { label: 'buy_ts', val: sc.buy_ts ? 'TRUE' : 'FALSE', pass: sc.buy_ts, x: padX + boxW + 16 },
      { label: 'conv >= min', val: `${sc.conv} >= ${sc.minConv}`, pass: sc.conv >= sc.minConv, x: padX + (boxW + 16) * 2 },
    ]

    boxes.forEach(b => {
      const bColor = b.pass ? TEAL : 'rgba(255,255,255,0.12)'
      ctx.fillStyle = b.pass ? 'rgba(38,166,154,0.09)' : 'rgba(255,255,255,0.02)'
      ctx.strokeStyle = bColor; ctx.lineWidth = 1
      roundRect(ctx, b.x, boxY, boxW, boxH, 7); ctx.fill(); ctx.stroke()
      ctx.fillStyle = bColor; ctx.font = 'bold 9px monospace'; ctx.textAlign = 'center'
      ctx.fillText(b.label, b.x + boxW / 2, boxY + 16)
      ctx.font = `bold 11px monospace`
      ctx.fillStyle = b.pass ? TEAL : 'rgba(255,255,255,0.2)'
      ctx.fillText(b.val, b.x + boxW / 2, boxY + boxH / 2 + 6)
    })

    // OR label between px and ts
    ctx.fillStyle = 'rgba(255,255,255,0.25)'; ctx.font = 'bold 9px monospace'; ctx.textAlign = 'center'
    ctx.fillText('OR', padX + boxW + 8, midY + 4)
    ctx.fillText('AND', padX + (boxW + 16) * 2 - 8, midY + 4)

    // Result arrow and box
    const resX = w - padX - boxW
    const pxOrTs = sc.buy_px || sc.buy_ts
    const result = pxOrTs && sc.conv >= sc.minConv

    // Arrow line
    ctx.save(); ctx.strokeStyle = result ? 'rgba(38,166,154,0.5)' : 'rgba(239,83,80,0.3)'; ctx.lineWidth = 2
    if (!result) ctx.setLineDash([4, 4])
    ctx.beginPath(); ctx.moveTo(padX + (boxW + 16) * 2 + boxW, midY); ctx.lineTo(resX - 8, midY); ctx.stroke()
    ctx.setLineDash([]); ctx.restore()

    // Result box
    ctx.save()
    if (result) { ctx.shadowColor = TEAL; ctx.shadowBlur = 12 + pulse * 8 }
    ctx.fillStyle = result ? 'rgba(38,166,154,0.12)' : 'rgba(239,83,80,0.08)'
    ctx.strokeStyle = result ? 'rgba(38,166,154,0.6)' : 'rgba(239,83,80,0.4)'; ctx.lineWidth = result ? 2 : 1
    roundRect(ctx, resX, boxY, boxW, boxH, 7); ctx.fill(); ctx.stroke()
    ctx.fillStyle = result ? TEAL : MAGENTA; ctx.font = 'bold 10px monospace'; ctx.textAlign = 'center'
    ctx.fillText('buy_signal', resX + boxW / 2, boxY + 16)
    ctx.font = 'bold 14px monospace'
    ctx.fillText(result ? 'TRUE ✓' : 'FALSE ✗', resX + boxW / 2, boxY + boxH / 2 + 7)
    ctx.restore()

    // Signal label if passes
    if (result) {
      ctx.save(); ctx.shadowColor = TEAL; ctx.shadowBlur = 14 + pulse * 8
      ctx.fillStyle = TEAL; ctx.strokeStyle = '#fff'; ctx.lineWidth = 1
      roundRect(ctx, resX + boxW / 2 - 28, boxY + boxH + 12, 56, 28, 6); ctx.fill(); ctx.stroke()
      ctx.fillStyle = '#fff'; ctx.font = 'bold 10px monospace'; ctx.textAlign = 'center'
      ctx.fillText('▲', resX + boxW / 2, boxY + boxH + 24)
      ctx.fillText(sc.conv >= 3 ? 'Long +' : 'Long', resX + boxW / 2, boxY + boxH + 37)
      ctx.restore()
    }

    ctx.textAlign = 'left'
  }

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
        {(Object.entries(SCENARIOS) as [typeof scenario, typeof SCENARIOS[typeof scenario]][]).map(([k, v]) => (
          <button
            key={k}
            onClick={() => setScenario(k)}
            className="py-2 rounded-lg text-[10px] font-bold font-mono tracking-wider border transition-all"
            style={{
              background: scenario === k ? v.color + '18' : 'transparent',
              color: scenario === k ? v.color : 'rgba(255,255,255,0.3)',
              borderColor: scenario === k ? v.color + '55' : 'rgba(255,255,255,0.08)',
            }}
          >{v.label}</button>
        ))}
      </div>
      <AnimScene draw={draw} deps={[scenario]} height={200} />
      <div className="rounded-lg border border-white/8 bg-white/2 p-3 text-xs text-white/55 leading-relaxed">
        {scenario === 'pass-px'    && 'PX fired (buy_px = TRUE) and conviction score 3 meets min_conviction 0. buy_signal resolves TRUE. Long + fires on chart.'}
        {scenario === 'pass-ts'    && 'TS fired (buy_ts = TRUE) with 4/4 conviction. buy_signal resolves TRUE. The origin does not change the verdict — only one of PX or TS needs to be TRUE.'}
        {scenario === 'block-conv' && 'PX fired but conviction score is only 1 and Strong Only is ON (min_conviction = 3). Even though the origin passed, the conviction check fails. buy_signal = FALSE. Nothing fires.'}
        {scenario === 'block-dir'  && 'Direction filter blocked this long candidate upstream. Neither buy_px nor buy_ts is TRUE — the signal was already suppressed before reaching this gate. buy_signal = FALSE by construction.'}
      </div>
    </div>
  )
}

// ─── ANIM 10: STANDARD VS STRONG ON CHART ─────────────────────────────────────
function Anim10StandardVsStrong() {
  const draw = (ctx: CanvasRenderingContext2D, w: number, h: number, frame: number) => {
    drawGrid(ctx, w, h)
    const pulse = Math.sin(frame * 0.05) * 0.5 + 0.5
    const py = (n: number) => h * (1 - n * 0.70 - 0.15)
    const pulseY = py(0.40)
    const bW = w * 0.048

    ctx.save(); ctx.strokeStyle = TEAL; ctx.globalAlpha = 0.35; ctx.lineWidth = 1.5; ctx.setLineDash([5,3])
    ctx.beginPath(); ctx.moveTo(0, pulseY); ctx.lineTo(w, pulseY); ctx.stroke()
    ctx.setLineDash([]); ctx.restore()

    // Filler
    const fillers = [{x:0.08,o:0.44,h:0.48,l:0.41,c:0.46},{x:0.28,o:0.48,h:0.52,l:0.45,c:0.50},
                     {x:0.52,o:0.52,h:0.56,l:0.49,c:0.54},{x:0.72,o:0.54,h:0.58,l:0.51,c:0.56},{x:0.92,o:0.56,h:0.60,l:0.53,c:0.58}]
    fillers.forEach(c => {
      const cx = w * c.x
      ctx.strokeStyle = 'rgba(38,166,154,0.3)'; ctx.lineWidth = 1
      ctx.beginPath(); ctx.moveTo(cx, py(c.h)); ctx.lineTo(cx, py(c.l)); ctx.stroke()
      ctx.fillStyle = 'rgba(38,166,154,0.3)'
      ctx.fillRect(cx - bW/2, py(Math.max(c.o,c.c)), bW, Math.max(2, py(Math.min(c.o,c.c)) - py(Math.max(c.o,c.c))))
    })

    // Standard signal (left) — 2/4
    const sx = w * 0.20
    ctx.strokeStyle = TEAL; ctx.lineWidth = 1.5
    ctx.beginPath(); ctx.moveTo(sx, py(0.52)); ctx.lineTo(sx, py(0.42)); ctx.stroke()
    ctx.fillStyle = TEAL; ctx.fillRect(sx - bW/2, py(0.52), bW, Math.max(2, py(0.46) - py(0.52)))
    ctx.save(); ctx.shadowColor = TEAL; ctx.shadowBlur = 7 + pulse * 4
    ctx.fillStyle = TEAL; ctx.strokeStyle = '#fff'; ctx.lineWidth = 1
    roundRect(ctx, sx - 20, py(0.42) + 8, 40, 22, 5); ctx.fill(); ctx.stroke()
    ctx.fillStyle = '#fff'; ctx.font = 'bold 9px monospace'; ctx.textAlign = 'center'
    ctx.fillText('▲', sx, py(0.42) + 18); ctx.fillText('Long', sx, py(0.42) + 29)
    ctx.restore()
    // Label
    ctx.fillStyle = 'rgba(255,255,255,0.45)'; ctx.font = '9px monospace'; ctx.textAlign = 'center'
    ctx.fillText('2/4 conviction', sx, py(0.42) + 42)
    ctx.fillText('Standard', sx, py(0.42) + 53)

    // Strong signal (right) — 4/4, bigger label
    const sx2 = w * 0.62
    ctx.strokeStyle = TEAL; ctx.lineWidth = 2
    ctx.beginPath(); ctx.moveTo(sx2, py(0.56)); ctx.lineTo(sx2, py(0.44)); ctx.stroke()
    ctx.fillStyle = TEAL; ctx.fillRect(sx2 - bW/2, py(0.56), bW, Math.max(2, py(0.50) - py(0.56)))
    ctx.save(); ctx.shadowColor = TEAL; ctx.shadowBlur = 14 + pulse * 8
    ctx.fillStyle = TEAL; ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.5
    roundRect(ctx, sx2 - 28, py(0.44) + 8, 56, 30, 6); ctx.fill(); ctx.stroke()
    ctx.fillStyle = '#fff'; ctx.font = 'bold 11px monospace'; ctx.textAlign = 'center'
    ctx.fillText('▲', sx2, py(0.44) + 20); ctx.fillText('Long +', sx2, py(0.44) + 33)
    ctx.restore()
    ctx.fillStyle = 'rgba(255,255,255,0.45)'; ctx.font = '9px monospace'; ctx.textAlign = 'center'
    ctx.fillText('4/4 conviction', sx2, py(0.44) + 50)
    ctx.fillText('Strong', sx2, py(0.44) + 61)

    // Comparison arrows
    ctx.save(); ctx.strokeStyle = 'rgba(255,255,255,0.12)'; ctx.lineWidth = 1; ctx.setLineDash([3,3])
    ctx.beginPath(); ctx.moveTo(sx + 28, py(0.44) + 15); ctx.lineTo(sx2 - 36, py(0.44) + 15); ctx.stroke()
    ctx.setLineDash([]); ctx.restore()
    ctx.fillStyle = 'rgba(255,255,255,0.2)'; ctx.font = '9px monospace'; ctx.textAlign = 'center'
    ctx.fillText('More factors aligned', (sx + sx2) / 2, py(0.44) + 10)
    ctx.fillText('= larger label + marker', (sx + sx2) / 2, py(0.44) + 21)

    ctx.textAlign = 'left'
  }

  return <AnimScene draw={draw} height={230} />
}

// ─── ANIM 11: 13 CONTEXT TAGS ─────────────────────────────────────────────────
function Anim11ContextTags() {
  const [selected, setSelected] = useState<number | null>(null)

  const TAGS = [
    { tag: 'Sweep + FVG',  color: TEAL,    priority: 1, desc: 'Liquidity sweep followed by a Fair Value Gap. ICT highest-conviction reversal setup. Highest priority tag.' },
    { tag: 'Sweep',        color: TEAL,    priority: 2, desc: 'Liquidity sweep detected without FVG confluence. Still a strong structural context.' },
    { tag: 'Breakout',     color: TEAL,    priority: 3, desc: 'Price breaking a key level with conviction. Signal aligns with the structural break.' },
    { tag: 'Snap',         color: MAGENTA, priority: 4, desc: 'TS (Tension Snap) origin — signal fired from a tension extreme reversal.' },
    { tag: 'Exhaustion',   color: MAGENTA, priority: 5, desc: 'Momentum exhaustion detected alongside the signal. Potential reversal after extended move.' },
    { tag: 'S/R Break',    color: TEAL,    priority: 6, desc: 'Signal fired at or after a Support/Resistance level break. Structure context.' },
    { tag: 'At Support',   color: TEAL,    priority: 7, desc: 'Long signal at a support level. Price reacting from structural floor.' },
    { tag: 'At Resistance',color: MAGENTA, priority: 8, desc: 'Short signal at a resistance level. Price reacting from structural ceiling.' },
    { tag: 'At Spine',     color: AMBER,   priority: 9, desc: 'Signal at the Cipher Spine — the central ATR-weighted midline of the ribbon system.' },
    { tag: 'At FVG',       color: AMBER,   priority:10, desc: 'Signal at an active Fair Value Gap zone. Price reacting to an unfilled imbalance.' },
    { tag: 'Overextended', color: MAGENTA, priority:11, desc: 'MR Score > 60. Signal fired while mr_overextended is active. Mean reversion pressure present.' },
    { tag: 'Fade',         color: AMBER,   priority:12, desc: 'PX signal with momentum health below 35%. Trend is fading — lower-confidence continuation.' },
    { tag: 'Trend',        color: TEAL,    priority:13, desc: 'PX signal with ribbon stacked in signal direction. Clean trend continuation context.' },
    { tag: 'Momentum',     color: TEAL,    priority:14, desc: 'Default tag. Signal passed pipeline but none of the above structural contexts applied.' },
  ]

  const sel = selected !== null ? TAGS[selected] : null

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap gap-2">
        {TAGS.map((t, i) => (
          <button
            key={t.tag}
            onClick={() => setSelected(selected === i ? null : i)}
            className="px-2.5 py-1 rounded-full text-[10px] font-bold font-mono border transition-all"
            style={{
              background: selected === i ? t.color + '20' : 'transparent',
              color: selected === i ? t.color : 'rgba(255,255,255,0.35)',
              borderColor: selected === i ? t.color + '60' : 'rgba(255,255,255,0.08)',
            }}
          >{t.tag}</button>
        ))}
      </div>
      <div className="rounded-xl border border-white/10 bg-white/2 p-4 min-h-[64px] flex items-start gap-3">
        {sel ? (
          <>
            <div className="shrink-0 text-center min-w-[36px]">
              <p className="font-mono text-[10px] text-white/30">P{sel.priority}</p>
              <p className="font-mono font-bold text-xs mt-0.5" style={{ color: sel.color }}>{sel.tag}</p>
            </div>
            <div className="border-l border-white/8 pl-3">
              <p className="text-xs text-white/60 leading-relaxed">{sel.desc}</p>
            </div>
          </>
        ) : (
          <p className="text-xs font-mono text-white/25">Tap any tag to read the context description. P1 = highest priority in the waterfall.</p>
        )}
      </div>
      <p className="text-[10px] font-mono text-white/25 text-center">Priority waterfall: CIPHER evaluates top-to-bottom and renders the first match</p>
    </div>
  )
}

// ─── ANIM 12: LAST SIGNAL FRESHNESS ───────────────────────────────────────────
function Anim12LastSignal() {
  const [barsAgo, setBarsAgo] = useState(2)

  const getState = (b: number) => {
    if (b <= 3)  return { label: 'JUST FIRED', color: TEAL,    guidance: '\u2192 JUST FIRED' }
    if (b <= 10) return { label: 'FRESH',      color: TEAL,    guidance: '\u2192 FRESH' }
    if (b <= 30) return { label: 'ACTIVE',     color: AMBER,   guidance: '\u2192 ACTIVE' }
    return               { label: 'AGING',      color: MAGENTA, guidance: '\u2192 AGING' }
  }

  const st = getState(barsAgo)

  const draw = (ctx: CanvasRenderingContext2D, w: number, h: number, frame: number) => {
    drawGrid(ctx, w, h)
    const pulse = Math.sin(frame * 0.05) * 0.5 + 0.5
    const bW = w * 0.045
    const py = (n: number) => h * (1 - n * 0.70 - 0.15)

    // Render barsAgo candles worth of history
    const totalCandleW = w * 0.85
    const startX = w * 0.08
    const maxCandles = 42
    const dispCandles = Math.min(maxCandles, barsAgo + 6)
    const cW = totalCandleW / dispCandles

    // Signal candle at left
    const sigIdx = 0
    for (let i = 0; i < dispCandles; i++) {
      const cx = startX + i * cW
      const isSignal = i === 0
      const barAge = barsAgo - i
      const opacity = isSignal ? 0.9 : Math.max(0.15, 0.5 - i * 0.01)
      const rand = ((i * 137 + 42) % 100) / 100
      const ov = 0.44 + rand * 0.16
      const cv = ov + (Math.random() > 0.5 ? 0.04 : -0.04)
      const hv = Math.max(ov, cv) + 0.03; const lv = Math.min(ov, cv) - 0.03
      const bull = cv >= ov
      const col = isSignal ? TEAL : (bull ? 'rgba(38,166,154,' + opacity + ')' : 'rgba(239,83,80,' + opacity + ')')
      ctx.strokeStyle = col; ctx.lineWidth = isSignal ? 1.5 : 0.8
      ctx.beginPath(); ctx.moveTo(cx, py(hv)); ctx.lineTo(cx, py(lv)); ctx.stroke()
      ctx.fillStyle = col
      ctx.fillRect(cx - Math.min(bW, cW * 0.5) / 2, py(Math.max(ov, cv)), Math.min(bW, cW * 0.5), Math.max(1.5, py(Math.min(ov,cv)) - py(Math.max(ov,cv))))

      if (isSignal) {
        ctx.save(); ctx.shadowColor = TEAL; ctx.shadowBlur = 10 + pulse * 6
        ctx.fillStyle = TEAL; ctx.strokeStyle = '#fff'; ctx.lineWidth = 1
        roundRect(ctx, cx - 22, py(hv) - 32, 44, 24, 5); ctx.fill(); ctx.stroke()
        ctx.fillStyle = '#fff'; ctx.font = 'bold 9px monospace'; ctx.textAlign = 'center'
        ctx.fillText('▲ Long', cx, py(hv) - 16)
        ctx.restore()
      }
    }

    // "Now" marker at right
    const nowX = startX + (barsAgo) * cW
    ctx.save(); ctx.strokeStyle = 'rgba(255,255,255,0.2)'; ctx.lineWidth = 1; ctx.setLineDash([3,3])
    ctx.beginPath(); ctx.moveTo(Math.min(nowX, w - 20), 0); ctx.lineTo(Math.min(nowX, w - 20), h); ctx.stroke()
    ctx.setLineDash([]); ctx.restore()
    ctx.fillStyle = 'rgba(255,255,255,0.3)'; ctx.font = '9px monospace'; ctx.textAlign = 'center'
    ctx.fillText('NOW', Math.min(nowX, w - 20), h - 8)

    // Bars ago label
    ctx.fillStyle = st.color; ctx.font = 'bold 10px monospace'
    ctx.fillText(`${barsAgo} bars ago`, Math.min(nowX, w - 20) - 30, 18)

    // CC Row mock
    const rowY = h - 38
    ctx.fillStyle = 'rgba(13,20,32,0.92)'; ctx.fillRect(0, rowY, w, 38)
    ctx.strokeStyle = 'rgba(255,255,255,0.06)'; ctx.lineWidth = 1
    ctx.beginPath(); ctx.moveTo(0, rowY); ctx.lineTo(w, rowY); ctx.stroke()
    ctx.font = '10px monospace'; ctx.textAlign = 'left'; ctx.fillStyle = 'rgba(255,255,255,0.3)'
    ctx.fillText('Last Signal', 12, rowY + 14)
    ctx.fillStyle = TEAL; ctx.font = 'bold 11px monospace'
    ctx.fillText(`\u25B2 Long  ${barsAgo} bars`, 100, rowY + 14)
    ctx.fillStyle = st.color; ctx.fillText(st.guidance, 100, rowY + 28)
    ctx.textAlign = 'left'
  }

  return (
    <div className="space-y-4">
      <AnimScene draw={draw} deps={[barsAgo]} height={210} />
      <div className="space-y-2">
        <div className="flex items-center justify-between text-xs font-mono">
          <span className="text-white/35">1 bar ago</span>
          <span className="font-bold" style={{ color: st.color }}>{barsAgo}b — {st.label}</span>
          <span className="text-white/35">50 bars ago</span>
        </div>
        <input
          type="range" min={1} max={50} value={barsAgo}
          onChange={e => setBarsAgo(Number(e.target.value))}
          className="w-full accent-amber-400 cursor-pointer"
        />
      </div>
    </div>
  )
}

// ─── ANIM 13: VISUALS ONLY MODE ───────────────────────────────────────────────
function Anim13VisualsOnly() {
  const [showSignals, setShowSignals] = useState(true)

  const draw = (ctx: CanvasRenderingContext2D, w: number, h: number, frame: number) => {
    drawGrid(ctx, w, h)
    const pulse = Math.sin(frame * 0.05) * 0.5 + 0.5
    const py = (n: number) => h * (1 - n * 0.70 - 0.15)
    const bW = w * 0.05
    const pulseY = py(0.42)

    // Tension fill
    ctx.fillStyle = `rgba(239,83,80,${0.06 + pulse * 0.04})`
    ctx.fillRect(0, py(0.72), w, py(0.60) - py(0.72))

    // Pulse line
    ctx.save(); ctx.strokeStyle = TEAL; ctx.globalAlpha = 0.45 + pulse * 0.1; ctx.lineWidth = 1.5; ctx.setLineDash([5,3])
    ctx.beginPath(); ctx.moveTo(0, pulseY); ctx.lineTo(w, pulseY); ctx.stroke()
    ctx.setLineDash([]); ctx.restore()

    // Ribbon lines
    const r1Y = py(0.54); const r2Y = py(0.50); const r3Y = py(0.47)
    ;[[r1Y,'rgba(38,166,154,0.55)'],[r2Y,'rgba(38,166,154,0.4)'],[r3Y,'rgba(38,166,154,0.25)']].forEach(([y,c]) => {
      ctx.strokeStyle = c as string; ctx.lineWidth = 1.5
      ctx.beginPath(); ctx.moveTo(0, y as number); ctx.lineTo(w, y as number); ctx.stroke()
    })

    const candles = [
      {x:0.08,o:0.47,h:0.52,l:0.44,c:0.50},{x:0.18,o:0.50,h:0.55,l:0.47,c:0.53},
      {x:0.28,o:0.53,h:0.58,l:0.50,c:0.56,hasPX:true},{x:0.38,o:0.56,h:0.61,l:0.53,c:0.59},
      {x:0.48,o:0.59,h:0.64,l:0.56,c:0.62},{x:0.58,o:0.62,h:0.68,l:0.58,c:0.65},
      {x:0.68,o:0.65,h:0.70,l:0.60,c:0.63,hasTS:true},{x:0.78,o:0.63,h:0.66,l:0.57,c:0.59},
      {x:0.88,o:0.59,h:0.63,l:0.55,c:0.57},
    ] as { x:number;o:number;h:number;l:number;c:number;hasPX?:boolean;hasTS?:boolean }[]

    candles.forEach(c => {
      const cx = w * c.x; const bull = c.c >= c.o
      const col = bull ? 'rgba(38,166,154,0.65)' : 'rgba(239,83,80,0.65)'
      ctx.strokeStyle = col; ctx.lineWidth = 1
      ctx.beginPath(); ctx.moveTo(cx, py(c.h)); ctx.lineTo(cx, py(c.l)); ctx.stroke()
      ctx.fillStyle = col
      ctx.fillRect(cx - bW/2, py(Math.max(c.o,c.c)), bW, Math.max(2, py(Math.min(c.o,c.c)) - py(Math.max(c.o,c.c))))

      if (showSignals) {
        if (c.hasPX) {
          ctx.save(); ctx.shadowColor = TEAL; ctx.shadowBlur = 10 + pulse * 6
          ctx.fillStyle = TEAL; ctx.strokeStyle = '#fff'; ctx.lineWidth = 1
          roundRect(ctx, cx - 22, py(c.l) + 8, 44, 24, 5); ctx.fill(); ctx.stroke()
          ctx.fillStyle = '#fff'; ctx.font = 'bold 9px monospace'; ctx.textAlign = 'center'
          ctx.fillText('▲ Long +', cx, py(c.l) + 24); ctx.restore()
        }
        if (c.hasTS) {
          ctx.save(); ctx.shadowColor = MAGENTA; ctx.shadowBlur = 10 + pulse * 6
          ctx.fillStyle = MAGENTA; ctx.strokeStyle = '#fff'; ctx.lineWidth = 1
          roundRect(ctx, cx - 24, py(c.h) - 32, 48, 24, 5); ctx.fill(); ctx.stroke()
          ctx.fillStyle = '#fff'; ctx.font = 'bold 9px monospace'; ctx.textAlign = 'center'
          ctx.fillText('▼ Short +', cx, py(c.h) - 16); ctx.restore()
        }
      }
    })

    // Mode badge
    const mColor = showSignals ? TEAL : AMBER
    const mLabel = showSignals ? 'SIGNALS ON' : 'VISUALS ONLY'
    ctx.fillStyle = mColor + '22'; ctx.strokeStyle = mColor + '60'; ctx.lineWidth = 1
    roundRect(ctx, 10, 10, 100, 22, 5); ctx.fill(); ctx.stroke()
    ctx.fillStyle = mColor; ctx.font = 'bold 10px monospace'; ctx.textAlign = 'left'
    ctx.fillText(mLabel, 18, 25)
  }

  return (
    <div className="space-y-3">
      <div className="flex gap-2">
        {([true, false] as const).map(v => (
          <button
            key={String(v)}
            onClick={() => setShowSignals(v)}
            className="flex-1 py-2 rounded-lg text-xs font-bold font-mono tracking-wider border transition-all"
            style={{
              background: showSignals === v ? (v ? 'rgba(38,166,154,0.12)' : 'rgba(255,179,0,0.12)') : 'transparent',
              color: showSignals === v ? (v ? TEAL : AMBER) : 'rgba(255,255,255,0.3)',
              borderColor: showSignals === v ? (v ? TEAL + '55' : AMBER + '55') : 'rgba(255,255,255,0.08)',
            }}
          >{v ? 'SIGNALS ON' : 'VISUALS ONLY MODE'}</button>
        ))}
      </div>
      <AnimScene draw={draw} deps={[showSignals]} height={220} />
      <div className="rounded-lg border border-white/8 bg-white/2 p-3 text-xs text-white/55 leading-relaxed">
        {showSignals
          ? 'Signals ON: labels appear on chart when pipeline passes. Ribbon, pulse, and tension still visible as supporting context.'
          : 'Visuals Only: no signal labels fire. Ribbon stack, pulse line, and tension fill remain active. The operator reads the chart manually using these tools.'}
      </div>
    </div>
  )
}

// ─── GAME ROUNDS DATA ─────────────────────────────────────────────────────────
export const gameRounds = [
  {
    id: 'gr-118-01',
    scenario: "CIPHER has been silent for 8 bars on your setup. Signal Engine = Trend, Direction = Long Only, Strong Only = ON. Your HTF is bullish and ADX reads 28. A PX long candidate fires but conviction is 2/4 — ribbon stacked, ADX passes, but volume is thin (0.7×) and health is 44%. What happens?",
    options: [
      {
        id: 'a',
        text: "Signal fires as 'Long' — 2/4 passes when Strong Only is OFF by default.",
        correct: false,
        explanation: "Strong Only is explicitly ON in this scenario. With Strong Only ON, min_conviction = 3. A 2/4 score does not meet that threshold. The signal is blocked at the Strong Only gate regardless of the other settings.",
      },
      {
        id: 'b',
        text: "Signal fires as 'Long +' — the ribbon and ADX passing is enough for strong.",
        correct: false,
        explanation: "Strong requires 3+/4 factors, not 2/4. Two factors passing (ribbon and ADX) does not qualify as strong. The + marker only appears when conviction reaches 3 or 4. This candidate scores 2 — blocked.",
      },
      {
        id: 'c',
        text: "Signal is blocked at the Strong Only gate — 2/4 does not meet the 3+ threshold.",
        correct: true,
        explanation: "Correct. Strong Only ON sets min_conviction = 3. This candidate has ribbon stacked and ADX > 20 (2 factors) but volume at 0.7× (below 1.0×) and health at 44% (below 50%) fail. Score is 2/4. The Strong Only gate blocks it. CIPHER stays silent.",
      },
      {
        id: 'd',
        text: "Signal is blocked at the direction gate — Long Only rejects this candidate.",
        correct: false,
        explanation: "The candidate is a long signal and Direction = Long Only — so the direction gate passes this one. The block happens later, at the Strong Only gate, where 2/4 conviction fails the 3+ threshold.",
      },
    ],
  },
  {
    id: 'gr-118-02',
    scenario: "Your Command Center Last Signal row shows: ▲ Long  22 bars → ACTIVE. A new short setup is forming. Should you consider the long signal still relevant context?",
    options: [
      {
        id: 'a',
        text: "Yes — ACTIVE means the signal is still fully valid and should override the short setup.",
        correct: false,
        explanation: "ACTIVE (11–30 bars) means the signal is aging and its context is weakening — not that it is still fully valid. It does not override a new setup forming in the opposite direction. Freshness states describe relevance, not authority.",
      },
      {
        id: 'b',
        text: "No — 22 bars is too old, discard it entirely and treat the chart as clean.",
        correct: false,
        explanation: "ACTIVE is not the same as AGING. At 22 bars the signal is weakening but has not crossed the 30-bar AGING threshold yet. Discarding it entirely misses the freshness system's nuance — it is flagging reduced relevance, not zero relevance.",
      },
      {
        id: 'c',
        text: "Treat it as weakening context — ACTIVE signals are aging but not stale. The new short setup needs its own fresh confirmation.",
        correct: true,
        explanation: "Correct. ACTIVE (11–30b) means the prior signal context is present but diminishing. At 22 bars it has not crossed into AGING yet. The right response is to note the prior direction without leaning on it — let the new short setup qualify through the pipeline on its own merits.",
      },
      {
        id: 'd',
        text: "Yes — a long signal 22 bars ago means the bias is still long and the short setup should be skipped.",
        correct: false,
        explanation: "The Last Signal row tracks what fired through your filters, not a permanent bias directive. A 22-bar-old signal does not lock you into a direction. Markets change. The freshness system exists precisely to prevent over-reliance on stale signal context.",
      },
    ],
  },
  {
    id: 'gr-118-03',
    scenario: "You see two CIPHER signals on your chart. Signal A: teal label, smaller size, reads 'Long'. Signal B: teal label, larger size, reads 'Long +'. Both fired on the same instrument, 4 bars apart. What does the size and + marker difference tell you?",
    options: [
      {
        id: 'a',
        text: "Signal B fired on a higher timeframe — the + means it came from a higher TF confirmation.",
        correct: false,
        explanation: "The + marker has nothing to do with timeframe. CIPHER runs on whichever chart you are on. The + suffix and larger label indicate strong conviction (3+/4 factors) on that specific bar. Timeframe is a separate concept.",
      },
      {
        id: 'b',
        text: "Signal A has 0–2/4 conviction factors aligned. Signal B has 3–4/4. Both passed the pipeline but B had more market alignment.",
        correct: true,
        explanation: "Correct. Both signals cleared origin, direction, and the final gate. The visual difference — smaller label vs larger label + '+' — reflects the conviction score. Signal A scored 0–2/4 (standard). Signal B scored 3–4/4 (strong). More factors aligned behind B.",
      },
      {
        id: 'c',
        text: "Signal A is a TS signal, Signal B is a PX signal — the + indicates the origin type.",
        correct: false,
        explanation: "The + marker indicates conviction strength, not origin type. Both PX and TS signals can produce standard or strong labels depending on their conviction score at the time they fire. Origin type is not encoded in the label size.",
      },
      {
        id: 'd',
        text: "Both signals are identical — the size difference is a rendering artifact from zoom level.",
        correct: false,
        explanation: "The label size difference is intentional and carries meaning. Strong signals (3+/4) render with a larger label and + suffix. Standard signals (0–2/4) render smaller. This is hardcoded in CIPHER's label rendering logic based on the conviction score.",
      },
    ],
  },
  {
    id: 'gr-118-04',
    scenario: "A TS short signal fires. Its context tag reads 'Sweep + FVG'. Signal Engine = All Signals, Direction = Both, Strong Only = OFF. Conviction = 3/4. You are in a TREND regime (TREND INTACT). Should you take this signal?",
    options: [
      {
        id: 'a',
        text: "Yes — 'Sweep + FVG' is the highest priority context tag and 3/4 conviction is strong. Take it.",
        correct: false,
        explanation: "The pipeline qualification and context tag are necessary but not sufficient. A TS short in a TREND INTACT regime means you are trading against the trend. The tag tells you the structural condition — not whether the trade fits your regime or HTF bias. Regime context always matters.",
      },
      {
        id: 'b',
        text: "No — TS signals are always lower quality than PX signals and should be avoided.",
        correct: false,
        explanation: "There is no hierarchy between PX and TS in terms of quality. Both are valid signal origins designed for different market conditions. TS signals are reversal entries — they are designed specifically for setups like this. The question is whether the regime supports a reversal, not which origin fired.",
      },
      {
        id: 'c',
        text: "Evaluate carefully — a TS short in TREND INTACT is counter-trend. The pipeline passed it but your regime and HTF bias should validate before entry.",
        correct: true,
        explanation: "Correct. The pipeline passed the signal — origin valid, direction open, conviction 3/4, final gate TRUE. But the signal is a short in a TREND INTACT regime. CIPHER passed it; operator judgment must evaluate whether a counter-trend reversal is appropriate given the macro context. 'Sweep + FVG' is a high-quality structural tag but does not override trend context.",
      },
      {
        id: 'd',
        text: "Yes — Strong Only is OFF so this is the most permissive setting. All valid signals should be taken.",
        correct: false,
        explanation: "Strong Only OFF means no minimum conviction threshold — but that is about filtering, not about trade selection. Permissive settings do not mean every signal that fires should be taken. The operator still applies regime, HTF bias, and structural judgment. CIPHER qualifies signals; operators execute them.",
      },
    ],
  },
  {
    id: 'gr-118-05',
    scenario: "You switch Signal Engine from 'All Signals' to 'Reversal'. CIPHER immediately goes quiet — no signals appear for 6 bars even though you saw PX signals firing before the switch. What is happening and is this correct behaviour?",
    options: [
      {
        id: 'a',
        text: "The indicator has a bug — switching modes should not affect historical signals.",
        correct: false,
        explanation: "CIPHER recalculates based on current settings on each bar. Historical labels are not retroactively removed — but going forward, only TS signals will be shown. If no TS signals have fired in the last 6 bars, silence is correct behaviour. There is no bug.",
      },
      {
        id: 'b',
        text: "Correct — Reversal mode blocks PX (Pulse Cross) signals at Gate 1. If no TS conditions have been met in 6 bars, silence is expected.",
        correct: true,
        explanation: "Correct. Switching to Reversal sets the Signal Engine gate to block all PX candidates. Only TS signals can pass. If the tension system has not produced a valid snap in the last 6 bars — no prior stretch, no snap candle, or conditions not fully met — CIPHER correctly shows nothing. The filter is working as intended.",
      },
      {
        id: 'c',
        text: "Correct — but you should switch back to All Signals immediately because 6 bars of silence means something is wrong with the indicator.",
        correct: false,
        explanation: "Six bars of silence in Reversal mode is not a malfunction. TS signals are the more selective of the two engines — they require four conditions to fire simultaneously. In a trending or ranging market without active tension extremes, TS signals will naturally be infrequent. Silence is the filter being selective.",
      },
      {
        id: 'd',
        text: "Incorrect — switching Signal Engine should not affect what fires going forward, only what is displayed historically.",
        correct: false,
        explanation: "Signal Engine mode directly controls which origin types are permitted in the pipeline going forward. Setting it to Reversal blocks all PX candidates from Gate 1 onward. The effect is immediate and correct — only TS signals will appear while this mode is active.",
      },
    ],
  },
]

// ─── QUIZ QUESTIONS DATA ──────────────────────────────────────────────────────
export const quizQuestions = [
  {
    id: 'qq-118-01',
    question: "Which Signal Engine mode shows both PX and TS signals simultaneously?",
    options: [
      { id: 'a', text: 'Trend' },
      { id: 'b', text: 'Reversal' },
      { id: 'c', text: 'All Signals' },
      { id: 'd', text: 'Visuals Only' },
    ],
    correct: 'c',
    explanation: "All Signals mode enables both Pulse Cross (PX) and Tension Snap (TS) signal origins simultaneously. Trend mode enables PX only. Reversal mode enables TS only. Visuals Only disables all signal labels.",
  },
  {
    id: 'qq-118-02',
    question: "What is the minimum conviction score required when Strong Only is turned ON?",
    options: [
      { id: 'a', text: '2 out of 4 factors' },
      { id: 'b', text: '4 out of 4 factors' },
      { id: 'c', text: '1 out of 4 factors' },
      { id: 'd', text: '3 out of 4 factors' },
    ],
    correct: 'd',
    explanation: "Strong Only ON sets min_conviction = 3. Signals with fewer than 3 of the 4 conviction factors (ribbon, ADX, volume, health) are blocked at the Strong Only gate. Signals at 3/4 or 4/4 pass and fire as 'Long +' or 'Short +'.",
  },
  {
    id: 'qq-118-03',
    question: "A PX long signal fires but Direction is set to Short Only. At which gate is it blocked?",
    options: [
      { id: 'a', text: 'The Final Gate — buy_signal resolves FALSE' },
      { id: 'b', text: 'The Strong Only gate — conviction not checked' },
      { id: 'c', text: 'The Direction Filter gate — long candidate blocked' },
      { id: 'd', text: 'The Signal Origin gate — PX not permitted' },
    ],
    correct: 'c',
    explanation: "The Direction Filter is Gate 2. When set to Short Only, all long candidates are rejected at this gate. The signal never reaches the conviction scoring or final gate. buy_px is set to FALSE upstream, so even if the PX fired at the origin level, the direction filter cancels it.",
  },
  {
    id: 'qq-118-04',
    question: "Which of the four conviction factors checks whether the trend engine supports the signal direction?",
    options: [
      { id: 'a', text: 'ADX > 20' },
      { id: 'b', text: 'Volume > 1.0×' },
      { id: 'c', text: 'Health > 50%' },
      { id: 'd', text: 'Ribbon Stacked' },
    ],
    correct: 'd',
    explanation: "Ribbon Stacked (conv_bull_ribbon for longs, conv_bear_ribbon for shorts) checks whether the Cipher Ribbon is stacked in the direction of the signal. A bull stack for a long signal or a bear stack for a short signal earns this conviction point.",
  },
  {
    id: 'qq-118-05',
    question: "The Last Signal row shows '▲ Long  35 bars → AGING'. What does this mean for the operator?",
    options: [
      { id: 'a', text: 'The long signal is still valid and should be used as primary direction bias.' },
      { id: 'b', text: 'The signal fired 35 bars ago. It is stale — wait for a fresh signal before acting.' },
      { id: 'c', text: 'AGING means the signal is about to reverse — take the opposite trade.' },
      { id: 'd', text: 'The signal fired 35 bars ago but AGING only applies after 50 bars.' },
    ],
    correct: 'b',
    explanation: "AGING fires when the last signal is 30+ bars old. At 35 bars the signal context is stale. The freshness system is telling you this setup is no longer fresh enough to carry full weight. Wait for a new signal to form before committing to direction bias from this one.",
  },
  {
    id: 'qq-118-06',
    question: "What does the context tag 'Sweep + FVG' indicate on a CIPHER signal?",
    options: [
      { id: 'a', text: 'The signal fired after a TS snap with 4/4 conviction.' },
      { id: 'b', text: 'A liquidity sweep occurred and a Fair Value Gap was present — the highest-priority structural context.' },
      { id: 'c', text: 'The signal fired in a VOLATILE regime with elevated volume.' },
      { id: 'd', text: 'Price swept a level and then crossed the Cipher Pulse line.' },
    ],
    correct: 'b',
    explanation: "'Sweep + FVG' is the highest priority tag in CIPHER's 13-level context waterfall. It indicates that a liquidity sweep was detected and a Fair Value Gap was present at the same time — the ICT highest-conviction reversal confluence. It is evaluated first in the priority cascade.",
  },
  {
    id: 'qq-118-07',
    question: "In CIPHER's final gate logic, what must be true for buy_signal to resolve TRUE?",
    options: [
      { id: 'a', text: 'Both buy_px AND buy_ts must be TRUE simultaneously.' },
      { id: 'b', text: 'buy_px OR buy_ts must be TRUE, AND bull_conviction must meet min_conviction.' },
      { id: 'c', text: 'buy_px must be TRUE AND conviction must be 4/4.' },
      { id: 'd', text: 'buy_ts must be TRUE AND the regime must be VOLATILE.' },
    ],
    correct: 'b',
    explanation: "The final gate expression is: buy_signal = (buy_px OR buy_ts) AND bull_conviction >= min_conviction. Only one of PX or TS needs to have fired (OR logic). The conviction must then meet or exceed min_conviction (0 when Strong Only is OFF, 3 when ON).",
  },
  {
    id: 'qq-118-08',
    question: "Which Tension Snap (TS) condition ensures the signal does not fire repeatedly in the same direction during a choppy reversal?",
    options: [
      { id: 'a', text: 'Prior stretch threshold' },
      { id: 'b', text: 'Snap candle body requirement' },
      { id: 'c', text: 'Velocity shift confirmation' },
      { id: 'd', text: 'Cooldown bar gate' },
    ],
    correct: 'd',
    explanation: "The cooldown gate prevents a TS signal from firing in the same direction within a set number of bars of the previous TS signal in that direction. It is explicitly designed to suppress repeated TS signals during choppy reversals where the tension system might otherwise fire multiple times.",
  },
]
