# L11.25 IP SCRUB — Deploy Bundle

**What this is:** A single file swap. The existing L11.25 lesson on production exposes Pine source code, line numbers, and variable names. This bundle replaces the lesson page with a fully scrubbed version. **Same content, same animations, same quiz, same cert — zero references to Pine source, Pine line numbers, or any internal variable name.**

**What changed:**
- 87 leak occurrences scrubbed across S04, S05, S06, prose throughout S00-S15, Mistakes section, Cheat Sheet, all 13 game scenarios, all 13 quiz questions (Q2 entirely rewritten), and inside 3 animations (PineGateFireAnim, TSCooldownClockAnim, PresetPhilosophyRingAnim, OverrideReplayAnim canvas text)
- 3 literal `<pre>` Pine code blocks removed from S04 and S05
- All "Pine line 200" / "Lines 2632-2648" / "Pine source" framing replaced with "the conviction gate" / "the cooldown mechanism" / "the engine"
- Quiz Q2 entirely rewritten: was "What is the literal Pine line 200 expression?" → now "How is the conviction threshold determined?"
- 8 lines shorter overall (3,861 → 3,853)

**What's preserved:**
- All 16 sections, all 13 animations including the ★★★ interactive 30-Session Scrubber
- All 6 mistake cards, the cheat sheet, the game, the 13-question quiz, the Discipline Operator cert
- 100% of the discipline pedagogy

---

## Deploy (single block, 90 seconds)

```bash
cd ~/OneDrive/Desktop/interakktive-website
./backup.sh pre-L11.25-scrub
cp /path/to/page.tsx app/academy/lesson/cipher-trading-discipline/page.tsx
git add app/academy/lesson/cipher-trading-discipline/page.tsx
git commit -m "Academy L11.25: scrub Pine source IP from lesson content (Option A strict)"
git push origin main
```

That's it. Vercel auto-deploys in 60-90s. No other files touched. No patches to apply. The lesson stays live throughout the swap.

---

## Verification after deploy

Open `/academy/lesson/cipher-trading-discipline` and verify:

- [ ] S04 no longer shows code blocks — section is now titled "The Conviction Threshold — The First Gate"
- [ ] S05 no longer shows Pine code — title still says "★ TS COOLDOWN CLOCK — SAME-DIRECTION LOCKOUT"
- [ ] S06 no longer references `(min_conviction, pulse_mult)` — preset list says "Threshold 3-of-4" / "tight" / "widest" etc.
- [ ] Quiz Q2 asks "How is the conviction threshold determined?" with plain-English answers
- [ ] Cheat Sheet "Three Mechanisms" section says "Conviction Threshold / TS Cooldown / Preset Philosophies" with no line numbers
- [ ] Animation 2 (the gate firing one in S01) shows "YOUR CONFIG / Threshold: 3-of-4 required" instead of Pine code
- [ ] Animation 5 (cooldown clock) shows "Cooldown window: 8 bars (this TF)" instead of Pine code
- [ ] Animation 6 (preset ring) side panel shows "Conviction threshold: 3-of-4" / "Signal engine width: widest" instead of variable names

Rollback if anything looks wrong: `git revert HEAD && git push`.
