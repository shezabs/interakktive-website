# Affiliate System Phase 1 — Deploy

## What's in this tarball

10 files. The tree mirrors your repo structure (`~/OneDrive/Desktop/interakktive-website/`).
Extract from the repo root and it will overlay correctly.

```
app/lib/admin-auth.ts                       (modified — added affiliate.view / affiliate.review capabilities)
app/lib/email.ts                            (modified — added notifyAffiliateApplication + escapeHtml helper)
app/api/affiliate-apply/route.ts            (NEW — public POST for application submissions)
app/api/admin/affiliates/route.ts           (NEW — admin GET/PATCH for review)
app/affiliates/page.tsx                     (NEW — public landing page)
app/admin/affiliates/page.tsx               (NEW — admin review tab)
app/admin/admin-context.tsx                 (modified — mirrored capabilities)
app/admin/components/AdminNav.tsx           (modified — added Affiliates tab between Academy and Audit)
app/components/Footer.tsx                   (modified — added Affiliates link to Resources column)
supabase/affiliate-applications.sql         (NEW — run once in Supabase SQL editor)
```

## Deploy steps

### 1. Extract over your repo

```bash
cd ~/OneDrive/Desktop/interakktive-website
tar -xzf affiliate-system-phase1.tar.gz
```

The tarball uses paths starting with `app/` and `supabase/` — no extra top-level folder.
Verify with `git status` before committing.

### 2. Run the SQL migration

Open Supabase → SQL Editor → paste contents of `supabase/affiliate-applications.sql` → Run.
Creates `affiliate_applications` table + RLS policies + updated_at trigger.
Idempotent (`CREATE TABLE IF NOT EXISTS`), safe to re-run.

### 3. Commit + push

```bash
git add app/ supabase/affiliate-applications.sql
git status                                                   # sanity check
git commit -m "feat: affiliate program phase 1 — landing page, application pipeline, admin review tab"
git push origin main
```

Vercel auto-deploys within 60-90s.

### 4. Smoke test on prod

- Visit any page → footer should show "Affiliates" link under Resources column → click → loads `/affiliates`
- Mobile + desktop: page renders cleanly, calculator slider works
- Submit form using your active-subscriber email → expect success card + 2 emails (admin notification to support@ + applicant confirmation to you)
- Submit form with email that has no active subscription → expect friendly 403 error
- Go to `/admin/affiliates` → application appears in Pending → click row → drawer opens → click Approve → status flips to Approved

### 5. Backup tarball after testing

Once smoke tests pass, save a `~/OneDrive/Desktop/interakktive-backups/` snapshot per usual discipline.

## Capabilities

- `affiliate.view` — see applications list (Owner + Operator)
- `affiliate.review` — approve/reject/reset (Owner + Operator)

Mustafa (Operator) can review applications. If you want to lock review to Owner-only, remove `affiliate.review` from `OPERATOR_CAPS` in BOTH `app/lib/admin-auth.ts` AND `app/admin/admin-context.tsx`.

## Not built (next session)

- Approved → affiliate provisioning (referral link gen, dashboard creation)
- Referral link click tracking + attribution
- Commission engine (tier math, Mustafa's special rules, bonus accounting)
- `/affiliate/dashboard` route for approved affiliates
- Mustafa's commission view inside `/admin`
- Mustafa-sourced-Ahmed retroactive seed: $7.50 one-time + $2.50/mo from 2026-05-10 (note for the commission build)

## Open thread carried forward

Direct-URL bypass of sequential lesson gate (from Section 16) — still pending.

## Known good

- TypeScript: 0 errors across project (`./node_modules/.bin/tsc --noEmit` passes)
- All lucide-react icons used are verified present in installed version
- Honeypot anti-bot field present
- Anti-spam: one pending application per email at a time
- Audit log written on every approve/reject/reset action
- Force-dynamic on admin API route (no cache leaks of pending applications)
- Active-customer eligibility checked server-side (not just client-side) — non-customers cannot submit even by bypassing the form
