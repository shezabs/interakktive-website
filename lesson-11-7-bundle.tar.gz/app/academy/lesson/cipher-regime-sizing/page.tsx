'use client'

import { useEffect, useRef, useState } from 'react'
import { motion } from 'framer-motion'

// ─── BRAND CONSTANTS ───────────────────────────────────────────────────────────
const TEAL    = '#26A69A'
const MAGENTA = '#EF5350'
const AMBER   = '#FFB300'
const DANGER_BRIGHT = '#FF1744'

// ─── ANIMSCENE ─────────────────────────────────────────────────────────────────
function AnimScene({
  draw,
  deps = [],
  height = 220,
  className = '',
}: {
  draw: (ctx: CanvasRenderingContext2D, w: number, h: number, frame: number) => void
  deps?: unknown[]
  height?: number
  className?: string
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const frameRef  = useRef(0)
  const rafRef    = useRef<number>(0)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    const resize = () => {
      const dpr = window.devicePixelRatio || 1
      const rect = canvas.getBoundingClientRect()
      canvas.width  = rect.width  * dpr
      canvas.height = rect.height * dpr
      ctx.scale(dpr, dpr)
    }

    resize()
    window.addEventListener('resize', resize)

    const tick = () => {
      const w = canvas.getBoundingClientRect().width
      const h = canvas.getBoundingClientRect().height
      ctx.clearRect(0, 0, w, h)
      draw(ctx, w, h, frameRef.current)
      frameRef.current++
      rafRef.current = requestAnimationFrame(tick)
    }
    rafRef.current = requestAnimationFrame(tick)

    return () => {
      window.removeEventListener('resize', resize)
      cancelAnimationFrame(rafRef.current)
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps)

  return (
    <canvas
      ref={canvasRef}
      style={{ width: '100%', height }}
      className={`rounded-lg ${className}`}
    />
  )
}

// ─── CONFETTI ──────────────────────────────────────────────────────────────────
function Confetti({ active }: { active: boolean }) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const pieces = useRef<Array<{
    x: number; y: number; vx: number; vy: number;
    color: string; size: number; spin: number; spinV: number
  }>>([])
  const rafRef = useRef<number>(0)

  useEffect(() => {
    if (!active) return
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return
    canvas.width  = window.innerWidth
    canvas.height = window.innerHeight
    const colors = [TEAL, MAGENTA, AMBER, '#ffffff']
    pieces.current = Array.from({ length: 120 }, () => ({
      x: Math.random() * canvas.width,
      y: -10,
      vx: (Math.random() - 0.5) * 4,
      vy: Math.random() * 3 + 2,
      color: colors[Math.floor(Math.random() * colors.length)],
      size: Math.random() * 8 + 4,
      spin: 0,
      spinV: (Math.random() - 0.5) * 0.2,
    }))
    const tick = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height)
      pieces.current.forEach(p => {
        p.x += p.vx; p.y += p.vy; p.spin += p.spinV
        ctx.save()
        ctx.translate(p.x, p.y)
        ctx.rotate(p.spin)
        ctx.fillStyle = p.color
        ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size * 0.5)
        ctx.restore()
      })
      pieces.current = pieces.current.filter(p => p.y < canvas.height + 20)
      if (pieces.current.length > 0) rafRef.current = requestAnimationFrame(tick)
      else ctx.clearRect(0, 0, canvas.width, canvas.height)
    }
    rafRef.current = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(rafRef.current)
  }, [active])

  if (!active) return null
  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 pointer-events-none z-50"
    />
  )
}

// ─── HELPERS ───────────────────────────────────────────────────────────────────
function lerp(a: number, b: number, t: number) { return a + (b - a) * t }
function easeInOut(t: number) { return t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t }

function drawGrid(ctx: CanvasRenderingContext2D, w: number, h: number) {
  ctx.strokeStyle = 'rgba(255,255,255,0.04)'
  ctx.lineWidth = 1
  for (let i = 1; i < 5; i++) {
    ctx.beginPath(); ctx.moveTo(0, h * i / 5); ctx.lineTo(w, h * i / 5); ctx.stroke()
  }
}

function roundRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  ctx.beginPath()
  ctx.moveTo(x + r, y)
  ctx.lineTo(x + w - r, y)
  ctx.quadraticCurveTo(x + w, y, x + w, y + r)
  ctx.lineTo(x + w, y + h - r)
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h)
  ctx.lineTo(x + r, y + h)
  ctx.quadraticCurveTo(x, y + h, x, y + h - r)
  ctx.lineTo(x, y + r)
  ctx.quadraticCurveTo(x, y, x + r, y)
  ctx.closePath()
}

// ─── SECTION WRAPPER ───────────────────────────────────────────────────────────
function Section({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <motion.section
      initial={{ opacity: 0, y: 32 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-60px' }}
      transition={{ duration: 0.55, ease: 'easeOut' }}
      className="mb-16"
    >
      <p className="text-xs font-bold tracking-widest uppercase text-amber-400/60 mb-3 font-mono">
        {label}
      </p>
      {children}
    </motion.section>
  )
}

// ─── ANIM 1: REGIME BAND EXPANSION (Groundbreaking Concept) ───────────────────
function Anim1RegimeBands() {
  const REGIMES = ['range', 'trend', 'volatile'] as const
  type Regime = typeof REGIMES[number]
  const [activeRegime, setActiveRegime] = useState<Regime>('range')
  const [playing, setPlaying]           = useState(false)
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null)

  const REGIME_CFG: Record<Regime, {
    scale: number; zone: string; guidance: string;
    dwell: string; zoneColor: string; guideColor: string;
    tabColor: string; tabBg: string
  }> = {
    range:    { scale: 0.85, zone: 'DANGER',  guidance: 'REDUCE SIZE',   dwell: '7b', zoneColor: MAGENTA,  guideColor: MAGENTA,  tabColor: MAGENTA,  tabBg: 'rgba(239,83,80,0.15)' },
    trend:    { scale: 1.15, zone: 'CAUTION', guidance: 'TIGHTEN STOPS', dwell: '3b', zoneColor: AMBER,    guideColor: AMBER,    tabColor: TEAL,     tabBg: 'rgba(38,166,154,0.15)' },
    volatile: { scale: 1.25, zone: 'WATCH',   guidance: 'STAY ALERT',    dwell: '2b', zoneColor: AMBER,    guideColor: AMBER,    tabColor: AMBER,    tabBg: 'rgba(255,179,0,0.15)' },
  }

  const scaleRef    = useRef(0.85)
  const targetScale = useRef(0.85)
  const regimeRef   = useRef<Regime>('range')

  useEffect(() => {
    regimeRef.current   = activeRegime
    targetScale.current = REGIME_CFG[activeRegime].scale
  }, [activeRegime])

  function toggle() {
    if (playing) {
      setPlaying(false)
      if (timerRef.current) clearTimeout(timerRef.current)
    } else {
      setPlaying(true)
      cycle()
    }
  }

  function cycle() {
    timerRef.current = setTimeout(() => {
      setActiveRegime(prev => {
        const idx  = REGIMES.indexOf(prev)
        return REGIMES[(idx + 1) % REGIMES.length]
      })
      cycle()
    }, 1800)
  }

  useEffect(() => () => { if (timerRef.current) clearTimeout(timerRef.current) }, [])

  const ANCHOR_N = 0.44
  const ATR_N    = 0.065

  const CANDLES = [
    { o:0.38,h:0.44,l:0.34,c:0.42 },
    { o:0.42,h:0.48,l:0.39,c:0.45 },
    { o:0.45,h:0.50,l:0.41,c:0.47 },
    { o:0.47,h:0.53,l:0.44,c:0.51 },
    { o:0.51,h:0.57,l:0.48,c:0.54 },
    { o:0.54,h:0.60,l:0.50,c:0.58 },
    { o:0.58,h:0.64,l:0.54,c:0.61 },
    { o:0.61,h:0.67,l:0.57,c:0.64 },
    { o:0.64,h:0.71,l:0.60,c:0.68 },
    { o:0.68,h:0.75,l:0.64,c:0.72 },
    { o:0.72,h:0.82,l:0.68,c:0.80 },
  ]

  const draw = (ctx: CanvasRenderingContext2D, w: number, h: number, frame: number) => {
    drawGrid(ctx, w, h)

    // Smooth scale
    scaleRef.current = lerp(scaleRef.current, targetScale.current, 0.06)
    const scale = scaleRef.current

    function py(n: number) { return h * (1 - n * 0.80 - 0.10) }
    const anchor  = py(ANCHOR_N)
    const atrPx   = ATR_N * h * 0.80
    const iMult   = 1.2  * scale
    const mMult   = 2.35 * scale
    const oMult   = 3.5  * scale
    const iU = anchor - atrPx * iMult; const iL = anchor + atrPx * iMult
    const mU = anchor - atrPx * mMult; const mL = anchor + atrPx * mMult
    const oU = anchor - atrPx * oMult; const oL = anchor + atrPx * oMult

    // Fills
    ctx.fillStyle = 'rgba(239,83,80,0.12)'
    ctx.fillRect(0, Math.max(0, oU), w, Math.max(0, mU - oU))
    ctx.fillRect(0, mL, w, Math.max(0, oL - mL))
    ctx.fillStyle = 'rgba(255,179,0,0.09)'
    ctx.fillRect(0, mU, w, iU - mU)
    ctx.fillRect(0, iL, w, mL - iL)
    ctx.fillStyle = 'rgba(38,166,154,0.07)'
    ctx.fillRect(0, iU, w, iL - iU)

    // Band lines
    const bands: [number, string][] = [[oU,MAGENTA],[oL,MAGENTA],[mU,AMBER],[mL,AMBER],[iU,TEAL],[iL,TEAL]]
    bands.forEach(([y, c]) => {
      ctx.save(); ctx.strokeStyle = c; ctx.globalAlpha = 0.45
      ctx.lineWidth = 1; ctx.setLineDash([4, 4])
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(w, y); ctx.stroke()
      ctx.setLineDash([]); ctx.restore()
    })

    // Band labels
    ctx.font = '9px monospace'
    ctx.fillStyle = 'rgba(239,83,80,0.7)';  ctx.fillText('DANGER',  w - 58, oU - 3)
    ctx.fillStyle = 'rgba(255,179,0,0.7)';   ctx.fillText('CAUTION', w - 62, mU - 3)
    ctx.fillStyle = 'rgba(38,166,154,0.7)';  ctx.fillText('WATCH',   w - 52, iU - 3)
    ctx.fillStyle = 'rgba(38,166,154,0.45)'; ctx.fillText('SAFE',    w - 36, anchor - 3)

    // Anchor EMA
    ctx.save(); ctx.strokeStyle = 'rgba(255,255,255,0.18)'; ctx.lineWidth = 1
    ctx.setLineDash([6, 3]); ctx.beginPath(); ctx.moveTo(0, anchor); ctx.lineTo(w, anchor); ctx.stroke()
    ctx.setLineDash([]); ctx.restore()

    // Candles
    const n = CANDLES.length; const lPad = 18; const rPad = 78
    const cW = (w - lPad - rPad) / n; const bW = Math.max(4, cW * 0.55)
    CANDLES.forEach((c, i) => {
      const cx = lPad + i * cW + cW / 2; const isLast = i === n - 1
      const bull = c.c >= c.o; const col = bull ? TEAL : MAGENTA
      ctx.strokeStyle = isLast ? '#fff' : col; ctx.lineWidth = isLast ? 1.5 : 1
      ctx.beginPath(); ctx.moveTo(cx, py(c.h)); ctx.lineTo(cx, py(c.l)); ctx.stroke()
      const yT = py(Math.max(c.o, c.c)); const yB = py(Math.min(c.o, c.c))
      const bH = Math.max(2, yB - yT)
      if (isLast) {
        ctx.fillStyle = 'rgba(38,166,154,0.85)'; ctx.fillRect(cx - bW/2, yT, bW, bH)
        ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.5; ctx.strokeRect(cx - bW/2, yT, bW, bH)
        ctx.fillStyle = 'rgba(255,255,255,0.8)'; ctx.font = 'bold 9px monospace'
        ctx.textAlign = 'center'
        ctx.fillText('THIS',   cx, py(c.h) - 14)
        ctx.fillText('CANDLE', cx, py(c.h) - 4)
        ctx.textAlign = 'left'
      } else {
        ctx.fillStyle = bull ? 'rgba(38,166,154,0.55)' : 'rgba(239,83,80,0.55)'
        ctx.fillRect(cx - bW/2, yT, bW, bH)
      }
    })

    // Scale badge
    const reg = regimeRef.current
    const rColor = reg === 'range' ? MAGENTA : reg === 'trend' ? TEAL : AMBER
    ctx.save(); ctx.fillStyle = rColor + '22'; ctx.strokeStyle = rColor; ctx.lineWidth = 1
    roundRect(ctx, 10, 10, 82, 22, 4); ctx.fill(); ctx.stroke()
    ctx.fillStyle = rColor; ctx.font = 'bold 11px monospace'
    ctx.fillText(reg === 'volatile' ? 'VOLATILE' : reg.toUpperCase(), 18, 25); ctx.restore()

    ctx.save(); ctx.fillStyle = 'rgba(255,255,255,0.05)'; ctx.strokeStyle = 'rgba(255,255,255,0.14)'; ctx.lineWidth = 1
    roundRect(ctx, 102, 10, 88, 22, 4); ctx.fill(); ctx.stroke()
    ctx.fillStyle = 'rgba(255,255,255,0.55)'; ctx.font = '10px monospace'
    ctx.fillText('SCALE ' + scale.toFixed(2) + '\u00D7', 110, 25); ctx.restore()
  }

  const cfg = REGIME_CFG[activeRegime]

  return (
    <div className="rounded-xl border border-white/8 bg-white/2 overflow-hidden">
      {/* Tabs */}
      <div className="flex border-b border-white/8">
        {REGIMES.map(r => (
          <button
            key={r}
            onClick={() => setActiveRegime(r)}
            className="flex-1 py-2.5 text-xs font-bold tracking-widest font-mono transition-all"
            style={{
              background: activeRegime === r ? REGIME_CFG[r].tabBg : 'transparent',
              color: activeRegime === r ? REGIME_CFG[r].tabColor : 'rgba(255,255,255,0.35)',
              borderRight: r !== 'volatile' ? '1px solid rgba(255,255,255,0.08)' : 'none',
            }}
          >
            {r === 'volatile' ? 'VOLATILE' : r.toUpperCase()}
          </button>
        ))}
      </div>

      {/* Canvas */}
      <div className="bg-[#080d18] p-0">
        <AnimScene draw={draw} deps={[activeRegime]} height={240} />
      </div>

      {/* CC Row */}
      <div className="flex items-center gap-3 px-4 py-3 bg-[#0d1420] border-t border-white/6 font-mono text-xs">
        <span className="text-white/40 w-8">Risk</span>
        <span className="font-bold text-sm" style={{ color: cfg.zoneColor }}>
          &#9650; {cfg.zone}
        </span>
        <span className="text-white/30">&#8594;</span>
        <span className="font-semibold" style={{ color: cfg.guideColor }}>{cfg.guidance}</span>
        <span className="ml-auto text-white/30">{cfg.dwell}</span>
      </div>

      {/* Insight */}
      <div className="px-4 py-3 border-t border-white/6">
        <p className="text-sm text-white/75 leading-relaxed">
          {activeRegime === 'range' && (
            <><span className="text-white font-semibold">RANGE</span> — bands at their narrowest (0.85&times;). Same candle sits outside the outer band. CIPHER says{' '}<span style={{ color: MAGENTA }} className="font-bold">DANGER</span>.</>
          )}
          {activeRegime === 'trend' && (
            <><span className="text-white font-semibold">TREND</span> — bands expand to 1.15&times;. Same price now falls between mid and outer. CIPHER drops to{' '}<span style={{ color: AMBER }} className="font-bold">CAUTION</span>.</>
          )}
          {activeRegime === 'volatile' && (
            <><span className="text-white font-semibold">VOLATILE</span> — bands widen to 1.25&times; (includes vol bonus). Same price now between inner and mid. CIPHER drops to{' '}<span style={{ color: AMBER }} className="font-bold">WATCH</span>.</>
          )}
        </p>
      </div>

      {/* Play btn */}
      <div className="px-4 py-3 border-t border-white/6 flex justify-end">
        <button
          onClick={toggle}
          className="px-5 py-1.5 rounded-lg text-xs font-bold font-mono tracking-widest transition-opacity hover:opacity-80"
          style={{ background: AMBER, color: '#060a12' }}
        >
          {playing ? '\u23F8 PAUSE' : '\u25B6 AUTO-CYCLE'}
        </button>
      </div>
    </div>
  )
}

// ─── ANIM 2: FOUR RISK ZONES ───────────────────────────────────────────────────
function Anim2RiskZones() {
  const ZONES = [
    { name: 'SAFE',    color: TEAL,          bg: 'rgba(38,166,154,0.10)',  guidance: 'NORMAL SIZE',   desc: 'Price inside the inner band. Full size permitted.',         mult: '< 1.2\u00D7 ATR' },
    { name: 'WATCH',   color: AMBER,          bg: 'rgba(255,179,0,0.10)',   guidance: 'STAY ALERT',    desc: 'Between inner and mid band. Momentum or extension detected.', mult: '1.2\u2013 2.35\u00D7 ATR' },
    { name: 'CAUTION', color: AMBER,          bg: 'rgba(255,179,0,0.12)',   guidance: 'TIGHTEN STOPS', desc: 'Between mid and outer band. Risk is elevated.',             mult: '2.35\u2013 3.5\u00D7 ATR' },
    { name: 'DANGER',  color: MAGENTA,        bg: 'rgba(239,83,80,0.12)',   guidance: 'REDUCE SIZE',   desc: 'Beyond the outer band. Overextension. Size down now.',       mult: '> 3.5\u00D7 ATR' },
  ]

  const draw = (ctx: CanvasRenderingContext2D, w: number, h: number, frame: number) => {
    drawGrid(ctx, w, h)
    const scale = 1.0
    const pulse  = Math.sin(frame * 0.04) * 0.5 + 0.5

    const ANCHOR_N = 0.50
    const ATR_N    = 0.055
    function py(n: number) { return h * (1 - n * 0.78 - 0.11) }
    const anchor = py(ANCHOR_N)
    const atrPx  = ATR_N * h * 0.78
    const iU = anchor - atrPx * 1.2 * scale;  const iL = anchor + atrPx * 1.2 * scale
    const mU = anchor - atrPx * 2.35 * scale; const mL = anchor + atrPx * 2.35 * scale
    const oU = anchor - atrPx * 3.5 * scale;  const oL = anchor + atrPx * 3.5 * scale

    // Zone fills
    ctx.fillStyle = `rgba(239,83,80,${0.10 + pulse * 0.04})`
    ctx.fillRect(0, Math.max(0, oU), w, Math.max(0, mU - oU))
    ctx.fillRect(0, mL, w, Math.max(0, oL - mL))
    ctx.fillStyle = `rgba(255,179,0,${0.08 + pulse * 0.03})`
    ctx.fillRect(0, mU, w, iU - mU)
    ctx.fillRect(0, iL, w, mL - iL)
    ctx.fillStyle = `rgba(38,166,154,${0.07 + pulse * 0.02})`
    ctx.fillRect(0, iU, w, iL - iU)

    // Lines
    const lines: [number, string][] = [[oU,MAGENTA],[oL,MAGENTA],[mU,AMBER],[mL,AMBER],[iU,TEAL],[iL,TEAL]]
    lines.forEach(([y, c]) => {
      ctx.save(); ctx.strokeStyle = c; ctx.globalAlpha = 0.5; ctx.lineWidth = 1; ctx.setLineDash([4, 4])
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(w, y); ctx.stroke()
      ctx.setLineDash([]); ctx.restore()
    })

    // Zone labels left side
    const zoneMids = [
      { label: 'DANGER',  y: (oU + mU) / 2,  color: MAGENTA },
      { label: 'CAUTION', y: (mU + iU) / 2,  color: AMBER },
      { label: 'SAFE',    y: anchor,           color: TEAL },
      { label: 'CAUTION', y: (iL + mL) / 2,  color: AMBER },
      { label: 'DANGER',  y: (mL + oL) / 2,  color: MAGENTA },
    ]
    zoneMids.forEach(({ label, y, color }) => {
      ctx.fillStyle = color; ctx.font = 'bold 10px monospace'; ctx.textAlign = 'center'
      ctx.fillText(label, 42, y + 4)
    })
    ctx.textAlign = 'left'

    // ATR distance markers right side
    ctx.fillStyle = 'rgba(255,255,255,0.3)'; ctx.font = '9px monospace'
    ctx.fillText('OUTER: 3.5\u00D7 ATR', w - 100, oU - 4)
    ctx.fillText('MID: 2.35\u00D7 ATR',  w - 96, mU - 4)
    ctx.fillText('INNER: 1.2\u00D7 ATR', w - 96, iU - 4)
  }

  return (
    <div className="space-y-4">
      <AnimScene draw={draw} height={210} />
      <div className="grid grid-cols-2 gap-3">
        {ZONES.map(z => (
          <div key={z.name} className="rounded-lg border p-3" style={{ borderColor: z.color + '40', background: z.bg }}>
            <div className="flex items-center justify-between mb-1">
              <span className="font-mono text-xs font-bold" style={{ color: z.color }}>{z.name}</span>
              <span className="font-mono text-xs text-white/40">{z.mult}</span>
            </div>
            <p className="text-xs font-bold mb-0.5" style={{ color: z.color }}>&rarr; {z.guidance}</p>
            <p className="text-xs text-white/55 leading-snug">{z.desc}</p>
          </div>
        ))}
      </div>
    </div>
  )
}

// ─── ANIM 3: REGIME SCALES BANDS ──────────────────────────────────────────────
function Anim3RegimeScale() {
  const draw = (ctx: CanvasRenderingContext2D, w: number, h: number, frame: number) => {
    drawGrid(ctx, w, h)

    const REGIMES = [
      { label: 'RANGE',    scale: 0.85, color: MAGENTA, x: w * 0.18 },
      { label: 'TREND',    scale: 1.15, color: TEAL,    x: w * 0.50 },
      { label: 'VOLATILE', scale: 1.25, color: AMBER,   x: w * 0.82 },
    ]

    const ANCHOR_N = 0.50
    const ATR_N    = 0.05
    function py(n: number) { return h * (1 - n * 0.78 - 0.11) }
    const anchor = py(ANCHOR_N)
    const atrPx  = ATR_N * h * 0.78

    const colW = w * 0.28

    REGIMES.forEach(({ label, scale, color, x }) => {
      const oU = anchor - atrPx * 3.5 * scale
      const oL = anchor + atrPx * 3.5 * scale
      const mU = anchor - atrPx * 2.35 * scale
      const mL = anchor + atrPx * 2.35 * scale
      const iU = anchor - atrPx * 1.2 * scale
      const iL = anchor + atrPx * 1.2 * scale
      const left = x - colW / 2

      // Danger fill
      ctx.fillStyle = 'rgba(239,83,80,0.12)'
      ctx.fillRect(left, Math.max(0, oU), colW, Math.max(0, mU - oU))
      ctx.fillRect(left, mL, colW, Math.max(0, oL - mL))
      // Caution fill
      ctx.fillStyle = 'rgba(255,179,0,0.09)'
      ctx.fillRect(left, mU, colW, iU - mU)
      ctx.fillRect(left, iL, colW, mL - iL)
      // Safe fill
      ctx.fillStyle = 'rgba(38,166,154,0.07)'
      ctx.fillRect(left, iU, colW, iL - iU)

      // Outer band lines
      ctx.save(); ctx.strokeStyle = MAGENTA; ctx.globalAlpha = 0.6; ctx.lineWidth = 1.5; ctx.setLineDash([4, 3])
      ctx.beginPath(); ctx.moveTo(left, oU); ctx.lineTo(left + colW, oU); ctx.stroke()
      ctx.beginPath(); ctx.moveTo(left, oL); ctx.lineTo(left + colW, oL); ctx.stroke()
      ctx.setLineDash([]); ctx.restore()

      // Regime pill
      ctx.save(); ctx.fillStyle = color + '22'; ctx.strokeStyle = color; ctx.lineWidth = 1
      roundRect(ctx, left + colW / 2 - 38, anchor - 13, 76, 22, 5); ctx.fill(); ctx.stroke()
      ctx.fillStyle = color; ctx.font = 'bold 10px monospace'; ctx.textAlign = 'center'
      ctx.fillText(label, x, anchor + 4); ctx.restore()

      // Scale label
      ctx.fillStyle = 'rgba(255,255,255,0.55)'; ctx.font = '10px monospace'; ctx.textAlign = 'center'
      ctx.fillText(scale.toFixed(2) + '\u00D7', x, oU - 6)
      ctx.textAlign = 'left'

      // Arrow showing band width difference
      const arrowCol = 'rgba(255,255,255,0.2)'
      ctx.save(); ctx.strokeStyle = arrowCol; ctx.lineWidth = 1
      ctx.beginPath(); ctx.moveTo(x + colW / 2 - 4, oU); ctx.lineTo(x + colW / 2 - 4, oL); ctx.stroke()
      ctx.restore()
    })

    // Anchor EMA line
    ctx.save(); ctx.strokeStyle = 'rgba(255,255,255,0.15)'; ctx.lineWidth = 1; ctx.setLineDash([6, 3])
    ctx.beginPath(); ctx.moveTo(0, anchor); ctx.lineTo(w, anchor); ctx.stroke()
    ctx.setLineDash([]); ctx.restore()
    ctx.fillStyle = 'rgba(255,255,255,0.3)'; ctx.font = '9px monospace'
    ctx.fillText('ANCHOR EMA', 6, anchor - 4)
  }

  return (
    <div className="space-y-4">
      <AnimScene draw={draw} height={220} />
      <div className="grid grid-cols-3 gap-3 font-mono text-xs">
        {[
          { r: 'RANGE',    s: '0.85\u00D7', bonus: 'no bonus', color: MAGENTA },
          { r: 'TREND',    s: '1.15\u00D7', bonus: 'ADX 75', color: TEAL },
          { r: 'VOLATILE', s: '1.25\u00D7', bonus: '+0.10 vol bonus', color: AMBER },
        ].map(({ r, s, bonus, color }) => (
          <div key={r} className="rounded-lg border border-white/8 bg-white/2 p-3 text-center">
            <div className="font-bold mb-1" style={{ color }}>{r}</div>
            <div className="text-xl font-bold text-white mb-0.5">{s}</div>
            <div className="text-white/35 text-[10px]">{bonus}</div>
          </div>
        ))}
      </div>
    </div>
  )
}

// ─── ANIM 4: DIRECTIONAL ASYMMETRY ────────────────────────────────────────────
function Anim4Asymmetry() {
  const [mode, setMode] = useState<'range' | 'bull' | 'bear'>('range')

  const draw = (ctx: CanvasRenderingContext2D, w: number, h: number, _frame: number) => {
    drawGrid(ctx, w, h)
    const scale = 1.15 // TREND

    // ADX 75 → asym_factor = min(0.15, (75-15)*0.006) = min(0.15, 0.36) = 0.15
    const asymFactor = mode === 'range' ? 0.0 : 0.15
    const trendSide  = 1.0 + asymFactor
    const counterSide= 1.0 - asymFactor

    // Bull: upper is trend side (wider), lower is counter (tighter)
    // Bear: lower is trend side (wider), upper is counter (tighter)
    const upperAsym = mode === 'bear'  ? counterSide : trendSide
    const lowerAsym = mode === 'bear'  ? trendSide   : counterSide

    const ANCHOR_N = 0.50; const ATR_N = 0.055
    function py(n: number) { return h * (1 - n * 0.80 - 0.10) }
    const anchor = py(ANCHOR_N); const atrPx = ATR_N * h * 0.80

    const outerUpper = anchor - atrPx * 3.5 * scale * upperAsym
    const outerLower = anchor + atrPx * 3.5 * scale * lowerAsym
    const midUpper   = anchor - atrPx * 2.35 * scale * upperAsym
    const midLower   = anchor + atrPx * 2.35 * scale * lowerAsym
    const innerUpper = anchor - atrPx * 1.2 * scale * upperAsym
    const innerLower = anchor + atrPx * 1.2 * scale * lowerAsym

    // Fills
    ctx.fillStyle = 'rgba(239,83,80,0.12)'
    ctx.fillRect(0, Math.max(0, outerUpper), w, Math.max(0, midUpper - outerUpper))
    ctx.fillRect(0, midLower, w, Math.max(0, outerLower - midLower))
    ctx.fillStyle = 'rgba(255,179,0,0.09)'
    ctx.fillRect(0, midUpper, w, innerUpper - midUpper)
    ctx.fillRect(0, innerLower, w, midLower - innerLower)
    ctx.fillStyle = 'rgba(38,166,154,0.07)'
    ctx.fillRect(0, innerUpper, w, innerLower - innerUpper)

    const drawLine = (y: number, c: string) => {
      ctx.save(); ctx.strokeStyle = c; ctx.globalAlpha = 0.5; ctx.lineWidth = 1; ctx.setLineDash([4, 4])
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(w, y); ctx.stroke()
      ctx.setLineDash([]); ctx.restore()
    }
    drawLine(outerUpper, MAGENTA); drawLine(outerLower, MAGENTA)
    drawLine(midUpper, AMBER);     drawLine(midLower, AMBER)
    drawLine(innerUpper, TEAL);    drawLine(innerLower, TEAL)

    // Anchor
    ctx.save(); ctx.strokeStyle = 'rgba(255,255,255,0.18)'; ctx.lineWidth = 1; ctx.setLineDash([6, 3])
    ctx.beginPath(); ctx.moveTo(0, anchor); ctx.lineTo(w, anchor); ctx.stroke()
    ctx.setLineDash([]); ctx.restore()

    // Asymmetry labels
    if (mode !== 'range') {
      const trendColor  = mode === 'bull' ? TEAL : MAGENTA
      const counterColor= mode === 'bull' ? MAGENTA : TEAL
      ctx.font = 'bold 9px monospace'; ctx.textAlign = 'center'

      if (mode === 'bull') {
        ctx.fillStyle = trendColor
        ctx.fillText('TREND SIDE (wider)', w / 2, outerUpper - 5)
        ctx.fillStyle = counterColor
        ctx.fillText('COUNTER SIDE (tighter)', w / 2, outerLower + 14)
      } else {
        ctx.fillStyle = counterColor
        ctx.fillText('COUNTER SIDE (tighter)', w / 2, outerUpper - 5)
        ctx.fillStyle = trendColor
        ctx.fillText('TREND SIDE (wider)', w / 2, outerLower + 14)
      }
      ctx.textAlign = 'left'

      // asym label
      ctx.fillStyle = 'rgba(255,255,255,0.4)'; ctx.font = '9px monospace'
      ctx.fillText('asym: \u00B10.15 (ADX 75)', 10, 18)
    } else {
      ctx.fillStyle = 'rgba(255,255,255,0.4)'; ctx.font = '9px monospace'
      ctx.fillText('symmetric (no ADX pressure)', 10, 18)
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex gap-2">
        {(['range','bull','bear'] as const).map(m => (
          <button
            key={m}
            onClick={() => setMode(m)}
            className="flex-1 py-2 rounded-lg text-xs font-bold font-mono tracking-wider transition-all border"
            style={{
              background: mode === m ? (m === 'range' ? 'rgba(255,255,255,0.08)' : m === 'bull' ? 'rgba(38,166,154,0.15)' : 'rgba(239,83,80,0.15)') : 'transparent',
              color: mode === m ? (m === 'range' ? '#fff' : m === 'bull' ? TEAL : MAGENTA) : 'rgba(255,255,255,0.35)',
              borderColor: mode === m ? (m === 'range' ? 'rgba(255,255,255,0.2)' : m === 'bull' ? TEAL + '60' : MAGENTA + '60') : 'rgba(255,255,255,0.08)',
            }}
          >
            {m === 'range' ? 'RANGE (SYMMETRIC)' : m === 'bull' ? 'BULL TREND' : 'BEAR TREND'}
          </button>
        ))}
      </div>
      <AnimScene draw={draw} deps={[mode]} height={210} />
      <div className="rounded-lg border border-white/8 bg-white/2 p-3 text-sm text-white/65 leading-relaxed">
        {mode === 'range' && <>In a <span className="text-white font-semibold">RANGE</span>, there is no directional pressure. Both sides of the envelope are equal. The risk zone is the same whether price moves up or down.</>}
        {mode === 'bull' && <>In a <span className="text-white font-semibold">BULL TREND</span>, a pullback is riskier than a continuation. CIPHER widens the upper band (trend side) and tightens the lower band (counter side). Pullbacks hit CAUTION sooner.</>}
        {mode === 'bear' && <>In a <span className="text-white font-semibold">BEAR TREND</span>, the lower band widens (trend side) and the upper band tightens (counter side). A bounce hits CAUTION sooner than a continuation down.</>}
      </div>
    </div>
  )
}

// ─── MAIN COMPONENT ────────────────────────────────────────────────────────────
export default function Lesson117() {
  // ── Game state ──
  const [gameStep, setGameStep]           = useState(0)
  const [gameScore, setGameScore]         = useState(0)
  const [gameSelected, setGameSelected]   = useState<string | null>(null)
  const [gameRevealed, setGameRevealed]   = useState(false)
  const [gameDone, setGameDone]           = useState(false)

  // ── Quiz state ──
  const [quizStep, setQuizStep]           = useState(0)
  const [quizScore, setQuizScore]         = useState(0)
  const [quizSelected, setQuizSelected]   = useState<string | null>(null)
  const [quizRevealed, setQuizRevealed]   = useState(false)
  const [quizDone, setQuizDone]           = useState(false)
  const [quizPassed, setQuizPassed]       = useState(false)
  const [confettiActive, setConfettiActive] = useState(false)

  // ── Cert reveal ──
  useEffect(() => {
    if (quizDone && quizPassed) {
      const t = setTimeout(() => setConfettiActive(true), 400)
      return () => clearTimeout(t)
    }
  }, [quizDone, quizPassed])

  // ── Game handlers ──
  function handleGameSelect(optId: string) {
    if (gameRevealed) return
    setGameSelected(optId)
    setGameRevealed(true)
    const round = gameRounds[gameStep]
    const opt = round.options.find(o => o.id === optId)
    if (opt?.correct) setGameScore(s => s + 1)
  }

  function handleGameNext() {
    if (gameStep < gameRounds.length - 1) {
      setGameStep(s => s + 1)
      setGameSelected(null)
      setGameRevealed(false)
    } else {
      setGameDone(true)
    }
  }

  // ── Quiz handlers ──
  function handleQuizSelect(optId: string) {
    if (quizRevealed) return
    setQuizSelected(optId)
    setQuizRevealed(true)
    const q = quizQuestions[quizStep]
    if (optId === q.correct) setQuizScore(s => s + 1)
  }

  function handleQuizNext() {
    if (quizStep < quizQuestions.length - 1) {
      setQuizStep(s => s + 1)
      setQuizSelected(null)
      setQuizRevealed(false)
    } else {
      const lastCorrect = quizSelected === quizQuestions[quizStep].correct ? 1 : 0
      const finalScore = quizScore + lastCorrect
      const pct = Math.round((finalScore / quizQuestions.length) * 100)
      setQuizDone(true)
      setQuizPassed(pct >= 66)
    }
  }

  const certCode = 'ATLAS-SZO-117-2026'

  return (
    <>
    <Confetti active={confettiActive} />
    <main
      className="min-h-screen text-white"
      style={{ background: 'linear-gradient(to bottom, #060a12, #0a0f1a)' }}
    >
      <div className="max-w-2xl mx-auto px-5 pb-24 pt-8">

        {/* ── HERO ── */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-14 text-center"
        >
          {/* Crown Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-amber-400/30 bg-amber-400/8 mb-5">
            <span className="text-amber-400 text-xs">&#9812;</span>
            <span className="text-amber-400 text-xs font-bold tracking-widest font-mono">CIPHER PRO MASTERY</span>
            <span className="text-amber-400 text-xs">&#9812;</span>
          </div>

          <p className="text-xs font-bold tracking-widest uppercase text-white/35 font-mono mb-3">
            Level 11 &middot; Lesson 7
          </p>

          <h1 className="text-3xl font-extrabold leading-tight mb-4">
            Regime-Based<br />
            <span style={{ color: AMBER }}>Position Sizing</span>
          </h1>

          <p className="text-base text-gray-400 leading-relaxed max-w-lg mx-auto">
            CIPHER&apos;s Risk Envelope doesn&apos;t stay fixed. It breathes with the regime.
            The same candle that means{' '}
            <span style={{ color: MAGENTA }} className="font-semibold">DANGER</span> in a Range
            becomes{' '}
            <span style={{ color: AMBER }} className="font-semibold">WATCH</span> in a Volatile
            market. Your size must reflect that.
          </p>

          <div className="flex items-center justify-center gap-6 mt-6 text-xs font-mono text-white/30">
            <span>17 SECTIONS</span>
            <span className="w-px h-3 bg-white/15" />
            <span>45 MIN</span>
            <span className="w-px h-3 bg-white/15" />
            <span>CERT: SIZING OPERATOR</span>
          </div>
        </motion.div>

        {/* ── S00: WHY THIS MATTERS ── */}
        <Section label="00 — Why This Matters">
          <h2 className="text-2xl font-extrabold mb-4">
            The Risk Envelope Is Not Optional
          </h2>
          <div className="text-gray-400 space-y-4 leading-relaxed">
            <p>
              Most traders apply a fixed percentage risk per trade and call it position sizing.
              That works if every market condition is identical. They are not.
            </p>
            <p>
              CIPHER&apos;s Risk Envelope calculates four risk zones in real time, every bar,
              using your regime, your ATR, and your directional bias. It then tells you
              exactly what sizing action to take. The Command Center does not ask you to guess.
            </p>
            <p>
              This lesson teaches you to read those outputs, understand the math behind them,
              and use them to size correctly across all three regimes.
            </p>
          </div>

          {/* Amber callout */}
          <div className="mt-6 rounded-lg border-l-4 border-amber-400 bg-amber-400/6 px-4 py-3">
            <p className="text-sm text-amber-300 font-semibold leading-relaxed">
              The Risk Envelope is a live sizing system. Every bar CIPHER recalculates
              where price stands relative to four zones. The Command Center Risk row gives
              you the verdict. Ignore it at your own cost.
            </p>
          </div>
        </Section>

        {/* ── S01: GROUNDBREAKING CONCEPT ── */}
        <Section label="01 ⭐ — Your Stop Distance Is Wrong Without Regime">
          <h2 className="text-2xl font-extrabold mb-2">
            Same Candle. Same ATR.{' '}
            <span style={{ color: AMBER }}>Three Different Risk Zones.</span>
          </h2>
          <p className="text-gray-400 mb-5 leading-relaxed">
            Switch regime and watch the bands expand around the same price.
            The candle never moves. Your risk classification does.
          </p>
          <Anim1RegimeBands />
          <div className="mt-4 rounded-lg border border-white/8 bg-white/2 px-4 py-3">
            <p className="text-sm text-white/65 leading-relaxed">
              This is the core insight of Lesson 11.7. CIPHER&apos;s bands are not cosmetic.
              They are a real-time sizing engine. The regime directly controls band width,
              which controls what zone your price sits in, which controls what the
              Command Center tells you to do with your size.
            </p>
          </div>
        </Section>

        {/* ── S02: FOUR RISK ZONES ── */}
        <Section label="02 — The Four Risk Zones">
          <h2 className="text-2xl font-extrabold mb-2">
            SAFE / WATCH / CAUTION / DANGER
          </h2>
          <p className="text-gray-400 mb-5 leading-relaxed">
            CIPHER divides the space around price into four nested zones. Each zone has
            one sizing verdict. There is no ambiguity.
          </p>
          <Anim2RiskZones />
          <div className="mt-4 rounded-lg border-l-4 border-amber-400 bg-amber-400/6 px-4 py-3">
            <p className="text-sm text-amber-300 leading-relaxed">
              The zone verdict is determined by where the close sits relative to the
              inner, mid, and outer bands every bar. One close = one zone = one action.
            </p>
          </div>
        </Section>

        {/* ── S03: REGIME SCALES BANDS ── */}
        <Section label="03 — How Regime Scales the Bands">
          <h2 className="text-2xl font-extrabold mb-2">
            The Band Scale Factor
          </h2>
          <p className="text-gray-400 mb-5 leading-relaxed">
            CIPHER applies a multiplier to all three band levels based on the current regime.
            The multiplier is calculated every bar from your ADX reading. A VOLATILE bonus
            is added on top for VOLATILE conditions.
          </p>
          <Anim3RegimeScale />
          <div className="mt-5 rounded-lg border border-white/8 bg-white/2 p-4 font-mono text-xs space-y-2">
            <div className="text-white/40 mb-1 text-[10px] tracking-widest uppercase">Scale Formula</div>
            <div className="text-white/75">Band Scale &nbsp;= 0.85 + (trend% &times; 0.004)</div>
            <div className="text-white/75">Vol Bonus &nbsp;&nbsp;= 0.10 &nbsp;(VOLATILE regime only)</div>
            <div className="text-white/75">Final Scale = Band Scale + Vol Bonus</div>
            <div className="border-t border-white/8 pt-2 text-white/40 text-[10px]">
              Range: 0.85 flat &rarr; Trend: 0.85&ndash;1.25 &rarr; Volatile: 0.85&ndash;1.35 maximum
            </div>
          </div>
        </Section>

        {/* ── S04: DIRECTIONAL ASYMMETRY ── */}
        <Section label="04 — Directional Asymmetry">
          <h2 className="text-2xl font-extrabold mb-2">
            Trend Bands Are Not Symmetric
          </h2>
          <p className="text-gray-400 mb-5 leading-relaxed">
            In a trending market, moving with the trend is lower risk than moving against it.
            CIPHER applies asymmetry: the band on the trend side widens, the counter side
            tightens. A pullback hits CAUTION faster than a continuation.
          </p>
          <Anim4Asymmetry />
          <div className="mt-4 rounded-lg border border-white/8 bg-white/2 p-4 font-mono text-xs space-y-2">
            <div className="text-white/40 mb-1 text-[10px] tracking-widest uppercase">Asymmetry Formula</div>
            <div className="text-white/75">asym_factor = min(0.15, (ADX &minus; 15) &times; 0.006)</div>
            <div className="text-white/75">trend_side &nbsp;= 1.0 + asym_factor &nbsp;(wider)</div>
            <div className="text-white/75">counter_side = 1.0 &minus; asym_factor &nbsp;(tighter)</div>
            <div className="border-t border-white/8 pt-2 text-white/40 text-[10px]">
              Only applies when ADX &gt; 15. Max asymmetry caps at 0.15 (ADX ~40+).
            </div>
          </div>
        </Section>

        {/* ── S05: THE RISK ROW — THREE CELLS ── */}
        <Section label="05 — The Risk Row: Three Cells">
          <h2 className="text-2xl font-extrabold mb-2">
            What You See in the Command Center
          </h2>
          <p className="text-gray-400 mb-5 leading-relaxed">
            The Risk row in your Command Center has three cells. Each cell has one job.
            Together they give you the full picture: which side, what zone, and what to do.
          </p>
          <Anim5RiskRow />
          <div className="mt-5 space-y-3">
            {[
              { cell: 'Cell 1 — Side',     color: TEAL,  desc: 'Shows ▲ or ▼ — whether price is above or below the anchor EMA. Sets directional context for the zone reading.' },
              { cell: 'Cell 2 — Zone',     color: AMBER, desc: 'The active risk zone: SAFE / WATCH / CAUTION / DANGER. Color-coded. Updates every bar.' },
              { cell: 'Cell 3 — Guidance', color: TEAL,  desc: 'The exact sizing action: NORMAL SIZE / STAY ALERT / TIGHTEN STOPS / REDUCE SIZE. Includes dwell count and transition states.' },
            ].map(({ cell, color, desc }) => (
              <div key={cell} className="flex gap-3 rounded-lg border border-white/8 bg-white/2 p-3">
                <div className="w-1 rounded-full shrink-0 mt-1" style={{ background: color }} />
                <div>
                  <p className="text-xs font-bold font-mono mb-1" style={{ color }}>{cell}</p>
                  <p className="text-sm text-white/60 leading-snug">{desc}</p>
                </div>
              </div>
            ))}
          </div>
        </Section>

        {/* ── S06: SAFE ── */}
        <Section label="06 — SAFE: NORMAL SIZE">
          <h2 className="text-2xl font-extrabold mb-2">
            Inside the Inner Band &mdash;{' '}
            <span style={{ color: TEAL }}>Full Size</span>
          </h2>
          <p className="text-gray-400 mb-5 leading-relaxed">
            When price is inside the inner band, CIPHER says the position is within
            acceptable extension. No penalty applies. You are cleared for normal size.
          </p>
          <Anim6Safe />
          <div className="mt-4 rounded-lg border border-white/8 bg-white/2 p-4 text-sm text-white/65 leading-relaxed">
            SAFE does not mean the trade will work. It means the Risk Envelope has no
            current objection to your size. You still apply your own risk rules. CIPHER
            is telling you the envelope is not a constraint right now.
          </div>
        </Section>

        {/* ── S07: WATCH ── */}
        <Section label="07 — WATCH: STAY ALERT">
          <h2 className="text-2xl font-extrabold mb-2">
            Between Inner and Mid &mdash;{' '}
            <span style={{ color: AMBER }}>Heightened Awareness</span>
          </h2>
          <p className="text-gray-400 mb-5 leading-relaxed">
            Price has moved beyond the inner band. CIPHER is not yet calling for a size
            reduction but is signalling that extension is building. The dwell counter
            tells you how many bars you have been in this zone.
          </p>
          <Anim7Watch />
          <div className="mt-4 rounded-lg border-l-4 border-amber-400 bg-amber-400/6 px-4 py-3">
            <p className="text-sm text-amber-300 leading-relaxed">
              WATCH with a long dwell count (ESTABLISHED or ENTRENCHED) is more
              meaningful than a fresh WATCH spike. A single-bar WATCH is often noise.
              Ten bars of WATCH is a message.
            </p>
          </div>
        </Section>

        {/* ── S08: CAUTION ── */}
        <Section label="08 — CAUTION: TIGHTEN STOPS">
          <h2 className="text-2xl font-extrabold mb-2">
            Between Mid and Outer &mdash;{' '}
            <span style={{ color: AMBER }}>Stop Management Required</span>
          </h2>
          <p className="text-gray-400 mb-5 leading-relaxed">
            Price has extended significantly. CIPHER is not asking you to reduce size yet,
            but it is telling you that your stop placement needs to tighten.
            This is the last warning before DANGER.
          </p>
          <Anim8Caution />
          <div className="mt-4 grid grid-cols-2 gap-3 text-xs font-mono">
            {[
              { label: 'JUST HIT CAUTION', color: AMBER,  desc: 'First bar in zone. Transition state — act now.' },
              { label: 'CAUTION  3b',      color: AMBER,  desc: 'Dwell 3 bars (VISIT). Stay tight.' },
              { label: 'CAUTION  12b',     color: AMBER,  desc: 'Dwell 12 bars (ESTABLISHED). Overextension is sticky.' },
              { label: 'LEAVING DANGER',   color: TEAL,   desc: 'Transitioning back down. De-escalation underway.' },
            ].map(({ label, color, desc }) => (
              <div key={label} className="rounded-lg border border-white/8 bg-white/2 p-3">
                <p className="font-bold mb-1" style={{ color }}>{label}</p>
                <p className="text-white/45 text-[11px] leading-snug">{desc}</p>
              </div>
            ))}
          </div>
        </Section>

        {/* ── S09: DANGER ── */}
        <Section label="09 — DANGER: REDUCE SIZE">
          <h2 className="text-2xl font-extrabold mb-2">
            Beyond the Outer Band &mdash;{' '}
            <span style={{ color: MAGENTA }}>Size Down Now</span>
          </h2>
          <p className="text-gray-400 mb-5 leading-relaxed">
            Price has moved beyond the outer band. CIPHER&apos;s verdict is unambiguous:
            reduce position size. When the zone becomes entrenched (21+ bars), the
            Command Center escalates to bright red and adds a warning symbol.
          </p>
          <Anim9Danger />
          <div className="mt-4 space-y-3">
            {[
              { label: 'JUST HIT DANGER',  color: MAGENTA,       dwell: 'SPIKE',      bars: '1&ndash;2b',   desc: 'First bar beyond outer band. React immediately.' },
              { label: 'REDUCE SIZE  5b',  color: MAGENTA,       dwell: 'VISIT',      bars: '3&ndash;8b',   desc: 'Short visit. May be a wick. Watch for exit.' },
              { label: 'REDUCE SIZE  14b', color: MAGENTA,       dwell: 'ESTABLISHED',bars: '9&ndash;20b',  desc: 'Price is camped outside. Overextension confirmed.' },
              { label: 'REDUCE SIZE  25b ⚠', color: DANGER_BRIGHT, dwell: 'ENTRENCHED', bars: '21b+',       desc: 'Bright red. Maximum overextension. Immediate action.' },
            ].map(({ label, color, dwell, bars, desc }) => (
              <div key={label} className="flex items-start gap-3 rounded-lg border border-white/8 bg-white/2 p-3">
                <div className="shrink-0 text-center min-w-[90px]">
                  <p className="font-mono font-bold text-xs leading-tight" style={{ color }}>{label}</p>
                  <p className="font-mono text-[10px] text-white/30 mt-0.5" dangerouslySetInnerHTML={{ __html: bars }} />
                </div>
                <div className="border-l border-white/8 pl-3">
                  <p className="font-mono text-[10px] text-white/40 mb-0.5">{dwell}</p>
                  <p className="text-xs text-white/60 leading-snug">{desc}</p>
                </div>
              </div>
            ))}
          </div>
        </Section>

        {/* ── S10: ZONE TRANSITIONS — ESCALATION STORY ── */}
        <Section label="10 — Zone Transitions: The Escalation Story">
          <h2 className="text-2xl font-extrabold mb-2">
            CIPHER Narrates the Journey
          </h2>
          <p className="text-gray-400 mb-5 leading-relaxed">
            When price crosses a zone boundary, the guidance cell does not just update
            the zone name. It fires a specific transition message on that first bar.
            You are told not just where you are, but how you got there.
          </p>
          <Anim10Transitions />
          <div className="mt-5 grid grid-cols-2 gap-3 text-xs font-mono">
            {[
              { msg: 'JUST HIT DANGER',  dir: 'Escalation', color: MAGENTA,  desc: 'First bar price crosses outer band upward or downward.' },
              { msg: 'JUST HIT CAUTION', dir: 'Escalation', color: AMBER,    desc: 'First bar price crosses mid band.' },
              { msg: 'LEAVING DANGER',   dir: 'De-escalation', color: TEAL,  desc: 'First bar price re-enters CAUTION from DANGER.' },
              { msg: 'BACK TO SAFE',     dir: 'De-escalation', color: TEAL,  desc: 'First bar price returns fully inside inner band.' },
            ].map(({ msg, dir, color, desc }) => (
              <div key={msg} className="rounded-lg border border-white/8 bg-white/2 p-3">
                <p className="font-bold mb-0.5" style={{ color }}>{msg}</p>
                <p className="text-[10px] text-white/30 mb-1">{dir}</p>
                <p className="text-white/50 text-[11px] leading-snug">{desc}</p>
              </div>
            ))}
          </div>
        </Section>

        {/* ── S11: REGIME × ZONE COMBINATIONS ── */}
        <Section label="11 — Regime × Zone Combinations">
          <h2 className="text-2xl font-extrabold mb-2">
            12 Possible Combinations
          </h2>
          <p className="text-gray-400 mb-5 leading-relaxed">
            Three regimes times four zones gives twelve distinct states.
            Each has a different meaning. DANGER in a Range is very different
            from DANGER in a Volatile market. The regime context always matters.
          </p>
          <Anim11RegimeZoneMatrix />
          <div className="mt-4 rounded-lg border-l-4 border-amber-400 bg-amber-400/6 px-4 py-3">
            <p className="text-sm text-amber-300 leading-relaxed">
              The most dangerous combination is <span className="font-bold">RANGE + DANGER</span>.
              Bands are at their narrowest, so price is deeply overextended. A VOLATILE + DANGER
              reading, while alarming, represents a smaller absolute extension because the bands
              are wider. Context changes everything.
            </p>
          </div>
        </Section>

        {/* ── S12: MEAN REVERSION SCORE ── */}
        <Section label="12 — The Mean Reversion Score">
          <h2 className="text-2xl font-extrabold mb-2">
            Overextension on a 0&ndash;100 Scale
          </h2>
          <p className="text-gray-400 mb-5 leading-relaxed">
            Alongside the zone system, CIPHER calculates a continuous Mean Reversion
            Score every bar. It measures how far price has moved from fair value
            relative to the regime-adaptive outer band. Five plain-English labels
            replace the raw number.
          </p>
          <Anim12MRScore />
          <div className="mt-5 rounded-lg border border-white/8 bg-white/2 p-4 font-mono text-xs space-y-2">
            <div className="text-white/40 mb-1 text-[10px] tracking-widest uppercase">Score Labels</div>
            {[
              { range: '0&ndash;20',  label: 'NONE',     color: TEAL,    note: 'No reversion pressure.' },
              { range: '21&ndash;40', label: 'LOW',      color: TEAL,    note: 'Minor extension — normal.' },
              { range: '41&ndash;60', label: 'MODERATE', color: AMBER,   note: 'Approaching WATCH territory.' },
              { range: '61&ndash;80', label: 'HIGH',     color: AMBER,   note: 'mr_overextended = true. CAUTION or DANGER.' },
              { range: '81&ndash;100',label: 'EXTREME',  color: MAGENTA, note: 'Beyond outer band. Full overextension.' },
            ].map(({ range, label, color, note }) => (
              <div key={label} className="flex items-center gap-3">
                <span className="text-white/30 w-14 text-right" dangerouslySetInnerHTML={{ __html: range }} />
                <span className="font-bold w-20" style={{ color }}>{label}</span>
                <span className="text-white/45 text-[11px]">{note}</span>
              </div>
            ))}
          </div>
        </Section>

        {/* ── S13: SIZING RULES ACROSS REGIMES ── */}
        <Section label="13 — Sizing Rules Across All Three Regimes">
          <h2 className="text-2xl font-extrabold mb-2">
            Your Sizing Playbook
          </h2>
          <p className="text-gray-400 mb-5 leading-relaxed">
            These are the concrete sizing rules that follow from everything above.
            One rule per zone per regime. Use the Command Center Risk row to identify
            your current state, then apply the corresponding rule.
          </p>
          <Anim13SizingPlaybook />
        </Section>

        {/* ── S14: SIX MISTAKES ── */}
        <Section label="14 — Six Common Sizing Mistakes">
          <h2 className="text-2xl font-extrabold mb-2">
            What Operators Get Wrong
          </h2>
          <p className="text-gray-400 mb-6 leading-relaxed">
            These are the six most frequent sizing errors made by traders who have
            access to the Risk Envelope but do not use it correctly.
          </p>
          <div className="space-y-3">
            {[
              {
                n: '01',
                title: 'Ignoring the zone and sizing from habit',
                body: 'Entering full size regardless of the Risk row output. The Command Center is telling you something every bar. Choosing not to read it is choosing to trade blind.',
              },
              {
                n: '02',
                title: 'Treating WATCH as permission to be aggressive',
                body: 'WATCH means heightened awareness, not a green light. A long dwell in WATCH is a warning that CAUTION is approaching. It is not an invitation to add size.',
              },
              {
                n: '03',
                title: 'Applying RANGE-regime sizing logic in a TREND',
                body: 'A DANGER reading in a TREND is not the same as DANGER in a RANGE. In a TREND the outer band is wider, so a DANGER print represents less absolute overextension. Reduce size, but do not panic-exit as you would in a Range DANGER.',
              },
              {
                n: '04',
                title: 'Ignoring the dwell count',
                body: 'A one-bar DANGER spike is often a wick. Twenty-five bars entrenched in DANGER is a structural overextension. The dwell count changes the urgency of the action. Read it.',
              },
              {
                n: '05',
                title: 'Failing to tighten stops on the counter side in a trending market',
                body: 'Asymmetry means the counter-trend band is tighter than the trend-side band. A pullback in a Bull Trend hits CAUTION sooner. If you are long and price pulls back into CAUTION, your stop should already be tighter than it was at entry.',
              },
              {
                n: '06',
                title: 'Waiting for DANGER before acting',
                body: 'By the time the Command Center says REDUCE SIZE, you are already beyond the outer band. The zone transition messages — JUST HIT CAUTION, JUST HIT DANGER — are designed to give you one bar of notice. CAUTION is the signal to prepare. DANGER is the signal to act.',
              },
            ].map(({ n, title, body }) => (
              <div
                key={n}
                className="rounded-lg border border-red-500/25 bg-red-500/6 p-4"
              >
                <div className="flex items-start gap-3">
                  <span className="font-mono text-xs font-bold text-red-400/60 mt-0.5 shrink-0">{n}</span>
                  <div>
                    <p className="text-sm font-bold text-red-400 mb-1">{title}</p>
                    <p className="text-xs text-white/55 leading-relaxed">{body}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </Section>

        {/* ── S15: CHEAT SHEET ── */}
        <Section label="15 — Cheat Sheet">
          <h2 className="text-2xl font-extrabold mb-5">
            Regime-Based Sizing at a Glance
          </h2>
          <div className="rounded-xl border border-white/10 bg-white/2 divide-y divide-white/6">

            {/* Risk Zones */}
            <div className="p-4 space-y-3">
              <p className="text-[10px] font-mono font-bold tracking-widest text-amber-400/60 uppercase">Risk Zones</p>
              {[
                { zone: 'SAFE',    color: TEAL,    action: 'NORMAL SIZE',   note: '< 1.2× ATR from anchor' },
                { zone: 'WATCH',   color: AMBER,   action: 'STAY ALERT',   note: '1.2 – 2.35× ATR' },
                { zone: 'CAUTION', color: AMBER,   action: 'TIGHTEN STOPS',note: '2.35 – 3.5× ATR' },
                { zone: 'DANGER',  color: MAGENTA, action: 'REDUCE SIZE',  note: '> 3.5× ATR' },
              ].map(({ zone, color, action, note }) => (
                <div key={zone} className="flex items-center justify-between text-xs font-mono">
                  <span className="font-bold w-20" style={{ color }}>{zone}</span>
                  <span className="text-white/70 font-semibold">&rarr; {action}</span>
                  <span className="text-white/30 text-right text-[11px]">{note}</span>
                </div>
              ))}
            </div>

            {/* Band Scale */}
            <div className="p-4 space-y-2">
              <p className="text-[10px] font-mono font-bold tracking-widest text-amber-400/60 uppercase mb-3">Band Scale</p>
              {[
                { regime: 'RANGE',    scale: '0.85×',       color: MAGENTA, note: 'Narrowest — tightest zones' },
                { regime: 'TREND',    scale: '0.85 – 1.25×',color: TEAL,    note: 'Scales with ADX' },
                { regime: 'VOLATILE', scale: '+ 0.10 bonus', color: AMBER,  note: 'Widest — most tolerant' },
              ].map(({ regime, scale, color, note }) => (
                <div key={regime} className="flex items-center justify-between text-xs font-mono">
                  <span className="font-bold w-20" style={{ color }}>{regime}</span>
                  <span className="text-white/70">{scale}</span>
                  <span className="text-white/30 text-[11px]">{note}</span>
                </div>
              ))}
            </div>

            {/* Dwell Phases */}
            <div className="p-4 space-y-2">
              <p className="text-[10px] font-mono font-bold tracking-widest text-amber-400/60 uppercase mb-3">Dwell Phases</p>
              {[
                { phase: 'SPIKE',       bars: '1–2b',  note: 'Often noise. Watch.' },
                { phase: 'VISIT',       bars: '3–8b',  note: 'Real touch. Respect it.' },
                { phase: 'ESTABLISHED', bars: '9–20b', note: 'Sticky overextension.' },
                { phase: 'ENTRENCHED',  bars: '21b+',  note: 'Red alert. Act now.' },
              ].map(({ phase, bars, note }) => (
                <div key={phase} className="flex items-center gap-3 text-xs font-mono">
                  <span className="text-white/60 font-bold w-28">{phase}</span>
                  <span className="text-white/35 w-12">{bars}</span>
                  <span className="text-white/40 text-[11px]">{note}</span>
                </div>
              ))}
            </div>

            {/* MR Score */}
            <div className="p-4 space-y-2">
              <p className="text-[10px] font-mono font-bold tracking-widest text-amber-400/60 uppercase mb-3">Mean Reversion Score</p>
              <div className="flex items-center gap-2 text-[11px] font-mono text-white/40">
                {[
                  { label: 'NONE', color: TEAL },
                  { label: 'LOW', color: TEAL },
                  { label: 'MODERATE', color: AMBER },
                  { label: 'HIGH', color: AMBER },
                  { label: 'EXTREME', color: MAGENTA },
                ].map(({ label, color }, i, arr) => (
                  <span key={label}>
                    <span style={{ color }} className="font-bold">{label}</span>
                    {i < arr.length - 1 && <span className="text-white/20 mx-1">&rarr;</span>}
                  </span>
                ))}
              </div>
              <p className="text-[11px] text-white/35 font-mono">Overextended flag fires at score &gt; 60 (HIGH or EXTREME)</p>
            </div>

            {/* Asymmetry */}
            <div className="p-4">
              <p className="text-[10px] font-mono font-bold tracking-widest text-amber-400/60 uppercase mb-3">Directional Asymmetry</p>
              <div className="space-y-1.5 text-xs font-mono text-white/55">
                <p>Bull Trend &rarr; upper band wider, lower tighter. Pullbacks hit CAUTION sooner.</p>
                <p>Bear Trend &rarr; lower band wider, upper tighter. Bounces hit CAUTION sooner.</p>
                <p className="text-white/30 text-[11px]">Only active when ADX &gt; 15. Max factor 0.15 at ADX ~40+.</p>
              </div>
            </div>

          </div>
        </Section>

        {/* ── S16: SCENARIO GAME ── */}
        <Section label="16 — Scenario Game">
          <h2 className="text-2xl font-extrabold mb-2">
            Sizing Operator: <span style={{ color: AMBER }}>5 Live Scenarios</span>
          </h2>
          <p className="text-gray-400 mb-6 leading-relaxed">
            Read the Command Center output. Make the correct sizing call.
          </p>

          {!gameDone ? (
            <div className="space-y-5">
              {/* Progress */}
              <div className="flex items-center justify-between text-xs font-mono text-white/35">
                <span>Round {gameStep + 1} of {gameRounds.length}</span>
                <span style={{ color: AMBER }}>{gameScore} correct</span>
              </div>
              <div className="w-full h-1 bg-white/8 rounded-full overflow-hidden">
                <div
                  className="h-full rounded-full transition-all duration-500"
                  style={{ width: `${((gameStep) / gameRounds.length) * 100}%`, background: AMBER }}
                />
              </div>

              {/* Scenario */}
              <div className="rounded-xl border border-white/10 bg-white/2 p-5">
                <p className="text-xs font-mono font-bold tracking-widest text-amber-400/60 uppercase mb-3">Scenario</p>
                <p className="text-sm text-white/85 leading-relaxed">{gameRounds[gameStep].scenario}</p>
              </div>

              {/* Options */}
              <div className="space-y-3">
                {gameRounds[gameStep].options.map(opt => {
                  const isSelected = gameSelected === opt.id
                  const isCorrect  = opt.correct
                  let borderColor  = 'rgba(255,255,255,0.08)'
                  let bgColor      = 'transparent'
                  let textColor    = 'rgba(255,255,255,0.75)'
                  if (gameRevealed) {
                    if (isCorrect)            { borderColor = TEAL + '70';    bgColor = 'rgba(38,166,154,0.10)'; textColor = '#fff' }
                    else if (isSelected)      { borderColor = MAGENTA + '70'; bgColor = 'rgba(239,83,80,0.10)';  textColor = '#fff' }
                    else                      { textColor = 'rgba(255,255,255,0.30)' }
                  } else if (isSelected) {
                    borderColor = AMBER + '70'; bgColor = 'rgba(255,179,0,0.08)'
                  }
                  return (
                    <button
                      key={opt.id}
                      onClick={() => handleGameSelect(opt.id)}
                      disabled={gameRevealed}
                      className="w-full text-left rounded-xl border p-4 text-sm leading-relaxed transition-all duration-200 disabled:cursor-default"
                      style={{ borderColor, background: bgColor, color: textColor }}
                    >
                      <span className="font-mono font-bold text-xs mr-2 opacity-50">{opt.id.toUpperCase()}.</span>
                      {opt.text}
                    </button>
                  )
                })}
              </div>

              {/* Explanation */}
              {gameRevealed && (
                <motion.div
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="rounded-xl border border-white/10 bg-white/2 p-4"
                >
                  <p className="text-xs font-mono font-bold tracking-widest mb-2"
                    style={{ color: gameRounds[gameStep].options.find(o => o.id === gameSelected)?.correct ? TEAL : MAGENTA }}>
                    {gameRounds[gameStep].options.find(o => o.id === gameSelected)?.correct ? 'CORRECT' : 'INCORRECT'}
                  </p>
                  <p className="text-sm text-white/65 leading-relaxed">
                    {gameRounds[gameStep].options.find(o => o.id === gameSelected)?.explanation}
                  </p>
                  <button
                    onClick={handleGameNext}
                    className="mt-4 px-5 py-2 rounded-lg text-xs font-bold font-mono tracking-widest transition-opacity hover:opacity-80"
                    style={{ background: AMBER, color: '#060a12' }}
                  >
                    {gameStep < gameRounds.length - 1 ? 'NEXT ROUND →' : 'SEE RESULTS'}
                  </button>
                </motion.div>
              )}
            </div>
          ) : (
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              className="rounded-xl border border-white/10 bg-white/2 p-6 text-center space-y-4"
            >
              <p className="text-xs font-mono text-white/35 tracking-widest uppercase">Game Complete</p>
              <p className="text-4xl font-extrabold" style={{ color: AMBER }}>{gameScore}<span className="text-white/30 text-2xl"> / {gameRounds.length}</span></p>
              <p className="text-sm text-white/55">
                {gameScore === 5 ? 'Perfect score. You read the Risk Envelope with operator precision.' :
                 gameScore >= 3 ? 'Solid read. Review the scenarios you missed before the quiz.' :
                 'Review the sizing rules above and retry the quiz.'}
              </p>
            </motion.div>
          )}
        </Section>

        {/* ── S17: QUIZ + CERTIFICATE ── */}
        <Section label="17 — Knowledge Check">
          <h2 className="text-2xl font-extrabold mb-2">
            Sizing Operator <span style={{ color: AMBER }}>Certification</span>
          </h2>
          <p className="text-gray-400 mb-6 leading-relaxed">
            8 questions. Score 66% or above to earn the Sizing Operator certificate.
          </p>

          {!quizDone ? (
            <div className="space-y-5">
              {/* Progress */}
              <div className="flex items-center justify-between text-xs font-mono text-white/35">
                <span>Question {quizStep + 1} of {quizQuestions.length}</span>
                <span style={{ color: AMBER }}>{quizScore} correct</span>
              </div>
              <div className="w-full h-1 bg-white/8 rounded-full overflow-hidden">
                <div
                  className="h-full rounded-full transition-all duration-500"
                  style={{ width: `${(quizStep / quizQuestions.length) * 100}%`, background: AMBER }}
                />
              </div>

              {/* Question */}
              <div className="rounded-xl border border-white/10 bg-white/2 p-5">
                <p className="text-xs font-mono font-bold tracking-widest text-amber-400/60 uppercase mb-3">Question {quizStep + 1}</p>
                <p className="text-sm text-white/85 leading-relaxed">{quizQuestions[quizStep].question}</p>
              </div>

              {/* Options */}
              <div className="space-y-3">
                {quizQuestions[quizStep].options.map(opt => {
                  const isSelected = quizSelected === opt.id
                  const isCorrect  = opt.id === quizQuestions[quizStep].correct
                  let borderColor  = 'rgba(255,255,255,0.08)'
                  let bgColor      = 'transparent'
                  let textColor    = 'rgba(255,255,255,0.75)'
                  if (quizRevealed) {
                    if (isCorrect)       { borderColor = TEAL + '70';    bgColor = 'rgba(38,166,154,0.10)'; textColor = '#fff' }
                    else if (isSelected) { borderColor = MAGENTA + '70'; bgColor = 'rgba(239,83,80,0.10)';  textColor = '#fff' }
                    else                 { textColor = 'rgba(255,255,255,0.30)' }
                  } else if (isSelected) {
                    borderColor = AMBER + '70'; bgColor = 'rgba(255,179,0,0.08)'
                  }
                  return (
                    <button
                      key={opt.id}
                      onClick={() => handleQuizSelect(opt.id)}
                      disabled={quizRevealed}
                      className="w-full text-left rounded-xl border p-4 text-sm leading-relaxed transition-all duration-200 disabled:cursor-default"
                      style={{ borderColor, background: bgColor, color: textColor }}
                    >
                      <span className="font-mono font-bold text-xs mr-2 opacity-50">{opt.id.toUpperCase()}.</span>
                      {opt.text}
                    </button>
                  )
                })}
              </div>

              {/* Explanation */}
              {quizRevealed && (
                <motion.div
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="rounded-xl border border-white/10 bg-white/2 p-4"
                >
                  <p className="text-xs font-mono font-bold tracking-widest mb-2"
                    style={{ color: quizSelected === quizQuestions[quizStep].correct ? TEAL : MAGENTA }}>
                    {quizSelected === quizQuestions[quizStep].correct ? 'CORRECT' : 'INCORRECT'}
                  </p>
                  <p className="text-sm text-white/65 leading-relaxed">{quizQuestions[quizStep].explanation}</p>
                  <button
                    onClick={handleQuizNext}
                    className="mt-4 px-5 py-2 rounded-lg text-xs font-bold font-mono tracking-widest transition-opacity hover:opacity-80"
                    style={{ background: AMBER, color: '#060a12' }}
                  >
                    {quizStep < quizQuestions.length - 1 ? 'NEXT QUESTION →' : 'SEE RESULTS'}
                  </button>
                </motion.div>
              )}
            </div>
          ) : (
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-6"
            >
              {/* Score card */}
              <div className="rounded-xl border border-white/10 bg-white/2 p-6 text-center space-y-3">
                <p className="text-xs font-mono text-white/35 tracking-widest uppercase">Quiz Complete</p>
                <p className="text-4xl font-extrabold" style={{ color: quizPassed ? TEAL : MAGENTA }}>
                  {Math.round((quizScore / quizQuestions.length) * 100)}%
                  <span className="text-white/30 text-xl ml-2">{quizScore}/{quizQuestions.length}</span>
                </p>
                <p className="text-sm" style={{ color: quizPassed ? TEAL : MAGENTA }}>
                  {quizPassed ? 'Passed — Sizing Operator certification earned.' : 'Below 66% — review and retry when ready.'}
                </p>
              </div>

              {/* Certificate */}
              {quizPassed && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.3, duration: 0.5 }}
                  className="rounded-2xl p-px"
                  style={{
                    background: 'conic-gradient(from 180deg, #26A69A, #FFB300, #EF5350, #FFB300, #26A69A)',
                  }}
                >
                  <div
                    className="rounded-2xl p-8 text-center space-y-4"
                    style={{ background: 'linear-gradient(135deg, #0a0f1a 0%, #060a12 100%)' }}
                  >
                    {/* Crown */}
                    <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-amber-400/30 bg-amber-400/8">
                      <span className="text-amber-400 text-sm">&#9812;</span>
                      <span className="text-amber-400 text-xs font-bold tracking-widest font-mono">ATLAS ACADEMY</span>
                      <span className="text-amber-400 text-sm">&#9812;</span>
                    </div>

                    <div>
                      <p className="text-xs font-mono text-white/30 tracking-widest uppercase mb-2">Certificate of Completion</p>
                      <h3 className="text-2xl font-extrabold" style={{ color: AMBER }}>Sizing Operator</h3>
                      <p className="text-sm text-white/50 mt-1">Level 11 &middot; Lesson 7 &middot; Regime-Based Position Sizing</p>
                    </div>

                    <div className="border-t border-b border-white/8 py-4 space-y-1">
                      <p className="text-xs text-white/35 font-mono">This certifies mastery of</p>
                      <p className="text-sm text-white/70 leading-relaxed">
                        CIPHER&apos;s Risk Envelope system &mdash; band scaling, zone classification,
                        dwell phases, directional asymmetry, and regime-adaptive position sizing.
                      </p>
                    </div>

                    <div className="font-mono text-xs space-y-1">
                      <p className="text-white/25">Certificate Code</p>
                      <p className="font-bold tracking-widest" style={{ color: AMBER }}>{certCode}</p>
                    </div>
                  </div>
                </motion.div>
              )}
            </motion.div>
          )}
        </Section>

      </div>

      {/* ── GOLD FOOTER ── */}
      <div
        className="border-t border-white/6 mt-8 py-12 text-center"
        style={{ background: 'linear-gradient(to bottom, transparent, rgba(255,179,0,0.04))' }}
      >
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-amber-400/20 bg-amber-400/5 mb-4">
          <span className="text-amber-400 text-xs">&#9812;</span>
          <span className="text-amber-400 text-xs font-bold tracking-widest font-mono">CIPHER PRO MASTERY</span>
          <span className="text-amber-400 text-xs">&#9812;</span>
        </div>
        <p className="text-sm text-white/30 font-mono">Level 11 &middot; Lesson 7 of 20</p>
        <p className="text-xs text-white/20 mt-2 font-mono tracking-widest">
          &ldquo;We Show You WHY, Not Just What.&rdquo;
        </p>
      </div>

    </main>
    </>
  )
}

// ─── ANIM 5: RISK ROW THREE CELLS ─────────────────────────────────────────────
function Anim5RiskRow() {
  const STATES = [
    { side: '\u25B2', zone: 'SAFE',    guidance: 'NORMAL SIZE',   dwell: '',     zoneClr: TEAL,          guideClr: 'rgba(255,255,255,0.4)' },
    { side: '\u25B2', zone: 'WATCH',   guidance: 'STAY ALERT',    dwell: '2b',   zoneClr: AMBER,         guideClr: AMBER },
    { side: '\u25B2', zone: 'CAUTION', guidance: 'JUST HIT CAUTION', dwell: '', zoneClr: AMBER,         guideClr: AMBER },
    { side: '\u25B2', zone: 'CAUTION', guidance: 'TIGHTEN STOPS', dwell: '12b',  zoneClr: AMBER,         guideClr: AMBER },
    { side: '\u25B2', zone: 'DANGER',  guidance: 'JUST HIT DANGER', dwell: '',  zoneClr: MAGENTA,       guideClr: MAGENTA },
    { side: '\u25B2', zone: 'DANGER',  guidance: 'REDUCE SIZE',   dwell: '5b',   zoneClr: MAGENTA,       guideClr: MAGENTA },
    { side: '\u25B2', zone: 'DANGER',  guidance: 'REDUCE SIZE \u26A0', dwell: '25b', zoneClr: MAGENTA,  guideClr: DANGER_BRIGHT },
    { side: '\u25B2', zone: 'DANGER',  guidance: 'LEAVING DANGER',dwell: '',     zoneClr: MAGENTA,       guideClr: TEAL },
    { side: '\u25B2', zone: 'SAFE',    guidance: 'BACK TO SAFE',  dwell: '',     zoneClr: TEAL,          guideClr: TEAL },
  ]

  const [idx, setIdx] = useState(0)
  const [playing, setPlaying] = useState(true)
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null)

  useEffect(() => {
    if (!playing) return
    timerRef.current = setTimeout(() => setIdx(i => (i + 1) % STATES.length), 1600)
    return () => { if (timerRef.current) clearTimeout(timerRef.current) }
  }, [idx, playing])

  const s = STATES[idx]

  return (
    <div className="space-y-3">
      {/* Simulated CC row */}
      <div className="rounded-xl border border-white/10 bg-[#0d1420] overflow-hidden">
        <div className="px-4 py-2 border-b border-white/6">
          <p className="text-[10px] font-mono text-white/25 tracking-widest uppercase">Command Center &mdash; Risk Row</p>
        </div>
        <div className="flex items-center gap-0 font-mono text-xs">
          {/* Cell 1 - Side */}
          <div className="flex-1 text-center py-3 border-r border-white/8">
            <p className="text-[10px] text-white/25 mb-1">SIDE</p>
            <p className="font-bold text-sm" style={{ color: TEAL }}>{s.side}</p>
          </div>
          {/* Cell 2 - Zone */}
          <div className="flex-1 text-center py-3 border-r border-white/8">
            <p className="text-[10px] text-white/25 mb-1">ZONE</p>
            <p className="font-bold text-sm transition-colors duration-300" style={{ color: s.zoneClr }}>{s.zone}</p>
          </div>
          {/* Cell 3 - Guidance */}
          <div className="flex-1 text-center py-3">
            <p className="text-[10px] text-white/25 mb-1">GUIDANCE</p>
            <p className="font-bold text-xs transition-colors duration-300" style={{ color: s.guideClr }}>
              {s.guidance}{s.dwell ? <span className="text-white/30 ml-1">{s.dwell}</span> : null}
            </p>
          </div>
        </div>
      </div>

      {/* State label */}
      <div className="flex items-center justify-between">
        <p className="text-xs font-mono text-white/35">{idx + 1} / {STATES.length} states</p>
        <div className="flex gap-2">
          <button
            onClick={() => setIdx(i => (i - 1 + STATES.length) % STATES.length)}
            className="px-3 py-1 rounded text-xs font-mono border border-white/10 text-white/40 hover:text-white/70 transition-colors"
          >&#8592;</button>
          <button
            onClick={() => setPlaying(p => !p)}
            className="px-3 py-1 rounded text-xs font-mono border border-white/10 text-white/40 hover:text-white/70 transition-colors"
          >{playing ? '\u23F8' : '\u25B6'}</button>
          <button
            onClick={() => setIdx(i => (i + 1) % STATES.length)}
            className="px-3 py-1 rounded text-xs font-mono border border-white/10 text-white/40 hover:text-white/70 transition-colors"
          >&#8594;</button>
        </div>
      </div>

      {/* Dot indicators */}
      <div className="flex gap-1.5 justify-center">
        {STATES.map((_, i) => (
          <button key={i} onClick={() => setIdx(i)}
            className="w-1.5 h-1.5 rounded-full transition-all"
            style={{ background: i === idx ? AMBER : 'rgba(255,255,255,0.15)' }}
          />
        ))}
      </div>
    </div>
  )
}

// ─── ANIM 6: SAFE STATE ────────────────────────────────────────────────────────
function Anim6Safe() {
  const draw = (ctx: CanvasRenderingContext2D, w: number, h: number, frame: number) => {
    drawGrid(ctx, w, h)
    const pulse = Math.sin(frame * 0.05) * 0.5 + 0.5
    const scale = 1.0
    const ANCHOR_N = 0.50; const ATR_N = 0.055
    function py(n: number) { return h * (1 - n * 0.78 - 0.11) }
    const anchor = py(ANCHOR_N); const atrPx = ATR_N * h * 0.78
    const iU = anchor - atrPx * 1.2 * scale; const iL = anchor + atrPx * 1.2 * scale
    const mU = anchor - atrPx * 2.35 * scale; const mL = anchor + atrPx * 2.35 * scale
    const oU = anchor - atrPx * 3.5 * scale; const oL = anchor + atrPx * 3.5 * scale

    // Dim outer zones
    ctx.fillStyle = 'rgba(239,83,80,0.05)'; ctx.fillRect(0, Math.max(0,oU), w, Math.max(0,mU-oU)); ctx.fillRect(0,mL,w,Math.max(0,oL-mL))
    ctx.fillStyle = 'rgba(255,179,0,0.05)'; ctx.fillRect(0,mU,w,iU-mU); ctx.fillRect(0,iL,w,mL-iL)
    // SAFE zone glowing
    ctx.fillStyle = `rgba(38,166,154,${0.12 + pulse * 0.08})`
    ctx.fillRect(0, iU, w, iL - iU)

    // Lines dim
    [[oU,MAGENTA],[oL,MAGENTA],[mU,AMBER],[mL,AMBER]].forEach(([y, c]) => {
      ctx.save(); ctx.strokeStyle = c as string; ctx.globalAlpha = 0.2; ctx.lineWidth = 1; ctx.setLineDash([4,4])
      ctx.beginPath(); ctx.moveTo(0,y as number); ctx.lineTo(w,y as number); ctx.stroke(); ctx.setLineDash([]); ctx.restore()
    })
    // Inner lines bright
    [[iU,TEAL],[iL,TEAL]].forEach(([y, c]) => {
      ctx.save(); ctx.strokeStyle = c as string; ctx.globalAlpha = 0.7; ctx.lineWidth = 1.5; ctx.setLineDash([4,4])
      ctx.beginPath(); ctx.moveTo(0,y as number); ctx.lineTo(w,y as number); ctx.stroke(); ctx.setLineDash([]); ctx.restore()
    })

    // Price dot inside safe zone
    const priceY = anchor - atrPx * 0.6
    ctx.save(); ctx.shadowColor = TEAL; ctx.shadowBlur = 10 + pulse * 8
    ctx.fillStyle = TEAL; ctx.beginPath(); ctx.arc(w / 2, priceY, 5, 0, Math.PI * 2); ctx.fill(); ctx.restore()

    // Label
    ctx.fillStyle = `rgba(38,166,154,${0.7 + pulse * 0.3})`; ctx.font = 'bold 13px monospace'; ctx.textAlign = 'center'
    ctx.fillText('SAFE — NORMAL SIZE', w / 2, priceY - 18); ctx.textAlign = 'left'

    // CC row mock at bottom
    const rowY = h - 36
    ctx.fillStyle = 'rgba(13,20,32,0.9)'; ctx.fillRect(0, rowY, w, 36)
    ctx.strokeStyle = 'rgba(255,255,255,0.06)'; ctx.lineWidth = 1
    ctx.beginPath(); ctx.moveTo(0,rowY); ctx.lineTo(w,rowY); ctx.stroke()
    ctx.font = '10px monospace'; ctx.textAlign = 'left'
    ctx.fillStyle = 'rgba(255,255,255,0.3)'; ctx.fillText('Risk', 12, rowY + 14)
    ctx.fillStyle = TEAL; ctx.font = 'bold 11px monospace'; ctx.fillText('\u25B2 SAFE', 50, rowY + 14)
    ctx.fillStyle = 'rgba(255,255,255,0.3)'; ctx.fillText('\u2192', 105, rowY + 14)
    ctx.fillStyle = 'rgba(255,255,255,0.55)'; ctx.fillText('NORMAL SIZE', 120, rowY + 14)
  }

  return <AnimScene draw={draw} height={200} />
}

// ─── ANIM 7: WATCH STATE ───────────────────────────────────────────────────────
function Anim7Watch() {
  const draw = (ctx: CanvasRenderingContext2D, w: number, h: number, frame: number) => {
    drawGrid(ctx, w, h)
    const pulse = Math.sin(frame * 0.06) * 0.5 + 0.5
    const scale = 1.0
    const ANCHOR_N = 0.50; const ATR_N = 0.055
    function py(n: number) { return h * (1 - n * 0.78 - 0.11) }
    const anchor = py(ANCHOR_N); const atrPx = ATR_N * h * 0.78
    const iU = anchor - atrPx * 1.2 * scale; const iL = anchor + atrPx * 1.2 * scale
    const mU = anchor - atrPx * 2.35 * scale; const mL = anchor + atrPx * 2.35 * scale
    const oU = anchor - atrPx * 3.5 * scale; const oL = anchor + atrPx * 3.5 * scale

    ctx.fillStyle = 'rgba(239,83,80,0.05)'; ctx.fillRect(0,Math.max(0,oU),w,Math.max(0,mU-oU)); ctx.fillRect(0,mL,w,Math.max(0,oL-mL))
    // WATCH zone glowing
    ctx.fillStyle = `rgba(255,179,0,${0.10 + pulse * 0.07})`
    ctx.fillRect(0, mU, w, iU - mU); ctx.fillRect(0, iL, w, mL - iL)
    ctx.fillStyle = 'rgba(38,166,154,0.05)'; ctx.fillRect(0, iU, w, iL - iU)

    [[oU,MAGENTA],[oL,MAGENTA]].forEach(([y,c]) => {
      ctx.save(); ctx.strokeStyle=c as string; ctx.globalAlpha=0.2; ctx.lineWidth=1; ctx.setLineDash([4,4])
      ctx.beginPath(); ctx.moveTo(0,y as number); ctx.lineTo(w,y as number); ctx.stroke(); ctx.setLineDash([]); ctx.restore()
    })
    [[mU,AMBER],[mL,AMBER],[iU,TEAL],[iL,TEAL]].forEach(([y,c]) => {
      ctx.save(); ctx.strokeStyle=c as string; ctx.globalAlpha=0.6; ctx.lineWidth=1.5; ctx.setLineDash([4,4])
      ctx.beginPath(); ctx.moveTo(0,y as number); ctx.lineTo(w,y as number); ctx.stroke(); ctx.setLineDash([]); ctx.restore()
    })

    // Price dot in WATCH zone
    const priceY = iU - atrPx * 0.4
    ctx.save(); ctx.shadowColor = AMBER; ctx.shadowBlur = 10 + pulse * 8
    ctx.fillStyle = AMBER; ctx.beginPath(); ctx.arc(w/2, priceY, 5, 0, Math.PI*2); ctx.fill(); ctx.restore()
    ctx.fillStyle = `rgba(255,179,0,${0.7+pulse*0.3})`; ctx.font='bold 13px monospace'; ctx.textAlign='center'
    ctx.fillText('WATCH — STAY ALERT  2b', w/2, priceY-18); ctx.textAlign='left'

    // CC row
    const rowY = h - 36
    ctx.fillStyle='rgba(13,20,32,0.9)'; ctx.fillRect(0,rowY,w,36)
    ctx.strokeStyle='rgba(255,255,255,0.06)'; ctx.lineWidth=1
    ctx.beginPath(); ctx.moveTo(0,rowY); ctx.lineTo(w,rowY); ctx.stroke()
    ctx.font='10px monospace'; ctx.fillStyle='rgba(255,255,255,0.3)'; ctx.fillText('Risk',12,rowY+14)
    ctx.fillStyle=AMBER; ctx.font='bold 11px monospace'; ctx.fillText('\u25B2 WATCH',50,rowY+14)
    ctx.fillStyle='rgba(255,255,255,0.3)'; ctx.fillText('\u2192',108,rowY+14)
    ctx.fillStyle=AMBER; ctx.fillText('STAY ALERT',122,rowY+14)
    ctx.fillStyle='rgba(255,255,255,0.25)'; ctx.font='10px monospace'; ctx.fillText('2b',210,rowY+14)
  }

  return <AnimScene draw={draw} height={200} />
}

// ─── ANIM 8: CAUTION STATE ────────────────────────────────────────────────────
function Anim8Caution() {
  const draw = (ctx: CanvasRenderingContext2D, w: number, h: number, frame: number) => {
    drawGrid(ctx, w, h)
    const pulse = Math.sin(frame * 0.07) * 0.5 + 0.5
    const scale = 1.0
    const ANCHOR_N = 0.50; const ATR_N = 0.055
    function py(n: number) { return h * (1 - n * 0.78 - 0.11) }
    const anchor = py(ANCHOR_N); const atrPx = ATR_N * h * 0.78
    const iU = anchor - atrPx * 1.2 * scale; const iL = anchor + atrPx * 1.2 * scale
    const mU = anchor - atrPx * 2.35 * scale; const mL = anchor + atrPx * 2.35 * scale
    const oU = anchor - atrPx * 3.5 * scale; const oL = anchor + atrPx * 3.5 * scale

    ctx.fillStyle = 'rgba(239,83,80,0.06)'; ctx.fillRect(0,Math.max(0,oU),w,Math.max(0,mU-oU)); ctx.fillRect(0,mL,w,Math.max(0,oL-mL))
    // CAUTION zone glowing
    ctx.fillStyle = `rgba(255,179,0,${0.13 + pulse * 0.08})`
    ctx.fillRect(0, mU, w, iU-mU); ctx.fillRect(0, iL, w, mL-iL)
    ctx.fillStyle = 'rgba(38,166,154,0.04)'; ctx.fillRect(0,iU,w,iL-iU)

    [[iU,TEAL],[iL,TEAL]].forEach(([y,c]) => {
      ctx.save(); ctx.strokeStyle=c as string; ctx.globalAlpha=0.3; ctx.lineWidth=1; ctx.setLineDash([4,4])
      ctx.beginPath(); ctx.moveTo(0,y as number); ctx.lineTo(w,y as number); ctx.stroke(); ctx.setLineDash([]); ctx.restore()
    })
    [[mU,AMBER],[mL,AMBER]].forEach(([y,c]) => {
      ctx.save(); ctx.strokeStyle=c as string; ctx.globalAlpha=0.7; ctx.lineWidth=1.5; ctx.setLineDash([4,4])
      ctx.beginPath(); ctx.moveTo(0,y as number); ctx.lineTo(w,y as number); ctx.stroke(); ctx.setLineDash([]); ctx.restore()
    })
    [[oU,MAGENTA],[oL,MAGENTA]].forEach(([y,c]) => {
      ctx.save(); ctx.strokeStyle=c as string; ctx.globalAlpha=0.4; ctx.lineWidth=1; ctx.setLineDash([4,4])
      ctx.beginPath(); ctx.moveTo(0,y as number); ctx.lineTo(w,y as number); ctx.stroke(); ctx.setLineDash([]); ctx.restore()
    })

    // Price in CAUTION
    const priceY = mU + (iU - mU) * 0.4
    ctx.save(); ctx.shadowColor=AMBER; ctx.shadowBlur=12+pulse*8
    ctx.fillStyle=AMBER; ctx.beginPath(); ctx.arc(w/2,priceY,5,0,Math.PI*2); ctx.fill(); ctx.restore()
    ctx.fillStyle=`rgba(255,179,0,${0.7+pulse*0.3})`; ctx.font='bold 13px monospace'; ctx.textAlign='center'
    ctx.fillText('CAUTION — TIGHTEN STOPS  12b', w/2, priceY-18); ctx.textAlign='left'

    // CC row
    const rowY = h - 36
    ctx.fillStyle='rgba(13,20,32,0.9)'; ctx.fillRect(0,rowY,w,36)
    ctx.strokeStyle='rgba(255,255,255,0.06)'; ctx.lineWidth=1
    ctx.beginPath(); ctx.moveTo(0,rowY); ctx.lineTo(w,rowY); ctx.stroke()
    ctx.font='10px monospace'; ctx.fillStyle='rgba(255,255,255,0.3)'; ctx.fillText('Risk',12,rowY+14)
    ctx.fillStyle=AMBER; ctx.font='bold 11px monospace'; ctx.fillText('\u25B2 CAUTION',50,rowY+14)
    ctx.fillStyle='rgba(255,255,255,0.3)'; ctx.fillText('\u2192',118,rowY+14)
    ctx.fillStyle=AMBER; ctx.fillText('TIGHTEN STOPS',132,rowY+14)
    ctx.fillStyle='rgba(255,255,255,0.25)'; ctx.font='10px monospace'; ctx.fillText('12b',248,rowY+14)
  }

  return <AnimScene draw={draw} height={200} />
}

// ─── ANIM 9: DANGER STATE ─────────────────────────────────────────────────────
function Anim9Danger() {
  const [dwell, setDwell] = useState<'spike'|'visit'|'established'|'entrenched'>('visit')

  const DWELL_CFG = {
    spike:       { bars: 1,  label: 'SPIKE',       guidance: 'JUST HIT DANGER', color: MAGENTA,       guideColor: MAGENTA },
    visit:       { bars: 5,  label: 'VISIT',       guidance: 'REDUCE SIZE',      color: MAGENTA,       guideColor: MAGENTA },
    established: { bars: 14, label: 'ESTABLISHED', guidance: 'REDUCE SIZE',      color: MAGENTA,       guideColor: MAGENTA },
    entrenched:  { bars: 25, label: 'ENTRENCHED',  guidance: 'REDUCE SIZE \u26A0', color: MAGENTA,     guideColor: DANGER_BRIGHT },
  }

  const cfg = DWELL_CFG[dwell]

  const draw = (ctx: CanvasRenderingContext2D, w: number, h: number, frame: number) => {
    drawGrid(ctx, w, h)
    const pulse = Math.sin(frame * 0.08) * 0.5 + 0.5
    const isEntrenched = dwell === 'entrenched'
    const dangerPulse = isEntrenched ? (0.18 + pulse * 0.12) : (0.12 + pulse * 0.06)
    const scale = 1.0
    const ANCHOR_N = 0.50; const ATR_N = 0.055
    function py(n: number) { return h * (1 - n * 0.78 - 0.11) }
    const anchor = py(ANCHOR_N); const atrPx = ATR_N * h * 0.78
    const iU = anchor - atrPx * 1.2 * scale; const iL = anchor + atrPx * 1.2 * scale
    const mU = anchor - atrPx * 2.35 * scale; const mL = anchor + atrPx * 2.35 * scale
    const oU = anchor - atrPx * 3.5 * scale; const oL = anchor + atrPx * 3.5 * scale

    ctx.fillStyle='rgba(38,166,154,0.04)'; ctx.fillRect(0,iU,w,iL-iU)
    ctx.fillStyle='rgba(255,179,0,0.05)'; ctx.fillRect(0,mU,w,iU-mU); ctx.fillRect(0,iL,w,mL-iL)
    // DANGER glowing — entrenched pulses harder
    const dangerColor = isEntrenched ? DANGER_BRIGHT : MAGENTA
    ctx.fillStyle = `rgba(${isEntrenched?'255,23,68':'239,83,80'},${dangerPulse})`
    ctx.fillRect(0,Math.max(0,oU),w,Math.max(0,mU-oU)); ctx.fillRect(0,mL,w,Math.max(0,oL-mL))

    [[iU,TEAL],[iL,TEAL],[mU,AMBER],[mL,AMBER]].forEach(([y,c]) => {
      ctx.save(); ctx.strokeStyle=c as string; ctx.globalAlpha=0.3; ctx.lineWidth=1; ctx.setLineDash([4,4])
      ctx.beginPath(); ctx.moveTo(0,y as number); ctx.lineTo(w,y as number); ctx.stroke(); ctx.setLineDash([]); ctx.restore()
    })
    [[oU,dangerColor],[oL,dangerColor]].forEach(([y,c]) => {
      ctx.save(); ctx.strokeStyle=c as string; ctx.globalAlpha=0.7+pulse*0.2; ctx.lineWidth=isEntrenched?2:1.5; ctx.setLineDash([4,4])
      ctx.beginPath(); ctx.moveTo(0,y as number); ctx.lineTo(w,y as number); ctx.stroke(); ctx.setLineDash([]); ctx.restore()
    })

    // Price dot in DANGER
    const priceY = oU - atrPx * 0.3
    ctx.save(); ctx.shadowColor=dangerColor; ctx.shadowBlur=14+pulse*10
    ctx.fillStyle=dangerColor; ctx.beginPath(); ctx.arc(w/2,priceY,5,0,Math.PI*2); ctx.fill(); ctx.restore()
    ctx.fillStyle=`rgba(${isEntrenched?'255,23,68':'239,83,80'},${0.7+pulse*0.3})`
    ctx.font='bold 13px monospace'; ctx.textAlign='center'
    ctx.fillText(`DANGER — ${cfg.guidance}  ${cfg.bars}b`, w/2, priceY-18)
    ctx.textAlign='left'

    // CC row
    const rowY = h - 36
    ctx.fillStyle='rgba(13,20,32,0.9)'; ctx.fillRect(0,rowY,w,36)
    ctx.strokeStyle='rgba(255,255,255,0.06)'; ctx.lineWidth=1
    ctx.beginPath(); ctx.moveTo(0,rowY); ctx.lineTo(w,rowY); ctx.stroke()
    ctx.font='10px monospace'; ctx.fillStyle='rgba(255,255,255,0.3)'; ctx.fillText('Risk',12,rowY+14)
    ctx.fillStyle=MAGENTA; ctx.font='bold 11px monospace'; ctx.fillText('\u25B2 DANGER',50,rowY+14)
    ctx.fillStyle='rgba(255,255,255,0.3)'; ctx.fillText('\u2192',115,rowY+14)
    ctx.fillStyle=cfg.guideColor; ctx.fillText(cfg.guidance,129,rowY+14)
    if(cfg.bars>1){ctx.fillStyle='rgba(255,255,255,0.25)'; ctx.font='10px monospace'; ctx.fillText(cfg.bars+'b',129+ctx.measureText(cfg.guidance).width+6,rowY+14)}
  }

  return (
    <div className="space-y-3">
      <div className="flex gap-2">
        {(['spike','visit','established','entrenched'] as const).map(d => (
          <button
            key={d}
            onClick={() => setDwell(d)}
            className="flex-1 py-1.5 rounded-lg text-[10px] font-bold font-mono tracking-wider border transition-all"
            style={{
              background: dwell===d ? (d==='entrenched'?'rgba(255,23,68,0.15)':'rgba(239,83,80,0.12)') : 'transparent',
              color: dwell===d ? (d==='entrenched'?DANGER_BRIGHT:MAGENTA) : 'rgba(255,255,255,0.3)',
              borderColor: dwell===d ? (d==='entrenched'?DANGER_BRIGHT+'60':MAGENTA+'40') : 'rgba(255,255,255,0.08)',
            }}
          >
            {d.toUpperCase()}
          </button>
        ))}
      </div>
      <AnimScene draw={draw} deps={[dwell]} height={200} />
    </div>
  )
}

// ─── ANIM 10: ZONE TRANSITIONS ────────────────────────────────────────────────
function Anim10Transitions() {
  const SEQUENCE = [
    { zone: 'SAFE',    priceN: 0.55, guidance: 'NORMAL SIZE',    zoneClr: TEAL,    guideClr: 'rgba(255,255,255,0.4)', transition: false },
    { zone: 'WATCH',   priceN: 0.63, guidance: 'STAY ALERT',     zoneClr: AMBER,   guideClr: AMBER,   transition: false },
    { zone: 'CAUTION', priceN: 0.72, guidance: 'JUST HIT CAUTION', zoneClr: AMBER, guideClr: AMBER,   transition: true  },
    { zone: 'CAUTION', priceN: 0.73, guidance: 'TIGHTEN STOPS',  zoneClr: AMBER,   guideClr: AMBER,   transition: false },
    { zone: 'DANGER',  priceN: 0.83, guidance: 'JUST HIT DANGER', zoneClr: MAGENTA,guideClr: MAGENTA, transition: true  },
    { zone: 'DANGER',  priceN: 0.84, guidance: 'REDUCE SIZE',    zoneClr: MAGENTA, guideClr: MAGENTA, transition: false },
    { zone: 'CAUTION', priceN: 0.74, guidance: 'LEAVING DANGER', zoneClr: MAGENTA, guideClr: TEAL,    transition: true  },
    { zone: 'SAFE',    priceN: 0.52, guidance: 'BACK TO SAFE',   zoneClr: TEAL,    guideClr: TEAL,    transition: true  },
  ]

  const [step, setStep] = useState(0)
  const [playing, setPlaying] = useState(true)
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null)

  useEffect(() => {
    if (!playing) return
    timerRef.current = setTimeout(() => setStep(s => (s + 1) % SEQUENCE.length), 1400)
    return () => { if (timerRef.current) clearTimeout(timerRef.current) }
  }, [step, playing])

  const s = SEQUENCE[step]
  const scale = 1.0
  const ANCHOR_N = 0.50
  const ATR_N = 0.055

  const draw = (ctx: CanvasRenderingContext2D, w: number, h: number, frame: number) => {
    drawGrid(ctx, w, h)
    const pulse = Math.sin(frame * 0.07) * 0.5 + 0.5
    function py(n: number) { return h * (1 - n * 0.78 - 0.11) }
    const anchor = py(ANCHOR_N); const atrPx = ATR_N * h * 0.78
    const iU = anchor - atrPx * 1.2 * scale; const iL = anchor + atrPx * 1.2 * scale
    const mU = anchor - atrPx * 2.35 * scale; const mL = anchor + atrPx * 2.35 * scale
    const oU = anchor - atrPx * 3.5 * scale; const oL = anchor + atrPx * 3.5 * scale

    ctx.fillStyle = 'rgba(239,83,80,0.08)'; ctx.fillRect(0,Math.max(0,oU),w,Math.max(0,mU-oU)); ctx.fillRect(0,mL,w,Math.max(0,oL-mL))
    ctx.fillStyle = 'rgba(255,179,0,0.07)'; ctx.fillRect(0,mU,w,iU-mU); ctx.fillRect(0,iL,w,mL-iL)
    ctx.fillStyle = 'rgba(38,166,154,0.06)'; ctx.fillRect(0,iU,w,iL-iU)

    const allLines: [number, string][] = [[oU,MAGENTA],[oL,MAGENTA],[mU,AMBER],[mL,AMBER],[iU,TEAL],[iL,TEAL]]
    allLines.forEach(([y, c]) => {
      ctx.save(); ctx.strokeStyle=c as string; ctx.globalAlpha=0.4; ctx.lineWidth=1; ctx.setLineDash([4,4])
      ctx.beginPath(); ctx.moveTo(0,y as number); ctx.lineTo(w,y as number); ctx.stroke(); ctx.setLineDash([]); ctx.restore()
    })

    // Price dot
    const priceY = py(s.priceN)
    const dotColor = s.zoneClr
    const glow = s.transition ? (14 + pulse * 12) : (8 + pulse * 4)
    ctx.save(); ctx.shadowColor = dotColor; ctx.shadowBlur = glow
    ctx.fillStyle = dotColor; ctx.beginPath(); ctx.arc(w * 0.3, priceY, 5 + (s.transition ? pulse * 1.5 : 0), 0, Math.PI * 2); ctx.fill(); ctx.restore()

    // Transition flash ring
    if (s.transition) {
      ctx.save(); ctx.strokeStyle = dotColor; ctx.globalAlpha = 0.3 + pulse * 0.3
      ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(w * 0.3, priceY, 12 + pulse * 6, 0, Math.PI * 2); ctx.stroke(); ctx.restore()
    }

    // Step indicator dots at top
    const dotGap = (w - 40) / SEQUENCE.length
    SEQUENCE.forEach((_, i) => {
      ctx.fillStyle = i === step ? AMBER : (i < step ? 'rgba(255,179,0,0.3)' : 'rgba(255,255,255,0.1)')
      ctx.beginPath(); ctx.arc(20 + i * dotGap + dotGap / 2, 14, 3, 0, Math.PI * 2); ctx.fill()
    })

    // Anchor EMA
    ctx.save(); ctx.strokeStyle='rgba(255,255,255,0.15)'; ctx.lineWidth=1; ctx.setLineDash([6,3])
    ctx.beginPath(); ctx.moveTo(0,anchor); ctx.lineTo(w,anchor); ctx.stroke(); ctx.setLineDash([]); ctx.restore()
  }

  return (
    <div className="space-y-3">
      <AnimScene draw={draw} deps={[step]} height={210} />
      <div className="rounded-xl border border-white/10 bg-[#0d1420] overflow-hidden">
        <div className="flex items-center gap-0 font-mono text-xs">
          <div className="flex-1 text-center py-2.5 border-r border-white/8">
            <p className="text-[10px] text-white/25 mb-0.5">ZONE</p>
            <p className="font-bold text-sm transition-colors duration-300" style={{ color: s.zoneClr }}>{s.zone}</p>
          </div>
          <div className="flex-1 text-center py-2.5 border-r border-white/8">
            <p className="text-[10px] text-white/25 mb-0.5">GUIDANCE</p>
            <p className="font-bold text-xs transition-colors duration-300" style={{ color: s.guideClr }}>{s.guidance}</p>
          </div>
          <div className="flex-1 text-center py-2.5">
            <p className="text-[10px] text-white/25 mb-0.5">TYPE</p>
            <p className="font-bold text-xs" style={{ color: s.transition ? AMBER : 'rgba(255,255,255,0.3)' }}>{s.transition ? 'TRANSITION' : 'STEADY'}</p>
          </div>
        </div>
      </div>
      <div className="flex items-center justify-between">
        <p className="text-xs font-mono text-white/30">Step {step + 1} / {SEQUENCE.length}</p>
        <div className="flex gap-2">
          <button onClick={() => setStep(s => (s - 1 + SEQUENCE.length) % SEQUENCE.length)} className="px-3 py-1 rounded text-xs font-mono border border-white/10 text-white/40 hover:text-white/70 transition-colors">&#8592;</button>
          <button onClick={() => setPlaying(p => !p)} className="px-3 py-1 rounded text-xs font-mono border border-white/10 text-white/40 hover:text-white/70 transition-colors">{playing ? '\u23F8' : '\u25B6'}</button>
          <button onClick={() => setStep(s => (s + 1) % SEQUENCE.length)} className="px-3 py-1 rounded text-xs font-mono border border-white/10 text-white/40 hover:text-white/70 transition-colors">&#8594;</button>
        </div>
      </div>
    </div>
  )
}

// ─── ANIM 11: REGIME × ZONE MATRIX ───────────────────────────────────────────
function Anim11RegimeZoneMatrix() {
  const [hovered, setHovered] = useState<string | null>(null)

  const REGIMES = [
    { r: 'RANGE',    scale: 0.85, color: MAGENTA },
    { r: 'TREND',    scale: 1.15, color: TEAL },
    { r: 'VOLATILE', scale: 1.25, color: AMBER },
  ]
  const ZONES = [
    { z: 'SAFE',    color: TEAL,    action: 'NORMAL SIZE',   severity: 0 },
    { z: 'WATCH',   color: AMBER,   action: 'STAY ALERT',    severity: 1 },
    { z: 'CAUTION', color: AMBER,   action: 'TIGHTEN STOPS', severity: 2 },
    { z: 'DANGER',  color: MAGENTA, action: 'REDUCE SIZE',   severity: 3 },
  ]

  const NOTE: Record<string, string> = {
    'RANGE-SAFE':       'Clean entry zone.',
    'RANGE-WATCH':      'Building extension in tight market.',
    'RANGE-CAUTION':    'Significant overextension — tighten hard.',
    'RANGE-DANGER':     'Most dangerous combo. Bands narrow, price deep outside.',
    'TREND-SAFE':       'Healthy trend continuation zone.',
    'TREND-WATCH':      'Trend extension — normal but monitor.',
    'TREND-CAUTION':    'Pullback risk high. Tighten counter-side stop.',
    'TREND-DANGER':     'Overextended trend. Real but less severe than Range DANGER.',
    'VOLATILE-SAFE':    'Inside wide bands. Low immediate risk.',
    'VOLATILE-WATCH':   'Early extension in volatile conditions.',
    'VOLATILE-CAUTION': 'Meaningful but bands are wide — context matters.',
    'VOLATILE-DANGER':  'Extended in volatile market. Reduce but do not panic.',
  }

  const key = hovered
  const info = key ? NOTE[key] : null

  return (
    <div className="space-y-3">
      <div className="overflow-x-auto">
        <table className="w-full text-xs font-mono border-collapse">
          <thead>
            <tr>
              <th className="text-left text-white/30 font-normal pb-2 pr-3 text-[10px]">REGIME &darr; / ZONE &rarr;</th>
              {ZONES.map(({ z, color }) => (
                <th key={z} className="text-center pb-2 px-1 font-bold text-[11px]" style={{ color }}>{z}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {REGIMES.map(({ r, color: rColor }) => (
              <tr key={r}>
                <td className="font-bold pr-3 py-1.5 text-[11px]" style={{ color: rColor }}>{r}</td>
                {ZONES.map(({ z, color: zColor, action, severity }) => {
                  const k = `${r}-${z}`
                  const isHov = hovered === k
                  return (
                    <td key={z} className="py-1.5 px-1 text-center">
                      <button
                        onMouseEnter={() => setHovered(k)}
                        onMouseLeave={() => setHovered(null)}
                        onClick={() => setHovered(hovered === k ? null : k)}
                        className="rounded-lg border px-2 py-1.5 w-full transition-all text-[10px] font-bold leading-tight"
                        style={{
                          borderColor: isHov ? zColor + '80' : zColor + '25',
                          background: isHov ? zColor + '20' : zColor + '08',
                          color: isHov ? zColor : zColor + 'aa',
                        }}
                      >
                        {action.split(' ').map((word, i) => <span key={i} className="block">{word}</span>)}
                      </button>
                    </td>
                  )
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="rounded-lg border border-white/8 bg-white/2 px-4 py-3 min-h-[44px] flex items-center">
        {info
          ? <p className="text-sm text-white/70 leading-relaxed"><span className="font-bold font-mono text-amber-400">{hovered?.replace('-', ' + ')}</span> — {info}</p>
          : <p className="text-xs font-mono text-white/25">Tap any cell to read the operator note.</p>
        }
      </div>
    </div>
  )
}

// ─── ANIM 12: MEAN REVERSION SCORE ───────────────────────────────────────────
function Anim12MRScore() {
  const [score, setScore] = useState(45)

  const getLabel = (s: number) => s > 80 ? 'EXTREME' : s > 60 ? 'HIGH' : s > 40 ? 'MODERATE' : s > 20 ? 'LOW' : 'NONE'
  const getColor = (s: number) => s > 60 ? (s > 80 ? MAGENTA : AMBER) : TEAL
  const isOverext = score > 60

  const draw = (ctx: CanvasRenderingContext2D, w: number, h: number, frame: number) => {
    drawGrid(ctx, w, h)
    const pulse = Math.sin(frame * 0.06) * 0.5 + 0.5
    const barH = 28
    const barY = h / 2 - barH / 2
    const barW = w - 60

    // Track background
    ctx.fillStyle = 'rgba(255,255,255,0.05)'
    roundRect(ctx, 30, barY, barW, barH, 6)
    ctx.fill()

    // Filled portion
    const fillW = (score / 100) * barW
    const col = getColor(score)
    const grad = ctx.createLinearGradient(30, 0, 30 + fillW, 0)
    grad.addColorStop(0, TEAL + 'cc')
    grad.addColorStop(0.6, AMBER + 'cc')
    grad.addColorStop(1, (score > 80 ? MAGENTA : AMBER) + 'cc')
    ctx.fillStyle = grad
    roundRect(ctx, 30, barY, fillW, barH, 6)
    ctx.fill()

    // Glow on fill end
    if (score > 0) {
      ctx.save(); ctx.shadowColor = col; ctx.shadowBlur = 8 + pulse * 6
      ctx.fillStyle = col; ctx.beginPath(); ctx.arc(30 + fillW, barY + barH / 2, 5, 0, Math.PI * 2); ctx.fill(); ctx.restore()
    }

    // Threshold line at 60
    const threshX = 30 + (60 / 100) * barW
    ctx.save(); ctx.strokeStyle = AMBER; ctx.globalAlpha = 0.6; ctx.lineWidth = 1.5; ctx.setLineDash([3, 3])
    ctx.beginPath(); ctx.moveTo(threshX, barY - 6); ctx.lineTo(threshX, barY + barH + 6); ctx.stroke()
    ctx.setLineDash([]); ctx.restore()
    ctx.fillStyle = 'rgba(255,179,0,0.6)'; ctx.font = '9px monospace'; ctx.textAlign = 'center'
    ctx.fillText('OVEREXT', threshX, barY - 10); ctx.textAlign = 'left'

    // Zone marks below bar
    const marks = [0, 20, 40, 60, 80, 100]
    marks.forEach(m => {
      const x = 30 + (m / 100) * barW
      ctx.fillStyle = 'rgba(255,255,255,0.2)'; ctx.font = '9px monospace'; ctx.textAlign = 'center'
      ctx.fillText(String(m), x, barY + barH + 16)
    })
    ctx.textAlign = 'left'

    // Score display
    ctx.fillStyle = col; ctx.font = 'bold 22px monospace'; ctx.textAlign = 'center'
    ctx.fillText(String(score), w / 2, barY - 22)
    ctx.fillStyle = col; ctx.font = 'bold 13px monospace'
    ctx.fillText(getLabel(score), w / 2, barY - 8); ctx.textAlign = 'left'

    // Overextended flag
    if (isOverext) {
      ctx.fillStyle = `rgba(255,${score > 80 ? '83,80' : '179,0'},${0.15 + pulse * 0.1})`
      roundRect(ctx, 30, barY - 46, barW, 20, 5); ctx.fill()
      ctx.fillStyle = getColor(score); ctx.font = 'bold 10px monospace'; ctx.textAlign = 'center'
      ctx.fillText('mr_overextended = true  — Signals carry overextension context', w / 2, barY - 32)
      ctx.textAlign = 'left'
    }
  }

  return (
    <div className="space-y-4">
      <AnimScene draw={draw} deps={[score]} height={180} />
      <div className="space-y-2">
        <div className="flex items-center justify-between text-xs font-mono text-white/40">
          <span>0 — NONE</span>
          <span style={{ color: getColor(score) }} className="font-bold">{score} — {getLabel(score)}</span>
          <span>100 — EXTREME</span>
        </div>
        <input
          type="range" min={0} max={100} value={score}
          onChange={e => setScore(Number(e.target.value))}
          className="w-full accent-amber-400 cursor-pointer"
        />
      </div>
      <div className="rounded-lg border border-white/8 bg-white/2 px-4 py-3 text-xs font-mono text-white/50 leading-relaxed">
        {!isOverext && 'Score below 60 — no overextension flag. Signals read normally.'}
        {isOverext && score <= 80 && <><span style={{ color: AMBER }} className="font-bold">HIGH</span> — mr_overextended is active. Buy signals in this state carry an overextension warning in the tooltip.</>}
        {score > 80 && <><span style={{ color: MAGENTA }} className="font-bold">EXTREME</span> — price is beyond the outer band. Mean reversion pressure is at its highest reading.</>}
      </div>
    </div>
  )
}

// ─── ANIM 13: SIZING PLAYBOOK ─────────────────────────────────────────────────
function Anim13SizingPlaybook() {
  const [activeRegime, setActiveRegime] = useState<'RANGE' | 'TREND' | 'VOLATILE'>('RANGE')

  const RULES: Record<string, { zone: string; color: string; action: string; detail: string }[]> = {
    RANGE: [
      { zone: 'SAFE',    color: TEAL,    action: 'Full size permitted.',    detail: 'Bands narrow. Inside inner band means price is genuinely near fair value. No penalty.' },
      { zone: 'WATCH',   color: AMBER,   action: 'Reduce to 75% size.',     detail: 'Extension is building in a tight market. This is the earliest warning. React early.' },
      { zone: 'CAUTION', color: AMBER,   action: 'Reduce to 50% size.',     detail: 'Significant overextension for a Range regime. Tighten stops and reduce exposure.' },
      { zone: 'DANGER',  color: MAGENTA, action: 'Reduce to 25% or exit.', detail: 'Deeply overextended in the tightest band configuration. This is the highest-urgency reading.' },
    ],
    TREND: [
      { zone: 'SAFE',    color: TEAL,    action: 'Full size — trend continuation.', detail: 'You are inside the inner band with trend momentum. Optimal entry or hold zone.' },
      { zone: 'WATCH',   color: AMBER,   action: 'Hold size, monitor counter side.', detail: 'Extension is building. In a Bull Trend, watch for pullback risk on the lower band.' },
      { zone: 'CAUTION', color: AMBER,   action: 'Reduce to 60–70% size.',  detail: 'Bands are wider in TREND so CAUTION represents less absolute extension. Still act — tighten stops on counter side.' },
      { zone: 'DANGER',  color: MAGENTA, action: 'Reduce to 40–50% size.',  detail: 'Overextended but in a wider band. Not as severe as Range DANGER. Do not panic-exit a strong trend.' },
    ],
    VOLATILE: [
      { zone: 'SAFE',    color: TEAL,    action: 'Full size — widest safe zone.', detail: 'Volatile bands are the widest. SAFE here represents a genuinely low-extension area.' },
      { zone: 'WATCH',   color: AMBER,   action: 'Hold size, heightened awareness.', detail: 'First sign of extension in a volatile market. Usually noise — but track the dwell count.' },
      { zone: 'CAUTION', color: AMBER,   action: 'Reduce to 70% size.',     detail: 'Even with the vol bonus widening bands, CAUTION in VOLATILE is meaningful. Reduce modestly.' },
      { zone: 'DANGER',  color: MAGENTA, action: 'Reduce to 50–60% size.',  detail: 'Widest bands still crossed. Real overextension. Reduce size but expect larger swings — do not chase exits.' },
    ],
  }

  const rules = RULES[activeRegime]
  const rColor = activeRegime === 'RANGE' ? MAGENTA : activeRegime === 'TREND' ? TEAL : AMBER

  return (
    <div className="space-y-4">
      {/* Regime selector */}
      <div className="flex gap-2">
        {(['RANGE', 'TREND', 'VOLATILE'] as const).map(r => (
          <button
            key={r}
            onClick={() => setActiveRegime(r)}
            className="flex-1 py-2 rounded-lg text-xs font-bold font-mono tracking-wider transition-all border"
            style={{
              background: activeRegime === r ? (r === 'RANGE' ? 'rgba(239,83,80,0.15)' : r === 'TREND' ? 'rgba(38,166,154,0.15)' : 'rgba(255,179,0,0.15)') : 'transparent',
              color: activeRegime === r ? (r === 'RANGE' ? MAGENTA : r === 'TREND' ? TEAL : AMBER) : 'rgba(255,255,255,0.35)',
              borderColor: activeRegime === r ? (r === 'RANGE' ? MAGENTA + '60' : r === 'TREND' ? TEAL + '60' : AMBER + '60') : 'rgba(255,255,255,0.08)',
            }}
          >
            {r}
          </button>
        ))}
      </div>

      {/* Rules */}
      <div className="space-y-2">
        {rules.map(({ zone, color, action, detail }) => (
          <div key={zone} className="rounded-lg border border-white/8 bg-white/2 p-4">
            <div className="flex items-start justify-between gap-3 mb-2">
              <span className="font-mono font-bold text-xs" style={{ color }}>{zone}</span>
              <span className="font-mono font-bold text-xs text-white/80 text-right leading-tight">{action}</span>
            </div>
            <p className="text-xs text-white/45 leading-relaxed">{detail}</p>
          </div>
        ))}
      </div>

      <div className="rounded-lg border-l-4 px-4 py-3" style={{ borderColor: rColor, background: rColor + '0a' }}>
        <p className="text-xs leading-relaxed" style={{ color: rColor + 'dd' }}>
          {activeRegime === 'RANGE' && 'RANGE has the tightest bands. Every zone carries more weight. React earlier and harder than you would in TREND or VOLATILE conditions.'}
          {activeRegime === 'TREND' && 'TREND bands scale with ADX. The stronger the trend, the wider the bands, the more forgiving CAUTION and DANGER become in absolute terms. Direction still matters — asymmetry means counter-trend extensions hit zones sooner.'}
          {activeRegime === 'VOLATILE' && 'VOLATILE gets the widest bands. This is intentional — CIPHER knows that price swings are larger. A DANGER reading in VOLATILE still requires action, but your stop placement should account for the wider expected movement.'}
        </p>
      </div>
    </div>
  )
}

// ─── GAME ROUNDS DATA ─────────────────────────────────────────────────────────
export const gameRounds = [
  {
    id: 'gr-117-01',
    scenario: "CIPHER shows: Regime = RANGE, Risk Row = ▲ DANGER, dwell 18b (ESTABLISHED). Your planned entry is a full-size long. What do you do?",
    options: [
      {
        id: 'a',
        text: "Enter full size — the RANGE regime means the move is contained.",
        correct: false,
        explanation: "Regime tells you context, not permission. RANGE + DANGER is the most dangerous combination because bands are at their narrowest. An ESTABLISHED dwell of 18 bars means price has been deeply overextended for nearly three sessions. Full size here is the worst possible decision.",
      },
      {
        id: 'b',
        text: "Skip the entry or reduce to 25% maximum — RANGE DANGER with 18 bars dwell is a hard no.",
        correct: true,
        explanation: "Correct. RANGE regime produces the narrowest bands (0.85× scale). Being in DANGER with an ESTABLISHED dwell means price has been outside the outer band for 18 bars — this is deep overextension. Reduce dramatically or pass entirely.",
      },
      {
        id: 'c',
        text: "Reduce to 75% — the ESTABLISHED dwell might mean the move is nearly over.",
        correct: false,
        explanation: "The dwell phase tells you how long price has been overextended, not that it is about to reverse. ESTABLISHED means the overextension is sticky. 75% is still too large. RANGE DANGER calls for 25% maximum or no position.",
      },
      {
        id: 'd',
        text: "Enter full size — 18 bars in DANGER means mean reversion is imminent.",
        correct: false,
        explanation: "CIPHER does not tell you when a reversal will happen — it tells you what zone you are in and what to do with your size right now. Trading reversal timing from a dwell count is not the correct use of this system. Reduce size as directed.",
      },
    ],
  },
  {
    id: 'gr-117-02',
    scenario: "CIPHER shows: Regime = TREND (ADX 72, Bull), Risk Row = ▼ CAUTION, guidance 'TIGHTEN STOPS 4b'. Price has pulled back from the trend high. Do you adjust your stop?",
    options: [
      {
        id: 'a',
        text: "No — CAUTION in a TREND is less severe than RANGE CAUTION, so hold the original stop.",
        correct: false,
        explanation: "CAUTION always requires stop tightening regardless of regime. While TREND bands are wider, a ▼ CAUTION on a pullback means price is on the counter-trend side hitting the mid band. Asymmetry makes the lower band tighter in a Bull Trend — CAUTION fires sooner on pullbacks precisely because it is the riskier direction.",
      },
      {
        id: 'b',
        text: "Yes — tighten the stop immediately. The ▼ side in a Bull Trend hits CAUTION sooner due to asymmetry.",
        correct: true,
        explanation: "Correct. In a Bull Trend, the lower band (counter side) is tighter than the upper band (trend side) by up to 0.15× factor at ADX 72. A ▼ CAUTION means price is pulling back into the tighter zone. CIPHER is signalling that this pullback carries elevated counter-trend risk. Tighten the stop now.",
      },
      {
        id: 'c',
        text: "Tighten the stop only if the regime changes to RANGE.",
        correct: false,
        explanation: "Stop management is zone-driven, not regime-change-driven. CAUTION fires the action regardless of whether regime has changed. Waiting for a regime shift to act on a CAUTION in a 4-bar pullback means you are always one step behind.",
      },
      {
        id: 'd',
        text: "Add to the position — a pullback to CAUTION in a TREND is a buying opportunity.",
        correct: false,
        explanation: "CIPHER is not telling you to add here. The Risk Row is saying TIGHTEN STOPS, not add size. Adding into a CAUTION reading on the counter side of a trend — where asymmetry makes the lower band tighter — directly contradicts the Command Center guidance.",
      },
    ],
  },
  {
    id: 'gr-117-03',
    scenario: "CIPHER shows: Regime = VOLATILE, Risk Row = ▲ DANGER, guidance 'JUST HIT DANGER'. This is the first bar beyond the outer band. The Mean Reversion Score reads EXTREME (87). What is the correct sizing response?",
    options: [
      {
        id: 'a',
        text: "Hold full size — VOLATILE bands are the widest so DANGER is less meaningful here.",
        correct: false,
        explanation: "VOLATILE bands are wider, which means the absolute extension to reach DANGER is larger. But once you are in DANGER, the guidance is the same: REDUCE SIZE. An EXTREME MR Score of 87 confirms deep overextension. The wider bands did not prevent you from being in DANGER — they just made it harder to get there.",
      },
      {
        id: 'b',
        text: "Reduce to 50–60% size — VOLATILE DANGER still requires action but expect larger swings.",
        correct: true,
        explanation: "Correct. VOLATILE DANGER is less severe than RANGE DANGER in absolute terms because the outer band is wider. But it still requires a size reduction. The EXTREME MR Score confirms overextension is real. Reduce to 50–60% and keep stops wide enough to account for volatile conditions.",
      },
      {
        id: 'c',
        text: "Exit the entire position immediately — EXTREME MR Score means reversal is certain.",
        correct: false,
        explanation: "CIPHER identifies overextension, not reversal certainty. An EXTREME score means mean reversion pressure is high, not that a reversal will happen on this bar. In volatile conditions, price can stay overextended longer. Reduce size — do not panic-exit.",
      },
      {
        id: 'd',
        text: "Wait for the zone to become ENTRENCHED before acting — one bar is too early.",
        correct: false,
        explanation: "The transition message 'JUST HIT DANGER' is your one-bar notice to act. Waiting for ENTRENCHED (21+ bars) means you will have been in DANGER for over 20 bars before responding. React on the first bar, not the 21st.",
      },
    ],
  },
  {
    id: 'gr-117-04',
    scenario: "CIPHER Risk Row was showing ▲ DANGER for 24 bars (ENTRENCHED, bright red guidance). Now it reads ▲ CAUTION — 'LEAVING DANGER'. What does this transition tell you and what do you do?",
    options: [
      {
        id: 'a',
        text: "Immediately return to full size — LEAVING DANGER means the risk is over.",
        correct: false,
        explanation: "LEAVING DANGER is a de-escalation signal, not an all-clear. Price has just moved back inside the outer band for the first time after 24 bars. The overextension is easing, not resolved. You are now in CAUTION — the Command Center guidance is TIGHTEN STOPS, not NORMAL SIZE.",
      },
      {
        id: 'b',
        text: "Increase size to 75% — the trend is resuming from an overextended base.",
        correct: false,
        explanation: "LEAVING DANGER drops you to CAUTION, which calls for TIGHTEN STOPS — not a size increase. A 24-bar entrenched DANGER followed by a single LEAVING DANGER bar is not confirmation of trend resumption. Wait for SAFE before restoring size.",
      },
      {
        id: 'c',
        text: "Keep reduced size and hold the tighter stops — you are now in CAUTION, not clear yet.",
        correct: true,
        explanation: "Correct. LEAVING DANGER puts you in CAUTION territory. The Command Center is telling you TIGHTEN STOPS. You have de-escalated one level, which is positive, but you are not SAFE yet. Maintain reduced size and tighter stops until BACK TO SAFE fires.",
      },
      {
        id: 'd',
        text: "Close the position entirely — exiting DANGER after 24 bars usually signals exhaustion.",
        correct: false,
        explanation: "CIPHER is giving you a de-escalation reading, not an exit signal. Closing because 24 bars of DANGER have passed is a timing assumption CIPHER does not make. The Risk Row tells you zone and sizing guidance, not entry or exit points. Let it play out to BACK TO SAFE before reassessing size.",
      },
    ],
  },
  {
    id: 'gr-117-05',
    scenario: "You are reviewing two setups on different instruments. Setup A: RANGE regime, WATCH zone, 1 bar dwell. Setup B: TREND regime, CAUTION zone, 11 bars dwell (ESTABLISHED). Which carries more immediate sizing urgency?",
    options: [
      {
        id: 'a',
        text: "Setup A — RANGE is always more dangerous so WATCH in RANGE outweighs TREND CAUTION.",
        correct: false,
        explanation: "WATCH in RANGE is a first warning with a 1-bar dwell — a possible spike or early extension. TREND CAUTION established over 11 bars is a confirmed, sticky overextension. The zone level (CAUTION) and the dwell phase (ESTABLISHED) together make Setup B the more urgent situation right now.",
      },
      {
        id: 'b',
        text: "Setup B — CAUTION with an ESTABLISHED 11-bar dwell requires immediate stop tightening.",
        correct: true,
        explanation: "Correct. Setup A is a 1-bar WATCH spike in RANGE — meaningful but early, likely noise. Setup B is CAUTION at 11 bars ESTABLISHED, meaning price has been in the mid-to-outer band zone for over 11 bars in a trend. The combination of a higher zone (CAUTION vs WATCH) and a longer dwell (ESTABLISHED vs SPIKE) makes Setup B the priority.",
      },
      {
        id: 'c',
        text: "Both are equally urgent — any non-SAFE reading requires the same action.",
        correct: false,
        explanation: "The four zones exist precisely because they carry different urgency. WATCH calls for awareness. CAUTION calls for stop tightening. The dwell phase adds further weight — 11 bars ESTABLISHED is more serious than 1 bar SPIKE. Treating them equally ignores the information CIPHER is providing.",
      },
      {
        id: 'd',
        text: "Neither — wait for DANGER in both setups before taking sizing action.",
        correct: false,
        explanation: "Waiting for DANGER before acting defeats the purpose of the zone system. CAUTION with an 11-bar dwell is already telling you to tighten stops. By the time DANGER fires, you have already missed the warning. CAUTION is the signal to prepare. DANGER is the signal to act urgently.",
      },
    ],
  },
]

// ─── QUIZ QUESTIONS DATA ──────────────────────────────────────────────────────
export const quizQuestions = [
  {
    id: 'qq-117-01',
    question: "What is the band scale value for a RANGE regime with no ADX pressure?",
    options: [
      { id: 'a', text: '1.00×' },
      { id: 'b', text: '0.85×' },
      { id: 'c', text: '1.25×' },
      { id: 'd', text: '1.35×' },
    ],
    correct: 'b',
    explanation: "The base formula is 0.85 + (trend_pct × 0.004). In a flat RANGE market with no trend, trend_pct ≈ 0, so band_scale = 0.85. This is the narrowest configuration — the tightest bands and the most sensitive zone readings.",
  },
  {
    id: 'qq-117-02',
    question: "What additional multiplier does CIPHER apply to the band scale in a VOLATILE regime?",
    options: [
      { id: 'a', text: '0.05 bonus' },
      { id: 'b', text: '0.15 bonus' },
      { id: 'c', text: '0.10 bonus' },
      { id: 'd', text: '0.20 bonus' },
    ],
    correct: 'c',
    explanation: "VOLATILE regime adds a fixed vol_regime_bonus of 0.10 on top of the existing band scale. This is applied only when the regime is VOLATILE, pushing the final band_scale up to a maximum of 1.35× at full trend pressure plus the vol bonus.",
  },
  {
    id: 'qq-117-03',
    question: "Which dwell phase fires when price has been in a risk zone for 21 or more bars?",
    options: [
      { id: 'a', text: 'ESTABLISHED' },
      { id: 'b', text: 'VISIT' },
      { id: 'c', text: 'SPIKE' },
      { id: 'd', text: 'ENTRENCHED' },
    ],
    correct: 'd',
    explanation: "ENTRENCHED fires at 21+ bars in the same zone. At this phase, the DANGER guidance escalates to bright red (#FF1744) and a warning symbol appears. It is CIPHER's strongest overextension signal. ESTABLISHED covers 9–20 bars, VISIT covers 3–8, and SPIKE covers 1–2.",
  },
  {
    id: 'qq-117-04',
    question: "In a Bull Trend, which side of the Risk Envelope is tighter due to directional asymmetry?",
    options: [
      { id: 'a', text: 'Both sides are equal — asymmetry only applies in VOLATILE regime.' },
      { id: 'b', text: 'The upper (trend) side is tighter.' },
      { id: 'c', text: 'The lower (counter-trend) side is tighter.' },
      { id: 'd', text: 'Asymmetry does not apply below ADX 50.' },
    ],
    correct: 'c',
    explanation: "In a Bull Trend, the lower band (counter-trend side) is tighter: counter_side = 1.0 − asym_factor. The upper band (trend side) is wider: trend_side = 1.0 + asym_factor. This means a pullback in a Bull Trend hits CAUTION sooner than a continuation upward. Asymmetry activates above ADX 15.",
  },
  {
    id: 'qq-117-05',
    question: "What does the Command Center Risk row display on the very first bar price crosses into DANGER from CAUTION?",
    options: [
      { id: 'a', text: 'REDUCE SIZE 1b' },
      { id: 'b', text: 'JUST HIT DANGER' },
      { id: 'c', text: 'ENTRENCHED' },
      { id: 'd', text: 'DANGER CONFIRMED' },
    ],
    correct: 'b',
    explanation: "CIPHER fires 'JUST HIT DANGER' on the exact first bar of the zone transition. This is a dedicated transition message that overrides the standard 'REDUCE SIZE' guidance for one bar. It is your one-bar notice to act before the dwell count begins.",
  },
  {
    id: 'qq-117-06',
    question: "The Mean Reversion Score threshold for the mr_overextended flag is:",
    options: [
      { id: 'a', text: 'Score > 40' },
      { id: 'b', text: 'Score > 80' },
      { id: 'c', text: 'Score > 50' },
      { id: 'd', text: 'Score > 60' },
    ],
    correct: 'd',
    explanation: "mr_overextended = true fires when mr_score > 60. This corresponds to HIGH or EXTREME label territory. When active, buy and sell signals in the tooltip carry overextension context. The threshold aligns with CAUTION and DANGER territory in the zone system.",
  },
  {
    id: 'qq-117-07',
    question: "Which regime + zone combination carries the most sizing urgency in absolute terms?",
    options: [
      { id: 'a', text: 'VOLATILE + DANGER — widest bands make DANGER most dramatic.' },
      { id: 'b', text: 'TREND + DANGER — ADX confirms extension.' },
      { id: 'c', text: 'RANGE + DANGER — narrowest bands, deepest relative overextension.' },
      { id: 'd', text: 'All DANGER readings carry identical urgency regardless of regime.' },
    ],
    correct: 'c',
    explanation: "RANGE + DANGER is the most urgent combination. The band_scale is at its minimum (0.85×), so the outer band is closest to the anchor EMA. Price being in DANGER in RANGE means it has moved the smallest absolute distance to reach the most extreme zone. VOLATILE + DANGER, while alarming, represents a larger absolute move to the same zone classification.",
  },
  {
    id: 'qq-117-08',
    question: "When the Command Center Risk row shows 'LEAVING DANGER', what sizing action should you take?",
    options: [
      { id: 'a', text: 'Return to full size — de-escalation means the risk is cleared.' },
      { id: 'b', text: 'Maintain reduced size and tighter stops — you are now in CAUTION.' },
      { id: 'c', text: 'Exit the position — leaving DANGER confirms the trend has reversed.' },
      { id: 'd', text: 'Add to the position — LEAVING DANGER is a continuation signal.' },
    ],
    correct: 'b',
    explanation: "'LEAVING DANGER' is a de-escalation transition — price has re-entered the CAUTION zone from DANGER. The current guidance becomes TIGHTEN STOPS. You have moved down one zone level, which is positive, but you are not in SAFE yet. Maintain reduced size and tighter stops until 'BACK TO SAFE' fires.",
  },
]
