# Lesson 11.7 Deploy Bundle

## Files
- app/academy/lesson/cipher-regime-sizing/page.tsx  — NEW (2479 lines, SWC verified)

## Manual patches required (2 files)

### 1. app/lib/academy-data.ts
Add entry AFTER the 'cipher-executive-summary' entry (see PATCH-academy-data.txt)

### 2. app/academy/page.tsx
Add 'cipher-regime-sizing' to liveLessons Set AFTER 'cipher-executive-summary' (see PATCH-page-allowlist.txt)

## Git commit message
Academy: ship Lesson 11.7 — Regime-Based Position Sizing
