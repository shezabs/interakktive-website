// ==========================================================================
// ADMIN AUTH — server-side helpers for admin API routes
// ==========================================================================
// With cookie-based auth (Phase 3A), we read the session directly from cookies
// via @supabase/ssr. No more Bearer tokens, no more adminFetch — middleware
// has already verified the user is an admin by the time these routes execute,
// but we re-verify here as defence-in-depth.
// ==========================================================================

import { createClient } from '@supabase/supabase-js';
import { NextRequest } from 'next/server';
import { createSupabaseServerClient } from './supabase-server';

// Admin allowlist — must match middleware.ts and app/admin/layout.tsx
export const ADMIN_EMAILS = [
  'shezabmediaworxltd@gmail.com',
  'mustafamoinmirza@icloud.com',
];

/**
 * Returns the current admin's email if they pass the allowlist, else null.
 * Called at the top of every /api/admin/* route as defence-in-depth.
 *
 * Legacy signature: accepted a NextRequest parameter for Bearer token reading.
 * Now reads from cookies. The req parameter is kept optional for backwards
 * compatibility during migration — remove usage over time.
 */
export async function getAdminEmail(_req?: NextRequest): Promise<string | null> {
  try {
    const supabase = createSupabaseServerClient();
    const { data: { user } } = await supabase.auth.getUser();
    if (!user?.email) return null;
    const email = user.email.toLowerCase();
    if (!ADMIN_EMAILS.includes(email)) return null;
    return email;
  } catch (err) {
    console.error('getAdminEmail error:', err);
    return null;
  }
}

/**
 * Supabase admin client using the service role key.
 * Bypasses RLS. Only call AFTER verifying the caller is an admin.
 */
export function getSupabaseAdmin() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !serviceKey) {
    throw new Error('Missing Supabase env vars (NEXT_PUBLIC_SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY)');
  }
  return createClient(url, serviceKey);
}

export interface AuditLogEntry {
  adminEmail: string;
  action: string;
  targetType: string;
  targetId?: string | null;
  before?: any;
  after?: any;
  ipAddress?: string | null;
}

/**
 * Writes a row to admin_audit_log. Failures are logged but never thrown —
 * an audit log failure must never block an admin action.
 */
export async function writeAuditLog(entry: AuditLogEntry): Promise<void> {
  try {
    const supabase = getSupabaseAdmin();
    const { error } = await supabase.from('admin_audit_log').insert({
      admin_email: entry.adminEmail,
      action: entry.action,
      target_type: entry.targetType,
      target_id: entry.targetId ?? null,
      before_data: entry.before ?? null,
      after_data: entry.after ?? null,
      ip_address: entry.ipAddress ?? null,
    });
    if (error) console.error('Audit log write failed:', error);
  } catch (err) {
    console.error('Audit log exception:', err);
  }
}

export function getClientIp(req: NextRequest): string | null {
  const forwarded = req.headers.get('x-forwarded-for');
  if (forwarded) return forwarded.split(',')[0].trim();
  return req.headers.get('x-real-ip') || null;
}
