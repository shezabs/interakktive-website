// Server component — no 'use client'. Middleware has already verified the
// user is an admin by the time we get here. No client-side guard needed.
//
// CommandPalette and AdminNav are still client components (they need
// interactivity), but the layout itself is server-rendered.

import type { Metadata } from 'next';
import AdminNav from './components/AdminNav';
import CommandPalette from './components/CommandPalette';

export const metadata: Metadata = {
  title: 'Admin — Interakktive',
  description: 'Internal admin panel',
  robots: { index: false, follow: false },
};

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen" style={{ background: 'linear-gradient(to bottom, #060a12, #0a0f1a)' }}>
      <AdminNav />
      <CommandPalette />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-24 pb-16">
        {children}
      </main>
    </div>
  );
}
