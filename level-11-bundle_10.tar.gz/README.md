# Lesson 11.10 — The 5-Layer Pulse Factor

**Slug:** `cipher-pulse-factor`
**Arc:** Signal Engine (lesson 1 of 4)
**Cert:** Pulse Factor Operator
**Lines:** 3,350
**SWC:** verified clean

## What's in this bundle

3 files modified/added — the standard Academy 3-file deploy:

1. `app/academy/lesson/cipher-pulse-factor/page.tsx` — NEW (3,350 lines, 13 animations)
2. `app/lib/academy-data.ts` — MODIFIED (1 line added after cipher-signal-philosophy)
3. `app/academy/page.tsx` — MODIFIED (1 line added to liveLessons allowlist)

## Deploy steps (Git Bash)

```bash
# 1. Backup first
cd ~/OneDrive/Desktop && STAMP=$(date +%Y-%m-%d_%H-%M) && mkdir -p interakktive-backups && tar --exclude='interakktive-website/node_modules' --exclude='interakktive-website/.next' --exclude='interakktive-website/.turbo' --exclude='interakktive-website/.vercel' -czf "interakktive-backups/interakktive-website_pre-11-10_${STAMP}.tar.gz" interakktive-website/

# 2. Extract bundle into repo
cd ~/OneDrive/Desktop/interakktive-website && tar -xzf ~/Downloads/level-11-bundle_10.tar.gz

# 3. Verify (should show the new lesson dir + the 3 modified files)
ls app/academy/lesson/cipher-pulse-factor/
git status

# 4. Commit and push
git add -A && git commit -m "Academy: ship Lesson 11.10 — The 5-Layer Pulse Factor" && git push origin main
```

Vercel auto-deploys within 60-90 seconds. Verify live at:
https://interakktive.com/academy/lesson/cipher-pulse-factor

## Lesson contents

- **Hero:** "The 5-Layer Pulse Factor" with gradient subtitle
- **S00 — First, Why This Matters:** Two operators, same setting, different Pulse
- **S01 — ⭐ The Self-Calibrating Heartbeat:** GC with central dial + 5 forces animation
- **S02 — Anatomy of the Pulse Line:** 5-step build (Flow → ATR → raw → ratchet → smooth)
- **S03 — Layer 1 · Timeframe:** tf_pulse_adj with 6-tab cycle animation
- **S04 — Layer 2 · Asset Class:** asset_pulse_adj with 4-panel comparison
- **S05 — Layer 3 · Volatility:** pulse_vol_adj with live gauge + clamp formula
- **S06 — Layer 4 · ADX:** pulse_adx_adj counter-intuitive: strong = tighter
- **S07 — Layer 5 · Active Preset:** preset_pulse_mult silent reach
- **S08 — The Composition:** Worked XAUUSD 1H example, multiplication formula
- **S09 — The Ratchet:** Side-by-side naive vs ratcheted comparison
- **S10 — Pulse Smoothing:** Lag-vs-stability dial
- **S11 — The Maturity Lifecycle:** FRESH/YOUNG/ESTABLISHED/MATURE timeline
- **S12 — The Choppy Flag:** 20-bar lookback + 3-flip rule
- **S13 — The Slope Verdict:** STEEPENING/STEADY/FLATTENING
- **S14 — Reading the Pulse Row:** All 5 proximity states + 6 guidance verdicts + color grammar
- **S15 — Six Common Mistakes:** 6 red mistake cards, operator-grade
- **Cheat Sheet:** Single glass-card with 7 border-b sub-sections
- **S16 — Scenario Game:** 5 rounds with per-option teaching explanations
- **S17 — Knowledge Check:** 8 questions, 66% pass threshold
- **Cert:** Pulse Factor Operator with conic-gradient card + confetti

## Quality verified

- 17 sections rendered (gold-standard)
- 13 animations (target: 13+)
- 6 red mistake cards (target: 6 exactly)
- 15 amber callouts
- 100 body prose blocks
- 13 correct answers (5 game + 8 quiz, target: 13)
- 0 max-w-4xl violations
- 0 raw \\u escapes
- 0 dashboard mentions (terminology rule)
- Section balance: 21/21 (matched)
- SWC parse: clean
