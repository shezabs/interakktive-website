import { Metadata } from 'next';
import Link from 'next/link';
import { ArrowLeft, FileText } from 'lucide-react';

export const metadata: Metadata = {
  title: 'Terms of Service',
  description: 'Terms of Service for Interakktive - Read our terms and conditions for using our trading indicators and services.',
};

export default function TermsOfServicePage() {
  return (
    <div className="pt-24 pb-20 min-h-screen">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <Link
          href="/"
          className="inline-flex items-center gap-2 text-gray-400 hover:text-white transition-colors mb-8"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Home
        </Link>

        <div className="glass p-8 md:p-12 rounded-lg">
          <div className="flex items-center gap-3 mb-6">
            <FileText className="w-8 h-8 text-primary-400" />
            <h1 className="text-3xl md:text-4xl font-bold">Terms of Service</h1>
          </div>

          <p className="text-gray-400 mb-8">Last updated: June 2026</p>

          <div className="prose prose-invert max-w-none space-y-8">
            <section>
              <h2 className="text-2xl font-semibold mb-4 text-white">1. Agreement to Terms</h2>
              <p className="text-gray-300 leading-relaxed">
                By accessing or using Interakktive&rsquo;s website and services, including our TradingView indicators
                (&ldquo;Services&rdquo;), you agree to be bound by these Terms of Service (&ldquo;Terms&rdquo;).
                Interakktive is a brand operated by <strong className="text-white">Shezab MediaWorx Ltd</strong>,
                a company registered in England and Wales (company number 16364787, registered office:
                Apartment 45 Dock Office, Furness Quay, Salford, England, M50 3AA) (&ldquo;we,&rdquo; &ldquo;our,&rdquo; or &ldquo;us&rdquo;).
                If you do not agree to these Terms, please do not use our Services.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4 text-white">2. Description of Services</h2>
              <p className="text-gray-300 leading-relaxed mb-4">
                Interakktive provides trading indicators and analytical tools for use on the TradingView platform.
                Our Services include:
              </p>
              <ul className="list-disc list-inside space-y-2 text-gray-300 ml-4">
                <li>Free trading indicators available on TradingView</li>
                <li>ATLAS PRO suite of premium indicators (invite-only access)</li>
                <li>Educational content and documentation</li>
                <li>User account management</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4 text-white">3. User Accounts</h2>
              <p className="text-gray-300 leading-relaxed mb-4">To access certain features, you may need to create an account. You agree to:</p>
              <ul className="list-disc list-inside space-y-2 text-gray-300 ml-4">
                <li>Provide accurate and complete registration information</li>
                <li>Maintain the security of your account credentials</li>
                <li>Promptly update any changes to your information</li>
                <li>Accept responsibility for all activities under your account</li>
                <li>Notify us immediately of any unauthorized access</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4 text-white">4. Important Disclaimers</h2>
              <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-lg p-4 mb-4">
                <p className="text-yellow-200 font-semibold mb-2">Trading Risk Warning</p>
                <p className="text-gray-300 text-sm">
                  Trading in financial markets involves substantial risk and may not be suitable for all investors.
                  Past performance is not indicative of future results.
                </p>
              </div>
              <ul className="list-disc list-inside space-y-2 text-gray-300 ml-4">
                <li>Our indicators are tools for analysis, not financial advice</li>
                <li>We do not guarantee any specific trading results or profits</li>
                <li>You are solely responsible for your trading decisions</li>
                <li>Always conduct your own research before trading</li>
                <li>Never trade with money you cannot afford to lose</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4 text-white">5. Intellectual Property</h2>
              <p className="text-gray-300 leading-relaxed mb-4">
                All content, indicators, code, designs, and materials on our platform are owned by Shezab MediaWorx Ltd (Interakktive)
                and protected by intellectual property laws. You may not:
              </p>
              <ul className="list-disc list-inside space-y-2 text-gray-300 ml-4">
                <li>Copy, modify, or distribute our indicators or code</li>
                <li>Reverse engineer or decompile our software</li>
                <li>Remove any copyright or proprietary notices</li>
                <li>Use our trademarks without written permission</li>
                <li>Resell or redistribute access to our indicators</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4 text-white">6. Acceptable Use</h2>
              <p className="text-gray-300 leading-relaxed mb-4">You agree not to:</p>
              <ul className="list-disc list-inside space-y-2 text-gray-300 ml-4">
                <li>Use our Services for any illegal purpose</li>
                <li>Attempt to gain unauthorized access to our systems</li>
                <li>Interfere with or disrupt our Services</li>
                <li>Share your account access with others</li>
                <li>Use automated systems to access our Services without permission</li>
                <li>Misrepresent your identity or affiliation</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4 text-white">7. Subscriptions, billing and renewals</h2>
              <p className="text-gray-300 leading-relaxed mb-4">
                Access to ATLAS PRO indicators is provided through paid subscription plans. By subscribing you agree that:
              </p>
              <ul className="list-disc list-inside space-y-2 text-gray-300 ml-4">
                <li>Subscription fees are charged in US dollars (USD) and processed securely by Stripe.</li>
                <li>Subscriptions renew automatically at the end of each billing period (monthly or annual) unless cancelled before the renewal date.</li>
                <li>You authorise us, via Stripe, to charge your payment method for each renewal until you cancel.</li>
                <li>You can cancel at any time from your account dashboard; cancellation stops future renewals and your access continues until the end of the current paid period.</li>
                <li>We may change our prices, and will give reasonable notice of changes that affect your renewals. Price changes do not affect the period you have already paid for.</li>
                <li>We may approve, deny, modify, or discontinue access or features at our reasonable discretion.</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4 text-white">8. Refunds and cancellation</h2>
              <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-lg p-4 mb-4">
                <p className="text-yellow-200 font-semibold mb-2">All sales are final</p>
                <p className="text-gray-300 text-sm">
                  Subscription fees are non-refundable. By subscribing you receive immediate access to digital
                  content, and all payments — including renewals and partial billing periods — are final.
                </p>
              </div>
              <p className="text-gray-300 leading-relaxed mb-4">
                Our Services provide immediate digital access. By subscribing and gaining access to the
                indicators and digital content, you expressly request that we begin supplying them straight
                away and you acknowledge that you lose any statutory 14-day right of withdrawal once access
                has been granted. You agree that no refunds will be given for change of mind, lack of use, or
                dissatisfaction with results.
              </p>
              <p className="text-gray-300 leading-relaxed">
                Cancelling stops future renewals; your access continues until the end of the period you have
                already paid for. Nothing in this section limits the rights you have under applicable consumer
                protection law where we are at fault — for example, if the Services are faulty, not as
                described, or you were charged in error.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4 text-white">9. Limitation of Liability</h2>
              <p className="text-gray-300 leading-relaxed">
                TO THE MAXIMUM EXTENT PERMITTED BY LAW, SHEZAB MEDIA WORX LIMITED SHALL NOT BE LIABLE FOR ANY INDIRECT,
                INCIDENTAL, SPECIAL, CONSEQUENTIAL, OR PUNITIVE DAMAGES, INCLUDING BUT NOT LIMITED TO LOSS
                OF PROFITS, DATA, OR OTHER INTANGIBLE LOSSES, RESULTING FROM YOUR USE OF OUR SERVICES OR
                ANY TRADING DECISIONS MADE BASED ON OUR INDICATORS.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4 text-white">10. Disclaimer of Warranties</h2>
              <p className="text-gray-300 leading-relaxed">
                OUR SERVICES ARE PROVIDED "AS IS" AND "AS AVAILABLE" WITHOUT WARRANTIES OF ANY KIND,
                EITHER EXPRESS OR IMPLIED. WE DO NOT WARRANT THAT OUR SERVICES WILL BE UNINTERRUPTED,
                SECURE, OR ERROR-FREE, OR THAT ANY DEFECTS WILL BE CORRECTED.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4 text-white">11. Indemnification</h2>
              <p className="text-gray-300 leading-relaxed">
                You agree to indemnify and hold harmless Shezab MediaWorx Ltd and its officers, directors, employees,
                and agents from any claims, damages, losses, or expenses arising from your use of our Services
                or violation of these Terms.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4 text-white">12. Termination</h2>
              <p className="text-gray-300 leading-relaxed">
                We may terminate or suspend your access to our Services immediately, without prior notice,
                for any reason, including breach of these Terms. Upon termination, your right to use our
                Services will cease immediately.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4 text-white">13. Changes to Terms</h2>
              <p className="text-gray-300 leading-relaxed">
                We reserve the right to modify these Terms at any time. We will provide notice of significant
                changes by posting the updated Terms on our website. Your continued use of our Services after
                such changes constitutes acceptance of the new Terms.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4 text-white">14. Governing Law</h2>
              <p className="text-gray-300 leading-relaxed">
                These Terms are governed by and construed in accordance with the laws of England and Wales,
                and any disputes shall be subject to the exclusive jurisdiction of the courts of England and Wales,
                without regard to conflict of law principles.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4 text-white">15. Contact Information</h2>
              <p className="text-gray-300 leading-relaxed">
                If you have any questions about these Terms, please contact us at:
              </p>
              <p className="text-primary-400 mt-2">shezabmediaworxltd@gmail.com</p>
            </section>
          </div>
        </div>

        <div className="mt-8 text-center flex items-center justify-center gap-4">
          <Link href="/privacy" className="text-primary-400 hover:text-primary-300 transition-colors">
            Privacy Policy
          </Link>
          <span className="text-gray-600">|</span>
          <Link href="/cookies" className="text-primary-400 hover:text-primary-300 transition-colors">
            Cookie Policy
          </Link>
        </div>
      </div>
    </div>
  );
}
