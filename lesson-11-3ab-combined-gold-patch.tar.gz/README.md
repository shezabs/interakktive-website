# ATLAS Academy — Level 11 Gold-Standard Rewrites 11.3a + 11.3b

**Combined patch — push both lessons together in one commit.**

This tarball replaces TWO lesson files with their gold-standard rewrites, matching the Level 10 formatting pattern that's already live in lessons 11.1 and 11.2.

## Files in this patch

| Path | Lines | SWC parse |
|---|---|---|
| `app/academy/lesson/cipher-inputs-anatomy-part-1/page.tsx` | 3,635 | PASS |
| `app/academy/lesson/cipher-inputs-anatomy-part-2/page.tsx` | 3,337 | PASS |

Both files have been verified against a strict deploy-safety audit (imports, TypeScript annotations, JSX balance, undefined components, state orphans, dead code, unicode escapes, closing braces). **No build-time errors expected.**

## Deploy (single push, both lessons together)

From Git Bash, in your repo root:

```bash
cd ~/OneDrive/Desktop/interakktive-website

# Extract both lessons in one shot
tar -xzf ~/Downloads/lesson-11-3ab-combined-gold-patch.tar.gz -C .

# Verify line counts match what this patch promised
wc -l app/academy/lesson/cipher-inputs-anatomy-part-1/page.tsx
#    3635 app/academy/lesson/cipher-inputs-anatomy-part-1/page.tsx
wc -l app/academy/lesson/cipher-inputs-anatomy-part-2/page.tsx
#    3337 app/academy/lesson/cipher-inputs-anatomy-part-2/page.tsx

# Review the changes
git status
git diff --stat

# Commit both files in one commit
git add app/academy/lesson/cipher-inputs-anatomy-part-1/page.tsx \
        app/academy/lesson/cipher-inputs-anatomy-part-2/page.tsx

git commit -m "Academy L11.3a + L11.3b: gold-standard rewrites (match Level 10 formatting)

- 11.3a CIPHER Inputs Anatomy Part 1 (Visual Layer): 26 inputs across 9 groups
- 11.3b CIPHER Inputs Anatomy Part 2 (Behavioral Layer): 33 inputs across 3 groups
- Both lessons converted to gold tokens (max-w-2xl, text-2xl h2, glass-cards)
- 17 sequential sections per lesson, no gaps
- All 28 canvas animations preserved (14 per lesson)
- New cheat sheet sections synthesizing each layer
- Auto-submit quizzes, conic-gradient certs, confetti on pass
- Completes the Level 11 CIPHER PRO Mastery arc"

git push
```

Vercel auto-deploys. Both lessons go live at:
- `interakktive.com/academy/lesson/cipher-inputs-anatomy-part-1`
- `interakktive.com/academy/lesson/cipher-inputs-anatomy-part-2`

Typical propagation time: 60–90 seconds.

## What each lesson delivers

### 11.3a — CIPHER Inputs Anatomy Part 1 (Visual Layer)

- **17 sequential sections** (hero → S00 → 15 numbered → Game → Quiz)
- Covers the **9 visual-layer input groups** (26 inputs): PRESET, CIPHER RIBBON, CIPHER RISK ENVELOPE, CIPHER STRUCTURE, CIPHER SPINE, **CIPHER IMBALANCE** (newly written section — source was missing it despite hero promising 9 groups), CIPHER SWEEPS, CIPHER COIL, CIPHER PULSE
- Groundbreaking concept: **The Silent Cascade** — one setting change ripples through 5+ downstream systems inside a single group
- 14 canvas animations preserved: SilentCascade, PineInputAnatomy, PresetSelector, PresetOverrideMatrix, RibbonDivergence, RibbonProjection, RiskEnvelopeZones, FairValueGravity, StructureLifecycle, SpineBreathing, ImbalanceShrink, SweepDetection, CoilCompression, PulseATRFactor
- New **Visual Layer Cheat Sheet** pinning all 9 groups + universal concepts
- Certificate: **CIPHER Visual-Layer Operator**

### 11.3b — CIPHER Inputs Anatomy Part 2 (Behavioral Layer)

- **17 sequential sections** (hero → S00 → 15 numbered → Game → Quiz)
- Covers the **3 behavioral-layer input groups** (33 inputs): SIGNAL ENGINE (4), CIPHER RISK MAP (10), COMMAND CENTER (19 = 3 panel + 16 row toggles)
- Groundbreaking concept: **The Arrow Is the Last Word** — every signal passes a 4-factor vote (Ribbon stacked · ADX > 20 · Volume > 1.0× · Momentum > 50%) before firing
- 14 canvas animations preserved: ArrowTally, SignalEngineSwitcher, DirectionFilter, StrongSignalsAudit, CipherCandlesSpectrum, RiskMapOverview, SLMethodComparison, AssetClassRouting, TPMethodComparison, TPScaleOut, PanelPositioning, RowFamilyOverview, CrossGroupCascade, BehavioralPlaybookMatrix
- New **Behavioral Layer Cheat Sheet** pinning all 3 groups + Cross-Group Cascade big 3
- Certificate: **CIPHER Behavioral-Layer Operator**

## Verification summary (skill Section 5.5 metrics)

Both lessons pass identical checks:

| Check | 11.3a | 11.3b |
|---|---|---|
| Gold sections | 19 ✓ | 19 ✓ |
| `max-w-4xl` remaining (must be 0) | 0 ✓ | 0 ✓ |
| Gold h2 count | 17 ✓ | 17 ✓ |
| Sequential labels 01 → 17 | no gaps ✓ | no gaps ✓ |
| Animations preserved | 14/14 ✓ | 14/14 ✓ |
| Legacy state vars | 0 ✓ | 0 ✓ |
| Literal ✓/✗ glyphs (no `\u` escapes in JSX) | ✓ | ✓ |
| `use client` directive first | ✓ | ✓ |
| `<section>` balance | 20/20 ✓ | 20/20 ✓ |
| `<motion.div>` balance | ✓ | ✓ |
| All imports present | ✓ | ✓ |
| File ends with `}` | ✓ | ✓ |
| Final SWC parse | PASS ✓ | PASS ✓ |

## Rollback (if needed)

If anything goes wrong post-push, both lessons can be reverted cleanly:

```bash
# Revert the combined commit
git revert HEAD
git push

# Or hard-reset to previous state (if you haven't pushed anything else)
git reset --hard HEAD~1
git push --force-with-lease
```

Rolling back affects ONLY these two files; 11.1 and 11.2 are untouched by this patch.

## Level 11 arc status after this push

| Lesson | Title | Status after push |
|---|---|---|
| 11.1 | Why CIPHER | Live ✓ |
| 11.2 | CIPHER Command Center — Anatomy | Ready in separate earlier patch |
| 11.3a | **CIPHER Inputs Anatomy — Part 1 (Visual Layer)** | **Live ✓** |
| 11.3b | **CIPHER Inputs Anatomy — Part 2 (Behavioral Layer)** | **Live ✓** |

After deploying 11.2 (separate patch), Level 11 CIPHER PRO Mastery will be fully gold-standard consistent.
