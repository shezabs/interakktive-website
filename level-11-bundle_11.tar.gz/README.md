# Lesson 11.11 — PX Filter Pipeline

**Slug:** `cipher-px-pipeline`
**Arc:** Signal Engine (lesson 2 of 4)
**Cert:** Pulse Cross Operator
**Lines:** 3,670
**SWC:** verified clean

## What is in this bundle

3 files modified/added:

1. `app/academy/lesson/cipher-px-pipeline/page.tsx` — NEW (3,670 lines, 13 animations)
2. `app/lib/academy-data.ts` — MODIFIED (adds BOTH 11.10 cipher-pulse-factor AND 11.11 cipher-px-pipeline entries)
3. `app/academy/page.tsx` — MODIFIED (adds BOTH lessons to liveLessons allowlist)

## Important — safe to apply over your current state

The bundle includes Lesson 10 (cipher-pulse-factor) entries in academy-data.ts and academy/page.tsx
even though it is already deployed. This is intentional: extracting this bundle will not break or
remove your existing Lesson 10 — it just confirms its presence.

## Deploy steps (Git Bash)

```bash
# 1. Backup first
cd ~/OneDrive/Desktop && STAMP=$(date +%Y-%m-%d_%H-%M) && mkdir -p interakktive-backups && tar --exclude='interakktive-website/node_modules' --exclude='interakktive-website/.next' --exclude='interakktive-website/.turbo' --exclude='interakktive-website/.vercel' -czf "interakktive-backups/interakktive-website_pre-11-11_${STAMP}.tar.gz" interakktive-website/

# 2. Extract bundle into repo
cd ~/OneDrive/Desktop/interakktive-website && tar -xzf ~/Downloads/level-11-bundle_11.tar.gz

# 3. Verify (should show new lesson dir + 3 modified files, no README at repo root)
ls app/academy/lesson/cipher-px-pipeline/
git status

# 4. Optional: remove README if it landed at repo root
rm README.md 2>/dev/null

# 5. Verify both lessons present exactly once in academy-data.ts
grep -c "cipher-pulse-factor" app/lib/academy-data.ts   # should be 1
grep -c "cipher-px-pipeline" app/lib/academy-data.ts    # should be 1

# 6. Commit and push
git add -A && git commit -m "Academy: ship Lesson 11.11 — PX Filter Pipeline" && git push origin main
```

Vercel auto-deploys within 60-90 seconds. Verify live at:
https://interakktive.com/academy/lesson/cipher-px-pipeline

## Lesson contents

- Hero: "PX Filter Pipeline — Why Some Flips Become Signals"
- S00 — First, Why This Matters: Three flips. One signal. Two silent rejections.
- S01 — ⭐ The Four Gates (GC): Pipeline visualisation, 6 example flips
- S02 — From Flip to PX: The bridge from L10's ratchet to PX qualification
- S03 — Gate 1 · Body Filter: min_body asset-routed thresholds
- S04 — Gate 2 · Pre-Cross Distance: min_dist asset+TF matrix
- S05 — Gate 3 · Chop Suppression: flip_window, recent-opposite blocking
- S06 — Gate 4 · Failed-Flip Override: V-bottom catcher, 8-bar lookback
- S07 — Asset Routing Master Table: all gates × asset classes
- S08 — Timeframe Routing Master Table: TF gradient on Gates 2 & 3
- S09 — Pipeline Logic in Plain English: clause-by-clause px_long walkthrough
- S10 — PX in the Command Center: Last Signal row reading
- S11 — PX vs TS Preview: two pathways, sets up Lesson 12
- S12 — Strong PX vs Standard PX: 4-factor conviction overlay
- S13 — Three PX Playbooks: Trend Continuation, Reversal from Extreme, Failed-Flip V-Bottom
- S14 — Reading Why a Flip Did Not Fire: 6 rejection patterns
- S15 — Six Common Mistakes: 6 red mistake cards
- Cheat Sheet: 9 border-b sub-sections covering the entire pipeline
- S16 — Scenario Game: 5 rounds with per-option teaching explanations
- S17 — Knowledge Check: 8 questions, 66% pass threshold
- Cert: Pulse Cross Operator with conic-gradient card + confetti

## Quality verified

- 17 sections rendered (matches gold standard)
- 13 animations (target 13+)
- 6 red mistake cards (target 6 exactly)
- 15 amber callouts
- 124 body prose blocks
- 19 glass-cards total
- 14 multi-titled glass-card containers (vs 11.4's 10 — denser than gold reference)
- 42 sub-section dividers (vs 11.4's 17 — much denser)
- 13 correct answers (5 game + 8 quiz, target 13)
- 0 max-w-4xl violations
- 0 raw \\u escapes in JSX body
- 0 dashboard mentions (terminology rule)
- Section balance: 21/21 (matched)
- SWC parse: clean (all 3 files)

## Density vs gold reference

This lesson exceeds 11.4 (the gold-standard reference) on every density metric:

| Metric | L11.11 | L11.4 (gold) | Delta |
|---|---|---|---|
| Glass-cards total | 19 | 14 | +36% |
| Multi-titled glass-cards | 14 | 10 | +40% |
| Sub-section dividers | 42 | 17 | +147% |
| Body prose blocks | 124 | 83 | +49% |
| Lines | 3,670 | 2,809 | +31% |
