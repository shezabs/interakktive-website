# L11.25 Cipher Trading Discipline — Deploy Bundle (with gate bypass)

Built 2026-05-21. Final page count: **3,861 lines**.

This bundle ships **L11.25 + a sequential-gate bypass for paying subscribers** so you can verify the lesson the moment Vercel deploys, and so customers can take lessons in any order they choose. Cert remains earned through completion (untouched).

---

## What's in this bundle

```
page.tsx                          → the lesson page file (3,861 lines)
academy-data-patch-1.txt          → adds L11.25 entry to app/lib/academy-data.ts
live-lessons-patch-2.txt          → registers cipher-trading-discipline in LIVE_LESSONS
academy-page-gate-patch-3.txt     → sequential-gate bypass for paying users (you + Mustafa + customers)
README.md                         → this file
```

---

## What the gate bypass actually changes

**Before:** Customers had to complete each lesson sequentially to unlock the next card on the academy index. You and Mustafa got the same locked cards visually because the existing bypass (`useProAccess` admin allowlist) only operated at the lesson-page level — not at the index UI.

**After:** Every paying subscriber (and admin) sees every lesson card as clickable on the academy index. Lessons can be taken in any order.

**What is NOT changed:**
- **Cert gating stays intact.** `isLevelCompleteByCompletions` in `academy-helpers.ts` reads from the `lesson_completions` Supabase table. A user only earns the Level 11 cert when ALL live lessons in Level 11 are in their completion set. Opening a lesson does not auto-complete it — completion is recorded only when the quiz inside the lesson is passed. **Customers still have to complete every Level 11 lesson (in any order) to earn the Level 11 cert.**
- **PRO-tier paywall stays intact.** Non-paying users still cannot access any PRO lesson — that's `hasAccess` in the index, controlled by `useProAccess` returning `'paying'` or not. The gate-3 patch does not touch this.
- **Direct lesson URL access** stays unchanged because the lesson layout already trusts `useProAccess`.

---

## Deploy steps (10 minutes, Git Bash)

```bash
# 1. From the repo root, take a backup before changing anything
cd ~/OneDrive/Desktop/interakktive-website
./backup.sh pre-L11.25-deploy

# 2. Extract this bundle somewhere convenient
mkdir -p /tmp/L11.25-bundle
tar -xzf /path/to/L11.25-cipher-trading-discipline.tar.gz -C /tmp/L11.25-bundle
cd /tmp/L11.25-bundle && ls
# Expected: README.md, page.tsx, academy-data-patch-1.txt, live-lessons-patch-2.txt, academy-page-gate-patch-3.txt

# 3. Create the lesson directory and copy the page file in
cd ~/OneDrive/Desktop/interakktive-website
mkdir -p app/academy/lesson/cipher-trading-discipline
cp /tmp/L11.25-bundle/page.tsx app/academy/lesson/cipher-trading-discipline/page.tsx

# 4. Apply patch 1 — add L11.25 entry to academy-data.ts
#    Open app/lib/academy-data.ts in your editor.
#    Find the 'cipher-war-room-integration' entry (around line 337).
#    Paste the lesson entry from academy-data-patch-1.txt IMMEDIATELY AFTER that
#    line and BEFORE the closing `    ],` of the Level 11 lessons array.
#    The array grows from 24 → 25 entries.

# 5. Apply patch 2 — register the lesson in LIVE_LESSONS
#    Open app/lib/academy-helpers.ts in your editor.
#    Find the closing line of the LIVE_LESSONS Set, currently:
#         'cipher-candles', 'cipher-war-room-integration',
#       ]);
#    Replace that line with the one from live-lessons-patch-2.txt:
#         'cipher-candles', 'cipher-war-room-integration', 'cipher-trading-discipline',
#       ]);

# 6. Apply patch 3 — sequential-gate bypass for paying users
#    Open app/academy/page.tsx in your editor.
#    Find the `const sequentiallyUnlocked = ...` assignment (around line 235).
#    Replace it with the block from academy-page-gate-patch-3.txt.
#    The `liveIdx` and `prevLiveLesson` lines above it stay UNTOUCHED.

# 7. Sanity check the file compiles locally (optional but recommended)
npm run build
# Look for "Compiled successfully" — no TypeScript errors expected.

# 8. Commit and push
git add app/academy/lesson/cipher-trading-discipline/page.tsx \
        app/lib/academy-data.ts \
        app/lib/academy-helpers.ts \
        app/academy/page.tsx
git commit -m "Academy: L11.25 Cipher Trading Discipline + open sequential gate for paying users"
git push origin main

# 9. Vercel auto-deploys in 60-90 seconds.
#    Visit https://interakktive.com/academy
#    -> Every Level 11 card should now be clickable for you.
#    Visit https://interakktive.com/academy/lesson/cipher-trading-discipline
#    -> Lesson should render with hero, all 16 sections, game, quiz, cert.
```

---

## Post-deploy verification checklist

After Vercel's build completes:

- [ ] `/academy` loads — no padlocks on any Level 11 lesson when logged in as you
- [ ] `/academy/lesson/cipher-trading-discipline` renders the hero
- [ ] Hero says "Cipher Trading Discipline · Discipline Is a Boolean"
- [ ] Scrolling reveals the BooleanEquationAnim animation in S00
- [ ] Scrolling reaches S10 — the 30-Session Scrubber accepts drag input
- [ ] S05 ★ TS Cooldown Clock animates (countdown clock + chart with bars)
- [ ] S06 ★★ Preset Philosophy Ring rotates through 6 presets
- [ ] Quiz renders 13 questions
- [ ] Quiz pass triggers cert reveal with "Discipline Operator" text
- [ ] Cert ID format: `PRO-CERT-L11.25-XXXXXX`

If anything fails, rollback is `git revert HEAD && git push`.

---

## What's in the lesson

**16 sections** (Hero + S00 → S15 + Mistakes + Cheat Sheet + Game + Quiz + Cert + Footer):

| Section | Theme |
|---|---|
| Hero | "Discipline Is a Boolean" — min-h-[85vh] |
| S00 | Groundbreaking Concept — two operators, same CIPHER, different P&L |
| S01 | The Equation: signal = engine AND discipline |
| S02 | The Skip Pile, Quantified — 8/3/5 ratio + 5 skip categories |
| S03 | The Discipline Pyramid — Process / Plan / Execution / Review |
| S04 | Pine-Encoded Discipline #1: min_conviction (line 200 walkthrough) |
| S05 | Pine-Encoded Discipline #2 ★: TS Cooldown (lines 2632-2648) |
| S06 | Pine-Encoded Discipline #3 ★★: Preset Philosophy Ring |
| S07 | Pre-Session Discipline — 5-item checklist + 2 kill criteria |
| S08 | Mid-Session 5-Second Decision Tree |
| S09 | Journal Protocol — taken + skipped, equal weight |
| S10 | The 30-Session Process Loop ★★★ — interactive equity-curve scrubber |
| S11 | The Override Doctrine — legitimate vs illegitimate variables |
| S12 | Six Operator Personality Types — each with mechanical defence |
| S13 | The 5-Stage Failure Cascade — Stage-1 Interrupt |
| S14 | Asset-Class Differences — preview of L11.26 |
| S15 | The 30-Day Discipline Test — pass criteria, fail modes |
| Mistakes | 6 cards (bg-red-500/5) |
| Cheat Sheet | 11 sub-section glass card for the second monitor |
| Game | 5 Discipline Failure Cascade Simulator scenarios |
| Quiz | 13 questions, 66% pass threshold |
| Cert | Discipline Operator — rotating conic-gradient |
| Footer | Single centered amber-to-accent button |

**13 animations:**

1. `BooleanEquationAnim` — Hero/S00 equation reveal
2. `PineGateFireAnim` — line 200 boolean firing (pass + fail scenarios)
3. `SkipPileAnim` — 8/3/5 signal flow visualisation
4. `DisciplinePyramidAnim` — 4-tier pyramid building bottom-up with stress test
5. ★ `TSCooldownClockAnim` — countdown clock + rejected attempt + completion
6. ★★ `PresetPhilosophyRingAnim` — 6-preset radial with reconfiguring panel
7. `PreSessionChecklistAnim` — 5-item checklist with kill criteria
8. `MidSessionDecisionTreeAnim` — branching flowchart, 4 scenarios
9. `JournalComposerAnim` — taken + skipped journal cards, equal weight
10. ★★★ `ThirtySessionScrubber` — **interactive** drag-to-scrub equity curve
11. `OverrideReplayAnim` — split-screen + 20-override -14.3R aggregate
12. `PersonalitySwapAnim` — 6 personalities flipping to reveal failure modes
13. `FailureCascadeAnim` — 5-stage chain + plummeting equity curve

---

## Locked-rule verification

All Section 13 locked rules met:

| Rule | Status |
|---|---|
| Body bg gradient `linear-gradient(to bottom, #060a12, #0a0f1a)` | ✓ |
| `bg-[#0a0a0a]` solid (forbidden) | 0 |
| `max-w-3xl` / `max-w-4xl` (forbidden) | 0 |
| `rose-500` (forbidden) | 0 |
| "dashboard" in JSX text (forbidden) | 0 |
| Crown badge with PRO · LEVEL 11 | ✓ |
| `typeof document !== 'undefined'` scroll guard | ✓ |
| Nav `fixed top-1` | ✓ |
| Hero `min-h-[85vh]` + radial halos | ✓ |
| AnimScene signature `(ctx, t, w, h)` byte-perfect from L11.11 | ✓ |
| S00 `py-20` + `p-6 rounded-2xl glass-card` | ✓ |
| Sections `py-16` + `p-5 rounded-2xl glass-card` | ✓ |
| `motion.div whileInView` wrappers (floor 16) | 20 |
| Mistake cards `bg-red-500/5 border border-red-500/15` (exactly 6) | 6 |
| 13 animations | 13 |
| 13 `correct: true` quiz answers | 13 |
| 5 `correct: true` game answers | 5 |
| HTML entities for unicode in JSX bodies | ✓ |
| Cert reveal rotating conic-gradient | ✓ |
| Cert ID format `PRO-CERT-L11.25-XXXXXX` | ✓ |
| Single centered amber-to-accent footer button | ✓ |
| Brace depth balanced (0) | ✓ |

---

## After deploy

Three Level 11 capstones now remain:

- L11.26 Cipher Asset-Class Adaptation
- L11.27 Cipher Failure Modes / Mastery Capstone (Level 11 finale)

S14 of this lesson serves as the bridge into L11.26.
S15's 30-Day Discipline Test is the on-ramp into L11.27.

---

## Section 17 open-thread status after this deploy

- ✅ ~~Direct URL bypass of sequential lesson gate~~ — RESOLVED. The gate-3 patch removes the sequential gate for paying users at the index level too. There's no longer a "direct URL bypass" because there's no longer a gate to bypass for paying users.
- 🟡 TV username edit feature — still held in tar.gz, undeployed
- 🟡 Affiliate Phase 2 (commission engine + referral links + dashboards) — still designed, not built
- 🟡 Daily Diagnostic Index SEO page — still designed, not built
- 🟡 ATLAS Score embeddable widget — still designed, not built
- 🟡 ATLAS Custom consultancy tier — still designed, not built
- 🟡 L11.26 + L11.27 capstones — paused, sequential build queued
