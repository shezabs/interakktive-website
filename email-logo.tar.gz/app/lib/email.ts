// Email notifications via Resend
// Sends admin alerts for subscription events + customer confirmations

const RESEND_API_KEY = process.env.RESEND_API_KEY;
const FROM_EMAIL = 'Interakktive <support@interakktive.com>';
const ADMIN_EMAIL = 'support@interakktive.com';
const LOGO_URL = 'https://www.interakktive.com/images/logo_final.png';
const SITE_URL = 'https://www.interakktive.com';

// Shared email wrapper with logo header and footer
function emailTemplate(content: string): string {
  return `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #0a0a14; border-radius: 12px; overflow: hidden;">
      <div style="background: linear-gradient(135deg, #0a0a14 0%, #1a1a2e 100%); padding: 30px 30px 15px; text-align: center; border-bottom: 1px solid rgba(255,255,255,0.08);">
        <img src="${LOGO_URL}" alt="Interakktive" style="height: 40px; width: auto;" />
      </div>
      <div style="padding: 30px; color: #fff;">
        ${content}
      </div>
      <div style="padding: 20px 30px; border-top: 1px solid rgba(255,255,255,0.08); text-align: center;">
        <p style="color: #6b7280; font-size: 12px; margin: 0 0 8px;">Interakktive — Trading Intelligence You Can See</p>
        <p style="color: #4b5563; font-size: 11px; margin: 0;">
          <a href="${SITE_URL}" style="color: #4b5563; text-decoration: none;">interakktive.com</a> · 
          <a href="${SITE_URL}/dashboard" style="color: #4b5563; text-decoration: none;">Dashboard</a> · 
          <a href="${SITE_URL}/pricing" style="color: #4b5563; text-decoration: none;">Pricing</a>
        </p>
      </div>
    </div>
  `;
}

interface SendEmailParams {
  to: string;
  subject: string;
  html: string;
}

async function sendEmail({ to, subject, html }: SendEmailParams): Promise<boolean> {
  if (!RESEND_API_KEY) {
    console.warn('RESEND_API_KEY not set — skipping email');
    return false;
  }

  try {
    const res = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${RESEND_API_KEY}`,
      },
      body: JSON.stringify({
        from: FROM_EMAIL,
        to,
        subject,
        html,
      }),
    });

    if (!res.ok) {
      const err = await res.json();
      console.error('Resend error:', err);
      return false;
    }

    console.log(`✉️ Email sent: ${subject} → ${to}`);
    return true;
  } catch (err) {
    console.error('Email send failed:', err);
    return false;
  }
}

// ── Admin notification: New subscription ──
export async function notifyNewSubscription(data: {
  email: string;
  tradingviewUsername: string;
  plan: string;
  billing: string;
  indicators: string[];
  isUpgrade?: boolean;
}) {
  const { email, tradingviewUsername, plan, billing, indicators, isUpgrade } = data;
  
  await sendEmail({
    to: ADMIN_EMAIL,
    subject: `🟢 ${isUpgrade ? 'UPGRADE' : 'NEW SUBSCRIPTION'}: ${email} — ${plan} (${billing})`,
    html: emailTemplate(`
      <h2 style="color: #0ea5e9; margin: 0 0 20px;">🟢 ${isUpgrade ? 'Plan Upgrade' : 'New Subscription'}</h2>
      <table style="width: 100%; border-collapse: collapse;">
        <tr><td style="padding: 8px 0; color: #9ca3af;">Email</td><td style="padding: 8px 0; color: #fff; font-weight: bold;">${email}</td></tr>
        <tr><td style="padding: 8px 0; color: #9ca3af;">TradingView</td><td style="padding: 8px 0; color: #fff; font-weight: bold;">${tradingviewUsername}</td></tr>
        <tr><td style="padding: 8px 0; color: #9ca3af;">Plan</td><td style="padding: 8px 0; color: #fff; font-weight: bold;">${plan} (${billing})</td></tr>
        <tr><td style="padding: 8px 0; color: #9ca3af;">Indicators</td><td style="padding: 8px 0; color: #fff; font-weight: bold;">${indicators.join(', ')}</td></tr>
      </table>
      <div style="margin-top: 20px; padding: 15px; background: rgba(14,165,233,0.1); border: 1px solid rgba(14,165,233,0.2); border-radius: 8px;">
        <p style="color: #0ea5e9; margin: 0; font-weight: bold;">⚡ ACTION REQUIRED</p>
        <p style="color: #d1d5db; margin: 8px 0 0;">Grant TradingView access to <strong>${tradingviewUsername}</strong> for: ${indicators.join(', ')}</p>
      </div>
    `),
  });
}

// ── Admin notification: Cancellation ──
export async function notifyCancellation(data: {
  email: string;
  tradingviewUsername: string;
  plan: string;
}) {
  const { email, tradingviewUsername, plan } = data;
  
  await sendEmail({
    to: ADMIN_EMAIL,
    subject: `🔴 CANCELLATION: ${email} — ${plan}`,
    html: emailTemplate(`
      <h2 style="color: #ef4444; margin: 0 0 20px;">🔴 Subscription Cancelled</h2>
      <table style="width: 100%; border-collapse: collapse;">
        <tr><td style="padding: 8px 0; color: #9ca3af;">Email</td><td style="padding: 8px 0; color: #fff; font-weight: bold;">${email}</td></tr>
        <tr><td style="padding: 8px 0; color: #9ca3af;">TradingView</td><td style="padding: 8px 0; color: #fff; font-weight: bold;">${tradingviewUsername}</td></tr>
        <tr><td style="padding: 8px 0; color: #9ca3af;">Plan</td><td style="padding: 8px 0; color: #fff; font-weight: bold;">${plan}</td></tr>
      </table>
      <div style="margin-top: 20px; padding: 15px; background: rgba(239,68,68,0.1); border: 1px solid rgba(239,68,68,0.2); border-radius: 8px;">
        <p style="color: #ef4444; margin: 0; font-weight: bold;">⚡ ACTION REQUIRED</p>
        <p style="color: #d1d5db; margin: 8px 0 0;">Revoke TradingView access for <strong>${tradingviewUsername}</strong> at period end.</p>
      </div>
    `),
  });
}

// ── Admin notification: Swap ──
export async function notifySwap(data: {
  email: string;
  tradingviewUsername: string;
  oldIndicators: string[];
  newIndicators: string[];
}) {
  const { email, tradingviewUsername, oldIndicators, newIndicators } = data;
  
  await sendEmail({
    to: ADMIN_EMAIL,
    subject: `🔄 SWAP: ${email} — ${oldIndicators.join(',')} → ${newIndicators.join(',')}`,
    html: emailTemplate(`
      <h2 style="color: #f59e0b; margin: 0 0 20px;">🔄 Indicator Swap</h2>
      <table style="width: 100%; border-collapse: collapse;">
        <tr><td style="padding: 8px 0; color: #9ca3af;">Email</td><td style="padding: 8px 0; color: #fff; font-weight: bold;">${email}</td></tr>
        <tr><td style="padding: 8px 0; color: #9ca3af;">TradingView</td><td style="padding: 8px 0; color: #fff; font-weight: bold;">${tradingviewUsername}</td></tr>
        <tr><td style="padding: 8px 0; color: #9ca3af;">Old</td><td style="padding: 8px 0; color: #ef4444; font-weight: bold;">${oldIndicators.join(', ')}</td></tr>
        <tr><td style="padding: 8px 0; color: #9ca3af;">New</td><td style="padding: 8px 0; color: #22c55e; font-weight: bold;">${newIndicators.join(', ')}</td></tr>
      </table>
      <div style="margin-top: 20px; padding: 15px; background: rgba(245,158,11,0.1); border: 1px solid rgba(245,158,11,0.2); border-radius: 8px;">
        <p style="color: #f59e0b; margin: 0; font-weight: bold;">⚡ ACTION REQUIRED</p>
        <p style="color: #d1d5db; margin: 8px 0 0;">Update TradingView access for <strong>${tradingviewUsername}</strong>: Remove ${oldIndicators.filter(i => !newIndicators.includes(i)).join(', ') || 'none'}, Add ${newIndicators.filter(i => !oldIndicators.includes(i)).join(', ') || 'none'}</p>
      </div>
    `),
  });
}

// ── Admin notification: TV username change ──
export async function notifyUsernameChange(data: {
  email: string;
  oldUsername: string;
  newUsername: string;
  plan: string;
}) {
  const { email, oldUsername, newUsername, plan } = data;
  
  await sendEmail({
    to: ADMIN_EMAIL,
    subject: `✏️ USERNAME CHANGE: ${email} — ${oldUsername} → ${newUsername}`,
    html: emailTemplate(`
      <h2 style="color: #8b5cf6; margin: 0 0 20px;">✏️ TradingView Username Changed</h2>
      <table style="width: 100%; border-collapse: collapse;">
        <tr><td style="padding: 8px 0; color: #9ca3af;">Email</td><td style="padding: 8px 0; color: #fff; font-weight: bold;">${email}</td></tr>
        <tr><td style="padding: 8px 0; color: #9ca3af;">Plan</td><td style="padding: 8px 0; color: #fff; font-weight: bold;">${plan}</td></tr>
        <tr><td style="padding: 8px 0; color: #9ca3af;">Old Username</td><td style="padding: 8px 0; color: #ef4444; font-weight: bold;">${oldUsername}</td></tr>
        <tr><td style="padding: 8px 0; color: #9ca3af;">New Username</td><td style="padding: 8px 0; color: #22c55e; font-weight: bold;">${newUsername}</td></tr>
      </table>
      <div style="margin-top: 20px; padding: 15px; background: rgba(139,92,246,0.1); border: 1px solid rgba(139,92,246,0.2); border-radius: 8px;">
        <p style="color: #8b5cf6; margin: 0; font-weight: bold;">⚡ ACTION REQUIRED</p>
        <p style="color: #d1d5db; margin: 8px 0 0;">Update TradingView access: Revoke from <strong>${oldUsername}</strong>, grant to <strong>${newUsername}</strong></p>
      </div>
    `),
  });
}

// ── Customer email: Welcome ──
export async function sendWelcomeEmail(data: {
  email: string;
  plan: string;
  indicators: string[];
}) {
  const { email, plan, indicators } = data;
  
  await sendEmail({
    to: email,
    subject: `Welcome to ATLAS PRO Suite — ${plan.charAt(0).toUpperCase() + plan.slice(1)} Plan`,
    html: emailTemplate(`
      <h2 style="color: #0ea5e9; margin: 0 0 20px;">Welcome to Interakktive! 🎉</h2>
      <p style="color: #d1d5db; line-height: 1.6;">Thank you for subscribing to the <strong style="color: #fff;">${plan.charAt(0).toUpperCase() + plan.slice(1)}</strong> plan.</p>
      <p style="color: #d1d5db; line-height: 1.6;">Your indicators: <strong style="color: #0ea5e9;">${indicators.join(', ')}</strong></p>
      <p style="color: #d1d5db; line-height: 1.6;">We'll grant you TradingView access within <strong style="color: #fff;">4 hours</strong>. You'll receive the indicators as Invite-Only scripts in your TradingView account.</p>
      <div style="margin-top: 20px; padding: 15px; background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px;">
        <p style="color: #9ca3af; margin: 0; font-size: 14px;">Need help? Reply to this email or visit <a href="${SITE_URL}/dashboard" style="color: #0ea5e9;">your dashboard</a>.</p>
      </div>
    `),
  });
}

// ── Customer email: Cancellation confirmed ──
export async function sendCancellationEmail(data: {
  email: string;
  plan: string;
  accessUntil: string;
}) {
  const { email, plan, accessUntil } = data;
  const dateStr = new Date(accessUntil).toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' });
  
  await sendEmail({
    to: email,
    subject: `Your ${plan.charAt(0).toUpperCase() + plan.slice(1)} plan has been cancelled`,
    html: emailTemplate(`
      <h2 style="color: #f59e0b; margin: 0 0 20px;">Subscription Cancelled</h2>
      <p style="color: #d1d5db; line-height: 1.6;">Your <strong style="color: #fff;">${plan.charAt(0).toUpperCase() + plan.slice(1)}</strong> plan has been cancelled.</p>
      <p style="color: #d1d5db; line-height: 1.6;">You still have full access to your indicators until <strong style="color: #fff;">${dateStr}</strong>.</p>
      <p style="color: #d1d5db; line-height: 1.6;">After that date, your TradingView access will be revoked.</p>
      <div style="margin-top: 20px; padding: 15px; background: rgba(14,165,233,0.05); border: 1px solid rgba(14,165,233,0.15); border-radius: 8px;">
        <p style="color: #0ea5e9; margin: 0; font-weight: bold;">Changed your mind?</p>
        <p style="color: #d1d5db; margin: 8px 0 0;">You can reactivate anytime before ${dateStr} from your <a href="${SITE_URL}/dashboard" style="color: #0ea5e9;">dashboard</a>.</p>
      </div>
    `),
  });
}

// ── Customer email: Swap confirmed ──
export async function sendSwapEmail(data: {
  email: string;
  newIndicators: string[];
  nextSwapDate: string;
}) {
  const { email, newIndicators, nextSwapDate } = data;
  const dateStr = nextSwapDate ? new Date(nextSwapDate).toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' }) : 'next month';
  
  await sendEmail({
    to: email,
    subject: `Indicator swap confirmed — ${newIndicators.join(' + ')}`,
    html: emailTemplate(`
      <h2 style="color: #0ea5e9; margin: 0 0 20px;">Indicator Swap Confirmed 🔄</h2>
      <p style="color: #d1d5db; line-height: 1.6;">Your indicators have been updated to:</p>
      <p style="color: #0ea5e9; font-size: 18px; font-weight: bold; margin: 15px 0;">${newIndicators.join(' + ')}</p>
      <p style="color: #d1d5db; line-height: 1.6;">We'll update your TradingView access within <strong style="color: #fff;">4 hours</strong>.</p>
      <p style="color: #d1d5db; line-height: 1.6;">Your next swap will be available on <strong style="color: #fff;">${dateStr}</strong>.</p>
      <div style="margin-top: 20px; padding: 15px; background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px;">
        <p style="color: #9ca3af; margin: 0; font-size: 14px;">Need help? Reply to this email or visit <a href="${SITE_URL}/dashboard" style="color: #0ea5e9;">your dashboard</a>.</p>
      </div>
    `),
  });
}

// ── Customer email: Upgrade confirmed ──
export async function sendUpgradeEmail(data: {
  email: string;
  newPlan: string;
  indicators: string[];
}) {
  const { email, newPlan, indicators } = data;
  
  await sendEmail({
    to: email,
    subject: `Upgraded to ${newPlan.charAt(0).toUpperCase() + newPlan.slice(1)} — ATLAS PRO Suite`,
    html: emailTemplate(`
      <h2 style="color: #0ea5e9; margin: 0 0 20px;">Plan Upgraded! 🚀</h2>
      <p style="color: #d1d5db; line-height: 1.6;">You've been upgraded to the <strong style="color: #fff;">${newPlan.charAt(0).toUpperCase() + newPlan.slice(1)}</strong> plan.</p>
      <p style="color: #d1d5db; line-height: 1.6;">Your indicators: <strong style="color: #0ea5e9;">${indicators.join(', ')}</strong></p>
      <p style="color: #d1d5db; line-height: 1.6;">We'll update your TradingView access within <strong style="color: #fff;">4 hours</strong>.</p>
      <p style="color: #d1d5db; line-height: 1.6;">Any unused time from your previous plan has been credited toward this subscription.</p>
      <div style="margin-top: 20px; padding: 15px; background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px;">
        <p style="color: #9ca3af; margin: 0; font-size: 14px;">Need help? Reply to this email or visit <a href="${SITE_URL}/dashboard" style="color: #0ea5e9;">your dashboard</a>.</p>
      </div>
    `),
  });
}

// ── Customer email: Payment failed ──
export async function sendPaymentFailedEmail(data: {
  email: string;
  plan: string;
}) {
  const { email, plan } = data;
  
  await sendEmail({
    to: email,
    subject: `Payment failed — Action required for your ${plan.charAt(0).toUpperCase() + plan.slice(1)} plan`,
    html: emailTemplate(`
      <h2 style="color: #ef4444; margin: 0 0 20px;">Payment Failed ⚠️</h2>
      <p style="color: #d1d5db; line-height: 1.6;">We were unable to process the payment for your <strong style="color: #fff;">${plan.charAt(0).toUpperCase() + plan.slice(1)}</strong> plan.</p>
      <p style="color: #d1d5db; line-height: 1.6;">Please update your payment method to avoid losing access to your indicators.</p>
      <div style="margin-top: 20px; text-align: center;">
        <a href="${SITE_URL}/dashboard" style="display: inline-block; padding: 12px 30px; background: linear-gradient(to right, #0ea5e9, #d946ef); color: #fff; text-decoration: none; border-radius: 8px; font-weight: bold;">Update Payment Method</a>
      </div>
      <p style="color: #9ca3af; font-size: 13px; margin-top: 20px; line-height: 1.6;">If you believe this is an error, reply to this email and we'll help you sort it out.</p>
    `),
  });
}

// ── Customer email: Subscription expired ──
export async function sendExpiredEmail(data: {
  email: string;
  plan: string;
}) {
  const { email, plan } = data;
  
  await sendEmail({
    to: email,
    subject: `Your ${plan.charAt(0).toUpperCase() + plan.slice(1)} plan has expired`,
    html: emailTemplate(`
      <h2 style="color: #6b7280; margin: 0 0 20px;">Subscription Ended</h2>
      <p style="color: #d1d5db; line-height: 1.6;">Your <strong style="color: #fff;">${plan.charAt(0).toUpperCase() + plan.slice(1)}</strong> plan has now expired and your TradingView access has been revoked.</p>
      <p style="color: #d1d5db; line-height: 1.6;">We hope the ATLAS PRO indicators helped your trading. If you'd like to resubscribe, you can do so anytime.</p>
      <div style="margin-top: 20px; text-align: center;">
        <a href="${SITE_URL}/pricing" style="display: inline-block; padding: 12px 30px; background: linear-gradient(to right, #0ea5e9, #d946ef); color: #fff; text-decoration: none; border-radius: 8px; font-weight: bold;">View Plans</a>
      </div>
      <p style="color: #9ca3af; font-size: 13px; margin-top: 20px; line-height: 1.6;">Questions? Reply to this email — we're here to help.</p>
    `),
  });
}
