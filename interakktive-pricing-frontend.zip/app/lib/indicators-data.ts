import { Indicator } from '@/app/types/indicator';

export const freeIndicators: Indicator[] = [
  {
    id: 'market-adaptive-trend',
    title: 'Market Adaptive Trend [Interakktive]',
    shortTitle: 'Market Adaptive Trend',
    description: 'A diagnostic trend baseline that re-tunes its own responsiveness to the live volatility regime — and narrates why, in plain English. Reveals how the trend is behaving, not where price "should" go.',
    features: [
      'Regime governor classifies volatility as RIDING, TIGHTENING, or GUARDED',
      'Adaptive baseline that loosens in calm markets and damps when volatility stretches',
      'Plain-English HUD: trend, regime, responsiveness, and a one-line state summary',
      'Gradient fill, edge glow, and regime-aware candle tinting (amber when GUARDED)',
      'Configurable calm/volatile thresholds and adaptation strength',
      'Trend-flip alert conditions for awareness, not automation',
    ],
    useCases: [
      'Use as a trend backdrop and context for your own setups',
      'Read the regime to set expectations before acting',
      'Treat the GUARDED state as a caution signal in volatile conditions',
      'Tune responsiveness to match your instrument and timeframe',
      'Combine with other free Interakktive diagnostics for fuller context',
    ],
    technicalDetails: 'Adaptive baseline driven by an error-feedback step scaled to the volatility regime. Relative volatility (ATR vs its own average) governs responsiveness. Closed-bar data only — no lookahead. Plain-English narrative, never raw scores.',
    tradingViewUrl: 'https://www.tradingview.com/script/SOZioJML-Market-Adaptive-Trend-Interakktive/',
    category: 'free',
    stats: {
      favorites: 0,
      publishedDate: 'June 2026',
    },
    isPro: false,
    isPublished: true,
    image: '/images/Market_Adaptive_Trend_SS.png',
  },
  {
    id: 'sessions-plus',
    title: 'Sessions + [Interakktive]',
    shortTitle: 'Sessions +',
    description: 'A standalone session intelligence indicator with DNA predictor narrative, adaptive multi-timeframe level degradation, and session-based structure analysis. Built as the gateway to the ATLAS suite — full diagnostic transparency with zero cost.',
    features: [
      'Session high/low tracking with adaptive level degradation',
      'DNA predictor narrative box with plain English intelligence',
      'Multi-timeframe level system (PHH/PHL through PQH/PQL)',
      'Previous Hour High/Low levels on sub-hourly timeframes',
      'Dashboard rows adapt by timeframe automatically',
      '39 alert conditions for comprehensive notification coverage',
    ],
    useCases: [
      'Identify key session levels for intraday trading',
      'Use DNA predictor to assess session bias before entering',
      'Combine with CIPHER PRO or PHANTOM PRO for confluent setups',
      'Track session structure across multiple timeframes',
      'Set alerts for session level breaks and sweeps',
    ],
    technicalDetails: 'Standalone indicator (no library imports). Hardcoded ATLAS brand colours. Multi-timeframe level degradation via ternary operators. Dashboard adapts rows based on chart timeframe.',
    tradingViewUrl: 'https://www.tradingview.com/script/g3aVrzmp-Sessions-Interakktive/',
    category: 'free',
    stats: {
      favorites: 0,
      publishedDate: 'March 2026',
    },
    isPro: false,
    isPublished: true,
    image: '/images/Sessions_Plus_SS.png',
  },
  {
    id: 'market-acceptance-envelope',
    title: 'Market Acceptance Envelope [Interakktive]',
    shortTitle: 'Market Acceptance Envelope',
    description: 'A dynamic envelope system that identifies institutional acceptance zones through probabilistic boundaries. Quantifies where price "belongs" based on statistical acceptance thresholds, revealing genuine support/resistance levels formed by market consensus.',
    features: [
      'Probabilistic acceptance boundaries',
      'Dynamic width adjustment based on volatility states',
      'Multi-standard deviation envelope layers',
      'Institutional acceptance zone identification',
      'Real-time boundary breach detection',
      'Customizable lookback and smoothing parameters',
    ],
    useCases: [
      'Identify high-probability reversal zones at envelope extremes',
      'Confirm trend strength when price sustains outside boundaries',
      'Detect compression phases when envelope narrows',
      'Validate breakouts when price establishes new acceptance ranges',
      'Support mean-reversion strategies in ranging markets',
    ],
    technicalDetails: 'Uses statistical standard deviation bands around a moving average baseline, with adaptive width calculations responding to realised volatility. Default: 20-period lookback with 2.0/2.5/3.0 standard deviation multipliers.',
    tradingViewUrl: 'https://www.tradingview.com/script/ZICs0t70-Market-Acceptance-Envelope-Interakktive/',
    category: 'free',
    stats: {
      uses: 2422,
      favorites: 511,
      publishedDate: 'December 25, 2025',
    },
    isPro: false,
    isPublished: true,
    image: '/images/Market_Acceptance_Envelope_SS.png',
  },
  {
    id: 'market-state-intelligence',
    title: 'Market State Intelligence [Interakktive]',
    shortTitle: 'Market State Intelligence',
    description: 'A multi-dimensional regime classifier that synthesizes trend, momentum, volatility, and structure into unified market state intelligence. Provides real-time regime detection so traders can adapt strategies to current conditions.',
    features: [
      'Four-dimensional state analysis (Trend, Momentum, Volatility, Structure)',
      'Real-time regime classification system',
      'Composite market state scoring',
      'Visual state transition alerts',
      'Historical regime performance tracking',
      'Customizable dimension weights and thresholds',
    ],
    useCases: [
      'Adapt trading strategies based on current market regime',
      'Identify regime transitions before they fully develop',
      'Filter trade signals based on favourable market states',
      'Understand why certain strategies perform in specific conditions',
      'Build regime-conditional trading systems',
    ],
    technicalDetails: 'Combines normalised metrics across four dimensions: ADX-based trend strength, RSI momentum, ATR volatility states, and swing structure analysis.',
    tradingViewUrl: 'https://www.tradingview.com/script/I1eqEIHI-Market-State-Intelligence-Interakktive/',
    category: 'free',
    stats: {
      uses: 660,
      favorites: 2311,
      publishedDate: 'December 25, 2025',
    },
    isPro: false,
    isPublished: true,
    image: '/images/Market_State_Intelligence_SS.png',
  },
  {
    id: 'market-acceptance-zones',
    title: 'Market Acceptance Zones [Interakktive]',
    shortTitle: 'Market Acceptance Zones',
    description: 'Identifies institutional acceptance levels where significant volume concentration and price equilibrium occurs. Maps horizontal zones representing areas of sustained interest, revealing where smart money has established positions.',
    features: [
      'Volume-weighted acceptance level detection',
      'Time-at-price concentration analysis',
      'Dynamic zone width based on institutional activity',
      'Support/Resistance level validation',
      'Historical zone strength persistence tracking',
      'Multi-timeframe zone confluence detection',
    ],
    useCases: [
      'Identify high-probability reversal zones at established acceptance levels',
      'Validate breakout potential when price exits acceptance zones',
      'Find institutional entry/exit areas based on volume concentration',
      'Set strategic stop-loss placements outside acceptance boundaries',
      'Detect accumulation/distribution zones through sustained price action',
    ],
    technicalDetails: 'Combines volume profile analysis with time-weighted price distribution to identify statistically significant acceptance zones.',
    tradingViewUrl: 'https://www.tradingview.com/script/yZ4KaZk4-Market-Acceptance-Zones-Interakktive/',
    category: 'free',
    stats: {
      views: 21811,
      favorites: 2532,
      publishedDate: 'December 23, 2025',
    },
    isPro: false,
    isPublished: true,
    image: '/images/Market_Acceptance_Zones_SS.png',
  },
  {
    id: 'market-participation-gradient',
    title: 'Market Participation Gradient [Interakktive]',
    shortTitle: 'Market Participation Gradient',
    description: 'Tracks the intensity and directional bias of market participation through momentum pressure analysis. Measures whether participation is accelerating or decelerating, revealing the commitment level behind price movements.',
    features: [
      'Momentum pressure intensity measurement',
      'Directional participation bias detection',
      'Acceleration/Deceleration gradient analysis',
      'Conviction strength quantification',
      'Visual participation heat mapping',
      'Divergence detection between price and participation',
    ],
    useCases: [
      'Confirm trend strength through rising participation gradients',
      'Detect early weakness when participation decelerates despite price advance',
      'Identify exhaustion zones where participation peaks',
      'Validate reversals when participation shifts directional bias',
      'Filter low-conviction moves with weak participation',
    ],
    technicalDetails: 'Combines rate-of-change calculations across multiple timeframes with momentum oscillators to create a composite participation gradient.',
    tradingViewUrl: 'https://www.tradingview.com/script/CxnjSZB9-Market-Participation-Gradient-Interakktive/',
    category: 'free',
    stats: {
      uses: 365,
      favorites: 1611,
      publishedDate: 'December 22, 2025',
    },
    isPro: false,
    isPublished: true,
    image: '/images/Market_Participation_Gradient_SS.png',
  },
  {
    id: 'market-pressure-regime',
    title: 'Market Pressure Regime [Interakktive]',
    shortTitle: 'Market Pressure Regime',
    description: 'A multi-dimensional pressure state classifier that identifies whether current market conditions favour buyers, sellers, or equilibrium. Synthesizes buying pressure, selling pressure, and equilibrium metrics into actionable regime states.',
    features: [
      'Three-dimensional pressure analysis (Buy/Sell/Equilibrium)',
      'Real-time regime classification system',
      'Pressure intensity scoring (0-100 scale)',
      'Visual pressure state zones',
      'Regime transition alerts',
      'Historical pressure pattern recognition',
    ],
    useCases: [
      'Identify dominant market pressure regimes in real-time',
      'Detect regime shifts before price fully reflects them',
      'Adapt directional bias based on pressure dominance',
      'Avoid counter-trend trades in strong pressure regimes',
      'Recognise equilibrium zones for range-bound strategies',
    ],
    technicalDetails: 'Combines volume-weighted buying pressure, selling pressure, and equilibrium calculations with adaptive smoothing and persistence logic.',
    tradingViewUrl: 'https://www.tradingview.com/script/V3jfGrc1-Market-Pressure-Regime-Interakktive/',
    category: 'free',
    stats: {
      uses: 387,
      favorites: 1422,
      publishedDate: 'December 20, 2025',
    },
    isPro: false,
    isPublished: true,
    image: '/images/Market_Pressure_Regime_SS.png',
  },
  {
    id: 'volatility-state-index',
    title: 'Volatility State Index [Interakktive]',
    shortTitle: 'Volatility State Index',
    description: 'A volatility regime detection system that classifies current market conditions into distinct states: Expansion, Decay, and Transition. Diagnoses the current volatility regime so traders can adapt their approach accordingly.',
    features: [
      'Three-state volatility classification (Expansion/Decay/Transition)',
      'Momentum analysis applied to volatility itself',
      'Stability filtering to detect genuinely unstable conditions',
      'Persistence logic to prevent false regime flipping',
      'State-first visual design for instant recognition',
      'Adaptive threshold calculations',
    ],
    useCases: [
      'Adjust position sizing based on current volatility regime',
      'Widen stops in expansion, tighten in decay states',
      'Identify volatility expansion preceding major moves',
      'Detect compression zones for potential breakout setups',
      'Adapt strategy parameters to volatility environment',
    ],
    technicalDetails: 'Uses ATR with rate-of-change analysis and stability filtering. State-first design classifies volatility regimes rather than plotting raw levels.',
    tradingViewUrl: 'https://www.tradingview.com/script/7K0MaDFs-Volatility-State-Index-Interakktive/',
    category: 'free',
    stats: {
      uses: 480,
      favorites: 2511,
      publishedDate: 'December 19, 2025',
    },
    isPro: false,
    isPublished: true,
    image: '/images/Volitality_State_Index_SS.png',
  },
  {
    id: 'effort-result-divergence',
    title: 'Effort-Result Divergence [Interakktive]',
    shortTitle: 'Effort-Result Divergence',
    description: 'A Wyckoff-inspired analytical tool that identifies efficiency anomalies by comparing volume effort against price result. Detects conditions revealing potential institutional activity.',
    features: [
      'Volume-Price efficiency ratio calculation',
      'Effort-Result divergence detection',
      'Institutional activity anomaly identification',
      'Efficiency/Inefficiency zone mapping',
      'Visual divergence alerts',
      'Customizable sensitivity thresholds',
    ],
    useCases: [
      'Identify accumulation zones where high volume produces minimal downside',
      'Detect distribution patterns with large volume but limited upside',
      'Recognise potential reversals at extreme effort-result divergences',
      'Validate breakouts when volume effort aligns with price result',
      'Spot institutional positioning through efficiency anomalies',
    ],
    technicalDetails: 'Calculates efficiency ratio by comparing normalised volume intensity to normalised price displacement. Detects statistical outliers using z-score methodology.',
    tradingViewUrl: 'https://www.tradingview.com/script/kb56fTI3-Effort-Result-Divergence-Interakktive/',
    category: 'free',
    stats: {
      uses: 549,
      favorites: 2311,
      publishedDate: 'December 18, 2025',
    },
    isPro: false,
    isPublished: true,
    image: '/images/Effort_Result_Divergence_SS.png',
  },
  {
    id: 'market-efficiency-ratio',
    title: 'Market Efficiency Ratio [Interakktive]',
    shortTitle: 'Market Efficiency Ratio',
    description: 'A diagnostic tool that decomposes price movement into directional progress versus wasted oscillatory movement. Quantifies what proportion of total travel distance represented genuine advancement versus sideways chop.',
    features: [
      'Efficiency Ratio calculation (0-100 scale)',
      'Net Displacement measurement',
      'Path Length tracking (total distance traveled)',
      'Chop Cost quantification',
      'Visual efficiency zones (Green/Yellow/Red)',
      'Customizable lookback and smoothing parameters',
    ],
    useCases: [
      'Differentiate clean trending periods from messy consolidation',
      'Understand relationship between total movement and productive progress',
      'Identify high-chop environments presenting elevated trading difficulty',
      'Assess trend quality without volume dependence',
      'Foundation work for advanced regime detection systems',
    ],
    technicalDetails: 'Net Displacement = |Close[current] - Close[N bars back]|; Path Length = Sum of bar-to-bar absolute changes; Efficiency Ratio = Net Displacement / Path Length. Default: 14-bar lookback, 5-bar EMA smoothing.',
    tradingViewUrl: 'https://www.tradingview.com/script/e1LSxUSp-Market-Efficiency-Ratio-Interakktive/',
    category: 'free',
    stats: {
      uses: 2411,
      favorites: 450,
      publishedDate: 'December 18, 2025',
    },
    isPro: false,
    isPublished: true,
    image: '/images/Market_Efficiency_Ration_SS.png',
  },
];

export const proIndicators: Indicator[] = [
  {
    id: 'atlas-cipher-pro',
    title: 'Atlas Cipher Pro [Interakktive]',
    shortTitle: 'CIPHER PRO',
    description: 'The flagship signal intelligence engine of the ATLAS suite. Combines asset-adaptive signal filtering, Ghost Performance tracking, Win Probability estimation, and a full Narrative Engine into a comprehensive decision support system.',
    features: [
      'PX + Tension Snap (TS) signal architecture with conviction scoring',
      'Ghost Performance\u2122 \u2014 historical win rate tracking with first-touch-only validation',
      'Win Probability Estimator with component similarity matching',
      'Adaptive Quality Threshold \u2014 adjusts based on rolling win rate',
      'Asset Intelligence Layer \u2014 238 configurations across 34 assets and 7 timeframes',
      'Risk Ribbon with volatility state classification',
      'Fair Value Gap smart tracking with mitigation detection',
      'Signal Autopsy + Intelligence Panel dual-dashboard',
      'Full alert system with JSON webhook payloads',
    ],
    useCases: [
      'Execute high-probability entries validated by Ghost Performance data',
      'Leverage multi-timeframe confluence for enhanced conviction',
      'Adapt signal quality thresholds automatically based on market conditions',
      'Use Win Probability to size positions according to statistical edge',
      'Combine with PHANTOM PRO and PULSE PRO for full-suite confluence',
    ],
    technicalDetails: '64/64 outputs | Asset-adaptive across stocks, forex, crypto, CFDs | Trail stops optimised at 1.0 ATR (368% improvement in backtested returns across 34 assets \u00d7 7 timeframes)',
    tradingViewUrl: 'https://www.tradingview.com/script/vvf2W2ZG/',
    category: 'pro',
    stats: {
      favorites: 0,
      publishedDate: 'March 2026',
    },
    isPro: true,
    isPublished: true,
    image: '/images/Cipher_Pro_SS.png',
  },
  {
    id: 'atlas-phantom-pro',
    title: 'Atlas Phantom Pro [Interakktive]',
    shortTitle: 'PHANTOM PRO',
    description: 'The unified Smart Money Concepts (SMC) and market structure intelligence engine. Dual-layer swing detection, BOS/CHoCH classification with strength scoring, Order Block Three-Eye detection, Zone DNA grading, FVG engine, Liquidity detection, Institutional Levels, and a complete Narrative Engine \u2014 all in plain English.',
    features: [
      'Dual-layer swing detection with BOS/CHoCH classification',
      'Order Block Three-Eye\u2122 detection with Zone DNA grading (A+ to F)',
      'Ghost Performance\u2122 for Structure and Zones',
      'Fair Value Gap engine with Inverse FVG (IFVG) support',
      'Liquidity Engine \u2014 EQH/EQL, Liquidity Grabs, Trendlines',
      'Institutional Levels\u2122 \u2014 PDH/PDL/PWH/PWL/PMH/PML/PQH/PQL with sweep lifecycle',
      'Smart Money Sequence\u2122 \u2014 5-step ICT playbook recognition',
      'Structural Confluence Kill Zones with pattern intelligence',
      'Command Centre with full Narrative Engine',
      '4-Timeframe MTF Panel',
    ],
    useCases: [
      'Identify institutional order blocks with validated quality grades',
      'Track market structure shifts across timeframes',
      'Detect liquidity sweeps at previous period highs/lows',
      'Use Zone DNA to filter high-quality zones from noise',
      'Combine Smart Money Sequence detection with CIPHER signals',
    ],
    technicalDetails: 'Overlay indicator | 9 request.security() calls | Command Centre with plain English intelligence | Institutional Levels with UNTESTED\u2192APPROACHING\u2192TESTING\u2192SWEPT lifecycle',
    tradingViewUrl: 'https://www.tradingview.com/script/fMZJJ8FQ/',
    category: 'pro',
    stats: {
      favorites: 0,
      publishedDate: 'March 2026',
    },
    isPro: true,
    isPublished: true,
    image: '/images/Phantom_Pro_SS.png',
  },
  {
    id: 'atlas-pulse-pro',
    title: 'Atlas Pulse Pro [Interakktive]',
    shortTitle: 'PULSE PRO',
    description: 'A pure momentum intelligence oscillator. Dual FLOW/WAVE engine, Pressure Bands, Rhythm analysis, Fatigue detection, Divergence lifecycle tracking, and a 6-component Pulse Score with consensus penalty. No signals \u2014 just deep diagnostic insight into market momentum.',
    features: [
      'Dual-layer FLOW/WAVE oscillator with adaptive calculations',
      'Pressure Bands showing momentum containment boundaries',
      'Rhythm analysis \u2014 measures momentum cadence and regularity',
      'Fatigue detection with exhaustion classification (VEL/FL/TRAP)',
      'Divergence engine with glow effects and lifecycle labels',
      'Pulse Score \u2014 6-component weighted composite with consensus penalty',
      'Pulse Memory \u2014 historical context for current momentum levels',
      'Momentum DNA strip \u2014 MTF alignment with auto-adaptive timeframes',
      'Edge Bars \u2014 score-driven strips at pane edges',
      'Narrative Engine with plain English momentum assessment',
    ],
    useCases: [
      'Assess momentum health before entering trades',
      'Detect exhaustion conditions before reversals',
      'Use consensus penalty to identify conflicting momentum layers',
      'Track DNA alignment across timeframes for confluence',
      'Monitor Pulse Memory for historical context',
    ],
    technicalDetails: '49/64 outputs | 19 alerts | Pure intelligence tool \u2014 trend/reversal signals deliberately removed after testing proved oscillator crossovers cannot match price-structure accuracy',
    tradingViewUrl: 'https://www.tradingview.com/script/nHfT0sXk/',
    category: 'pro',
    stats: {
      favorites: 0,
      publishedDate: 'March 2026',
    },
    isPro: true,
    isPublished: true,
    image: '/images/Pulse_Pro_SS.png',
  },
  {
    id: 'atlas-radar-pro',
    title: 'Atlas Radar Pro [Interakktive]',
    shortTitle: 'RADAR PRO',
    description: 'A multi-ticker intelligence screener scanning 10 tickers simultaneously across three independent engines: Signal, Structure, and Momentum. The only screener on TradingView with three genuinely independent analytical dimensions producing a unified Confluence rating. Includes a dedicated Timeframe column for multi-TF scanning of the same ticker.',
    features: [
      '10-ticker simultaneous scanning via request.security()',
      'Signal Engine \u2014 6-factor stateless confluence assessment',
      'Structure Engine \u2014 stateless HH/HL vs LH/LL bias detection',
      'Momentum Engine \u2014 100% proprietary adaptive computations',
      'Cross-engine Confluence rating with weighted composite scoring',
      'Timeframe column \u2014 scan the same ticker across multiple TFs in one table',
      '3 stackable filters + 5-column sorting',
      'Volatility classification across 5 tiers',
      'All columns independently toggleable',
      '6-type JSON alert system with transition detection',
    ],
    useCases: [
      'Screen watchlist for tickers where all three engines agree',
      'Identify highest-confluence opportunities across instruments',
      'Filter by volatility regime to match risk tolerance',
      'Sort by signal, structure, momentum, confluence, or rating',
      'Set alerts for rating transitions to catch emerging setups',
    ],
    technicalDetails: '40 request.security() calls (10 tickers \u00d7 4 fetch loops) | 835 lines | Stateless architecture prevents var state bleed | Toggleable TF column for multi-timeframe scanning | No competitor has 3 independent engines in a single screener',
    tradingViewUrl: 'https://www.tradingview.com/script/V6tg80MI-Atlas-Radar-Pro-Interakktive/',
    category: 'pro',
    stats: {
      favorites: 0,
      publishedDate: 'March 2026',
    },
    isPro: true,
    isPublished: true,
    image: '/images/Radar_Pro_SS.png',
  },
  {
    id: 'atlas-options-pro',
    title: 'Atlas Options Pro [Interakktive]',
    shortTitle: 'OPTIONS PRO',
    description: 'An options intelligence overlay that diagnoses the volatility environment and translates it into actionable options strategy recommendations. Five-regime volatility engine, full Black-Scholes-Merton Greeks, gamma structure mapping, institutional Whale Flow analysis, and a strategy scoring matrix \u2014 all with cross-timeframe consistency from 1-minute to Monthly.',
    features: [
      '5-regime Volatility Engine \u2014 Compression, Expansion, Crush, Spike, Mean-Revert',
      'Full BSM Greeks \u2014 Delta, Gamma, Theta, Vega + optional Vanna, Charm, Vomma',
      'Cross-TF Consistent \u2014 IV Rank, IV Percentile, IV Status identical on all timeframes',
      'Gamma Structure \u2014 strike-level hedging zones with ATM, Pin Risk, Max Pain',
      'Whale Flow Intelligence \u2014 VIX term structure, SKEW, institutional positioning',
      'Strategy Matrix \u2014 10-strategy scoring with regime + premium + flow alignment',
      'Expected Move Fan \u2014 50%/1\u03c3/2\u03c3 probability projections',
      'OPEX Gravity Field \u2014 expanding visual showing hedging pull near expiry',
      'Narrative Engine \u2014 plain English synthesis of all five engines',
      '6 asset classes \u2014 ETF, Stock, Crypto, Forex, Gold, Oil with auto-detection',
    ],
    useCases: [
      'Diagnose the volatility regime before selecting an options strategy',
      'Use IV Rank and IV Percentile to assess whether options are cheap or expensive',
      'Identify gamma zones where market maker hedging creates support/resistance',
      'Check Whale Flow for institutional positioning confirmation',
      'Get strategy recommendations scored against the current environment',
    ],
    technicalDetails: '15 alerts | Real IV data from CBOE VIX, GVZ, OVX + Deribit DVOL/ETHDVOL | Cross-timeframe consistent IV Rank and IV Percentile | 6 asset classes with auto-detection',
    tradingViewUrl: 'https://www.tradingview.com/script/9D3jLsLj-Atlas-Options-Pro-Interakktive/',
    category: 'pro',
    stats: {
      favorites: 0,
      publishedDate: 'April 2026',
    },
    isPro: true,
    isPublished: true,
    image: '/images/Options_Pro_SS.png',
  },
];

// Pricing tiers
export interface PricingTier {
  id: string;
  name: string;
  description: string;
  recommendedFor?: string;
  badge?: string;
  monthlyPrice: number;
  annualPrice: number;
  annualOriginalPrice?: number;
  priceNote?: string;        // e.g. "Starting from" or activation note
  seats?: number;
  features: string[];
  isPopular?: boolean;
  isFree?: boolean;
  hideCta?: boolean;
  ctaLabel?: string;
  ctaHref?: string;          // overrides checkout for free/contact tiers
  activationNote?: string;   // shown post-purchase guidance (e.g. MAX seats by email)
  stripePriceIdMonthly?: string;
  stripePriceIdAnnual?: string;
  customCycles?: CustomCycle[];   // PRO "Custom" side: weekly / bi-weekly / monthly
}

// Custom billing cycles shown under the ATLAS PRO price on the "Custom" toggle side.
// `id` flows through checkout as ?billing=<id> and maps to a Stripe price on the backend.
export interface CustomCycle {
  id: 'weekly' | 'biweekly' | 'monthly';
  label: string;    // e.g. "Weekly"
  sublabel: string; // e.g. "7 days"
  price: number;    // display price
}

// ==========================================================================
// PRICING TIERS — rebuilt 2026-06-14.
// FREE / ATLAS PRO / ATLAS MAX. No indicator pick-and-choose: each paid tier
// grants a fixed set. Annual = 2 months free. All commentary framed as
// educational, not financial advice.
// ==========================================================================
export const pricingTiers: PricingTier[] = [
  {
    id: 'free',
    name: 'FREE Suite',
    description: 'Get started with our core tools and community at no cost.',
    recommendedFor: 'General Public',
    monthlyPrice: 0,
    annualPrice: 0,
    isFree: true,
    ctaLabel: 'Sign Up Free',
    ctaHref: '/signup',
    features: [
      'All Free Indicators',
      '3 lessons of Trading Academy',
      'Free trading calculators (position size, risk-to-reward, pip value, lot size & more)',
      'Free YouTube videos',
      'Free Discord groups',
      'WhatsApp "Interakktive Hub" group',
      'WhatsApp broadcast channels',
    ],
  },
  {
    id: 'pro',
    name: 'ATLAS PRO Suite',
    description: 'The complete ATLAS PRO toolkit for the individual trader.',
    recommendedFor: 'Individual Clients',
    badge: 'MOST POPULAR',
    priceNote: 'Pre-Discount',
    monthlyPrice: 99.99,
    annualPrice: 999.99,
    annualOriginalPrice: 1199.99,
    seats: 1,
    isPopular: true,
    ctaLabel: 'Get Started',
    customCycles: [
      { id: 'weekly', label: 'Weekly', sublabel: '7 days', price: 29.99 },
      { id: 'biweekly', label: 'Bi-Weekly', sublabel: '14 days', price: 54.99 },
      { id: 'monthly', label: 'Monthly', sublabel: '1 month', price: 99.99 },
    ],
    features: [
      'Everything included in FREE, plus:',
      'All premium indicators on TradingView (1 seat)',
      'Full trading calculator suite + premium calculators (prop-firm challenge, drawdown recovery, risk-of-ruin)',
      'Personal trade journal & performance tracker',
      'Full Trading Academy + Prop Firm Manager',
      'Support team facility',
      'Unlisted (private) YouTube videos',
      'Premium (private) Discord groups',
      'Live (recorded) trading & learning sessions',
      'WhatsApp "ATLAS Inner Circle" group',
    ],
  },
  {
    id: 'max',
    name: 'ATLAS MAX Suite',
    description: 'Multi-seat access and weekly educational commentary for teams and institutions.',
    recommendedFor: 'Institutional Clients',
    badge: 'BEST FOR TEAMS',
    priceNote: 'Starting from',
    monthlyPrice: 299.99,
    annualPrice: 2999.99,
    annualOriginalPrice: 3599.99,
    seats: 4,
    ctaLabel: 'Get Started',
    activationNote:
      'After checkout, email your 4 TradingView usernames to support@interakktive.com to activate your seats. You can request username changes anytime; your plan always includes 4 seats.',
    features: [
      'Everything included in ATLAS PRO, plus:',
      '4 TradingView seats (4 usernames)',
      'Priority support team facility',
      'Weekly educational market recap & roundup',
      'Weekly technical education & market recap',
      'Weekly session open/close commentary',
      'Weekly general market commentary',
      'WhatsApp private "Custom-Built Requests" group',
    ],
  },
];

export const allIndicators = [...freeIndicators, ...proIndicators];

export function getIndicatorById(id: string): Indicator | undefined {
  return allIndicators.find(indicator => indicator.id === id);
}

export function getFreeIndicators(): Indicator[] {
  return freeIndicators;
}

export function getProIndicators(): Indicator[] {
  return proIndicators;
}
